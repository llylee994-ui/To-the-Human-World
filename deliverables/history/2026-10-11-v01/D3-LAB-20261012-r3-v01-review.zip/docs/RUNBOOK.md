# 运行与续接

仅在 `D:\taptap\To-the-Human-World-3D-Lab` 继续；先读 LAB_STATUS、行动记录、BLOCKERS 和哈希证据。唯一任务 `01a12c24-a725-712b-ba7d-df58430f5098`，不创建新任务/子代理，不联系其他窗口。

## 现在可以复跑的验证

在 Windows PowerShell：

```powershell
$env:PYTHONIOENCODING='utf-8'
python D:\taptap\To-the-Human-World-3D-Lab\tools\run_checks.py
python D:\taptap\To-the-Human-World-3D-Lab\tools\check_lsp.py
python D:\taptap\To-the-Human-World-3D-Lab\tools\finalize_evidence.py
```

第一条使用已有 Python 3.13 + 试验目录内复制的 Lupa Lua 5.4，运行真实业务和数学/面板回调测试。第二条使用已安装 EmmyLua 二进制，输出限 Lab，约 20 秒后关闭自身服务；不启动游戏。第三条只核对复制源及测试哈希，不覆盖源或重新复制。不要重跑 `snapshot_source.py` 来覆盖已适配的 Panels。

## 原生入口：已写入，启动受阻

入口 `scripts/main.lua`。正式支持路径的诊断命令如下，当前返回需要绑定的错误：

```powershell
taptap-maker preview status --target-dir D:\taptap\To-the-Human-World-3D-Lab --json
taptap-maker preview prepare --target-dir D:\taptap\To-the-Human-World-3D-Lab --json
```

这两条不是成功运行命令；本轮未启动任何试验 Runtime。不得复制正式 `.maker-mcp`、运行 init 或自行直启引擎绕过检查。先取得符合隔离边界的官方支持方式。原生运行恢复后，使用该方式启动唯一首次预览，记录 session/reload 身份；之后只刷新确认存活的试验会话。用户停止后不能自行重启。

## 解除阻塞后的操作验收脚本

1. 先用当前 Library 官方 Windows 支持流程将已有四张 PNG 放到 references/incoming，核验可读、哈希并实际逐张查看；修正空间/炉/船/网默认造型，保留稳定 ID。
2. 原生启动后检查 `[D3-LAB started]`、真实模型/材质/光照/中文文字显示，再检查资源错误，不能用进程存活代替 P0 通过。
3. Home 点击网兜，经门洞到 Seaside；点击船打开商店，购买海盐一次，验证余额/库存。重复点击和模态点击不得穿透。
4. 在独立新会话中继续按真实购买消耗到失败，检查失败不扣款；关闭商店，明确点击捕捞，返回 Home，点信纸阅读并剪词、重开。
5. 点炉子到 Brew，检查同一炉/架/桌视差与遮挡，然后返回 Home；导航前后对照业务快照。锅口只检查独立区域，本轮无投料玩法。
6. 在 960×540（16:9）、1260×540（21:9）、1024×768（4:3）分别检查三个镜头、模态长文滚动、返回和小物件命中。数学投影测试只覆盖 Home 五个物件中心，不能替代本项。
7. 正常速度录屏；若工具不支持，保存带时间连续帧与原始日志，声明不能证明流畅度。记录设备、原生分辨率、平均/最差帧耗时、资源缺失、模型/纹理统计。桌面结果不代表手机。

## 暂定外观与资源替换

所有场景形状、尺寸与 15 个静态材质是文字约束下的可调默认值，未经过最新版参考像素对照。没有使用历史主页贴图或整图平面伪装 3D。房间、门框、桌架、锅、码头均为几何；海面也是几何，远岸为简化球体，天空使用引擎 Dusk 预设。没有独立贴图、下载模型或 create_3d_asset 任务。

主要修正点：参考图真实构图比例、炉体剪影/把手/支脚、帆船造型、网兜透空关系、手绘纹理、木材与水面层次、原生灯光曝光和阴影。替换 `World` 网格与 `SceneView` 材质即可保留物件 ID、镜头与真实接口；不应重写库存或经济。
