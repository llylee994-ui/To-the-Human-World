-- 自动生成：scripts/debug/generate_numeric_v02.py；来源为已确认v02与定稿。
return {
    ["directRules"] = {
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_rested",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_rested",
            ["facts"] = {
                {
                    ["id"] = "e01_result_rested",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_rested",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_rested",
            ["facts"] = {
                {
                    ["id"] = "e01_result_rested",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_rested",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_rested",
            ["facts"] = {
                {
                    ["id"] = "e01_result_rested",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_rested",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_rested",
            ["facts"] = {
                {
                    ["id"] = "e01_result_rested",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_dream",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_dream",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_dream",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_dream",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_dream",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_dream",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_dream",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_dream",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_dream",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_dream",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_dream",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_dream",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fragmented_song_faded",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fragmented_song_faded",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fragmented_song_faded",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.4,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_mother_dream",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_mother_dream",
            ["facts"] = {
                {
                    ["id"] = "e01_result_mother_dream",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_017",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_walking_crates",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_walking_crates",
            ["facts"] = {
                {
                    ["id"] = "e01_result_walking_crates",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_018",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fish_choir",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fish_choir",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fish_choir",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_019",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_fish_choir",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_fish_choir",
            ["facts"] = {
                {
                    ["id"] = "e01_result_fish_choir",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_020",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_mother_unclear",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_mother_unclear",
            ["facts"] = {
                {
                    ["id"] = "e01_result_mother_unclear",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_021",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_mother_unclear",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_mother_unclear",
            ["facts"] = {
                {
                    ["id"] = "e01_result_mother_unclear",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_022",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_mother_unclear",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_mother_unclear",
            ["facts"] = {
                {
                    ["id"] = "e01_result_mother_unclear",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_023",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_passerby_a.lastResult",
                    ["value"] = "e01_result_mother_unclear",
                },
            },
            ["desc"] = "独立互斥区间 → e01_result_mother_unclear",
            ["facts"] = {
                {
                    ["id"] = "e01_result_mother_unclear",
                    ["important"] = true,
                    ["subjectId"] = "npc_passerby_a",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_e01_024",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_pa_01",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "dream",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "forget",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_departure_agreed",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_departure_agreed",
            ["facts"] = {
                {
                    ["id"] = "n01_result_departure_agreed",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_stayed_for_promise",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_stayed_for_promise",
            ["facts"] = {
                {
                    ["id"] = "n01_result_stayed_for_promise",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_started_learning",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_started_learning",
            ["facts"] = {
                {
                    ["id"] = "n01_result_started_learning",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_stayed_for_promise",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_stayed_for_promise",
            ["facts"] = {
                {
                    ["id"] = "n01_result_stayed_for_promise",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_departure_conflict",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_departure_conflict",
            ["facts"] = {
                {
                    ["id"] = "n01_result_departure_conflict",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_stayed_for_promise",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_stayed_for_promise",
            ["facts"] = {
                {
                    ["id"] = "n01_result_stayed_for_promise",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_departure_conflict",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_departure_conflict",
            ["facts"] = {
                {
                    ["id"] = "n01_result_departure_conflict",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_stayed_for_promise",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_stayed_for_promise",
            ["facts"] = {
                {
                    ["id"] = "n01_result_stayed_for_promise",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_luca.lastResult",
                    ["value"] = "n01_result_missed_place",
                },
            },
            ["desc"] = "独立互斥区间 → n01_result_missed_place",
            ["facts"] = {
                {
                    ["id"] = "n01_result_missed_place",
                    ["important"] = true,
                    ["subjectId"] = "npc_luca",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n01_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n01",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "brave",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_care",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_care",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_care",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_care",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_care",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_care",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_swallowed",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_swallowed",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_swallowed",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_escaped",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_escaped",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_escaped",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_swallowed",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_swallowed",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_swallowed",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_escaped",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_escaped",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_escaped",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_nora.lastResult",
                    ["value"] = "n02_candidate_doubted",
                },
            },
            ["desc"] = "独立互斥区间 → n02_candidate_doubted",
            ["facts"] = {
                {
                    ["id"] = "n02_candidate_doubted",
                    ["important"] = true,
                    ["subjectId"] = "npc_nora",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n02_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n02",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_hide",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_hide",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_hide",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_salt",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_salt",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_salt",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_hide",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_hide",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_hide",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_freeze",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_freeze",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_freeze",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_salt",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_salt",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_salt",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_freeze",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_freeze",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_freeze",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_ellie.lastResult",
                    ["value"] = "n03_candidate_protect",
                },
            },
            ["desc"] = "独立互斥区间 → n03_candidate_protect",
            ["facts"] = {
                {
                    ["id"] = "n03_candidate_protect",
                    ["important"] = true,
                    ["subjectId"] = "npc_ellie",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n03_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n03",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "safety",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "confusion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "curiosity",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_envy",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_envy",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_envy",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_017",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_018",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_019",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_020",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_021",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_022",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_play",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_play",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_play",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_023",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_024",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_025",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_026",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_027",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_028",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_029",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_030",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_tear",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_tear",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_tear",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_031",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_otto.lastResult",
                    ["value"] = "n04_candidate_past",
                },
            },
            ["desc"] = "独立互斥区间 → n04_candidate_past",
            ["facts"] = {
                {
                    ["id"] = "n04_candidate_past",
                    ["important"] = true,
                    ["subjectId"] = "npc_otto",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n04_032",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n04",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_talk",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_talk",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_talk",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_sad",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_sad",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_sad",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_sad",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_sad",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_sad",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_count",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_count",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_count",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_talk",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_talk",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_talk",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_sad",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_sad",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_sad",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_sad",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_sad",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_sad",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_cecilia.lastResult",
                    ["value"] = "n05_candidate_fork",
                },
            },
            ["desc"] = "独立互斥区间 → n05_candidate_fork",
            ["facts"] = {
                {
                    ["id"] = "n05_candidate_fork",
                    ["important"] = true,
                    ["subjectId"] = "npc_cecilia",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n05_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n05",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "appetite",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_sleep",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_sleep",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_sleep",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_pain",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_pain",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_pain",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_sleep",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_sleep",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_sleep",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_sleep",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_sleep",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_sleep",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_stop",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_stop",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_stop",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_stop",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_stop",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_stop",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_leon.lastResult",
                    ["value"] = "n06_candidate_split",
                },
            },
            ["desc"] = "独立互斥区间 → n06_candidate_split",
            ["facts"] = {
                {
                    ["id"] = "n06_candidate_split",
                    ["important"] = true,
                    ["subjectId"] = "npc_leon",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n06_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n06",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "steady",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "pain",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sleep",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_soft",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_soft",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_soft",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_discount",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_discount",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_discount",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_discount",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_discount",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_discount",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_acid",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_acid",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_acid",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_discount",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_discount",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_discount",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_acid",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_acid",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_acid",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_bea.lastResult",
                    ["value"] = "n07_candidate_bucket",
                },
            },
            ["desc"] = "独立互斥区间 → n07_candidate_bucket",
            ["facts"] = {
                {
                    ["id"] = "n07_candidate_bucket",
                    ["important"] = true,
                    ["subjectId"] = "npc_bea",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n07_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n07",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 1.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "envy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "sadness",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_child",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_child",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_child",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_slow",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_slow",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_slow",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_slow",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_slow",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_slow",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_wait",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_wait",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_wait",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_wait",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_wait",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_wait",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_military",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_military",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_military",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_military",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_military",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_military",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_military",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_military",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_military",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_military",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_military",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_military",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_wait",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_wait",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_wait",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_martin.lastResult",
                    ["value"] = "n08_candidate_wait",
                },
            },
            ["desc"] = "独立互斥区间 → n08_candidate_wait",
            ["facts"] = {
                {
                    ["id"] = "n08_candidate_wait",
                    ["important"] = true,
                    ["subjectId"] = "npc_martin",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n08_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n08",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "relax",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "calm",
                    ["source"] = "potion.effects",
                    ["value"] = 2.2,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "happy",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_doubt",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_doubt",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_doubt",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grace",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grace",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grace",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_doubt",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_doubt",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_doubt",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_good",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_good",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_good",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_hedge",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_hedge",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_hedge",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grace",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grace",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grace",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_hedge",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_hedge",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_hedge",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_agnes.lastResult",
                    ["value"] = "n09_candidate_grain",
                },
            },
            ["desc"] = "独立互斥区间 → n09_candidate_grain",
            ["facts"] = {
                {
                    ["id"] = "n09_candidate_grain",
                    ["important"] = true,
                    ["subjectId"] = "npc_agnes",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n09_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n09",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "reason",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_3",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_3",
            ["facts"] = {
                {
                    ["id"] = "n10_result_3",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_001",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_002",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_003",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_004",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_2b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_2b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_2b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_005",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_006",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_007",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_008",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_2a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_2a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_2a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_009",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_010",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_011",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_012",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_2b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_2b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_2b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_013",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1b",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1b",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1b",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_014",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_015",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
            },
        },
        {
            ["changes"] = {
                {
                    ["op"] = "set",
                    ["path"] = "world.npcs.npc_jacob.lastResult",
                    ["value"] = "n10_result_1a",
                },
            },
            ["desc"] = "独立互斥区间 → n10_result_1a",
            ["facts"] = {
                {
                    ["id"] = "n10_result_1a",
                    ["important"] = true,
                    ["subjectId"] = "npc_jacob",
                    ["value"] = true,
                },
            },
            ["id"] = "rule_v02_n10_016",
            ["priority"] = 0,
            ["ruleSetId"] = "rules_n10",
            ["unless"] = {},
            ["when"] = {
                {
                    ["op"] = "gte",
                    ["path"] = "recall",
                    ["source"] = "potion.effects",
                    ["value"] = 0.8,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "anger",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "fear",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "suspicion",
                    ["source"] = "potion.effects",
                    ["value"] = 0.6,
                },
                {
                    ["op"] = "gte",
                    ["path"] = "trust",
                    ["source"] = "potion.effects",
                    ["value"] = 1.2,
                },
            },
        },
    },
    ["factExclusionGroups"] = {
        {
            ["factIds"] = {
                "e01_result_rested",
                "e01_result_mother_dream",
                "e01_result_song_faded",
                "e01_result_mother_unclear",
                "e01_result_fish_choir",
                "e01_result_walking_crates",
                "e01_result_fragmented_dream",
                "e01_result_fragmented_song_faded",
            },
            ["id"] = "exclusive_v02_e01",
        },
        {
            ["factIds"] = {
                "n01_result_missed_place",
                "n01_result_stayed_for_promise",
                "n01_result_departure_conflict",
                "n01_result_started_learning",
                "n01_result_departure_agreed",
            },
            ["id"] = "exclusive_v02_n01",
        },
        {
            ["factIds"] = {
                "n02_candidate_doubted",
                "n02_candidate_escaped",
                "n02_candidate_swallowed",
                "n02_candidate_care",
                "n02_candidate_good",
            },
            ["id"] = "exclusive_v02_n02",
        },
        {
            ["factIds"] = {
                "n03_candidate_protect",
                "n03_candidate_freeze",
                "n03_candidate_hide",
                "n03_candidate_salt",
                "n03_candidate_good",
            },
            ["id"] = "exclusive_v02_n03",
        },
        {
            ["factIds"] = {
                "n04_candidate_past",
                "n04_candidate_tear",
                "n04_candidate_envy",
                "n04_candidate_play",
                "n04_candidate_good",
            },
            ["id"] = "exclusive_v02_n04",
        },
        {
            ["factIds"] = {
                "n05_candidate_fork",
                "n05_candidate_sad",
                "n05_candidate_talk",
                "n05_candidate_count",
                "n05_candidate_good",
            },
            ["id"] = "exclusive_v02_n05",
        },
        {
            ["factIds"] = {
                "n06_candidate_split",
                "n06_candidate_stop",
                "n06_candidate_sleep",
                "n06_candidate_pain",
                "n06_candidate_good",
            },
            ["id"] = "exclusive_v02_n06",
        },
        {
            ["factIds"] = {
                "n07_candidate_bucket",
                "n07_candidate_acid",
                "n07_candidate_discount",
                "n07_candidate_soft",
                "n07_candidate_good",
            },
            ["id"] = "exclusive_v02_n07",
        },
        {
            ["factIds"] = {
                "n08_candidate_wait",
                "n08_candidate_military",
                "n08_candidate_slow",
                "n08_candidate_child",
                "n08_candidate_good",
            },
            ["id"] = "exclusive_v02_n08",
        },
        {
            ["factIds"] = {
                "n09_candidate_grain",
                "n09_candidate_hedge",
                "n09_candidate_doubt",
                "n09_candidate_grace",
                "n09_candidate_good",
            },
            ["id"] = "exclusive_v02_n09",
        },
        {
            ["factIds"] = {
                "n10_result_1a",
                "n10_result_1b",
                "n10_result_2b",
                "n10_result_2a",
                "n10_result_3",
            },
            ["id"] = "exclusive_v02_n10",
        },
    },
    ["followupTemplates"] = {
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_e01_result_rested",
                "frag_e01_result_mother_dream",
                "frag_e01_result_song_faded",
                "frag_e01_result_mother_unclear",
                "frag_e01_result_fish_choir",
                "frag_e01_result_walking_crates",
                "frag_e01_result_fragmented_dream",
                "frag_e01_result_fragmented_song_faded",
            },
            ["id"] = "tpl_pa_01",
            ["letterId"] = "letter_pa_01_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n01_result_departure_agreed",
                "frag_n01_result_departure_conflict",
                "frag_n01_result_stayed_for_promise",
                "frag_n01_result_missed_place",
                "frag_n01_result_started_learning",
            },
            ["id"] = "tpl_n01",
            ["letterId"] = "letter_n01_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n02_candidate_good",
                "frag_n02_candidate_swallowed",
                "frag_n02_candidate_escaped",
                "frag_n02_candidate_care",
                "frag_n02_candidate_doubted",
            },
            ["id"] = "tpl_n02",
            ["letterId"] = "letter_n02_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n03_candidate_good",
                "frag_n03_candidate_hide",
                "frag_n03_candidate_freeze",
                "frag_n03_candidate_salt",
                "frag_n03_candidate_protect",
            },
            ["id"] = "tpl_n03",
            ["letterId"] = "letter_n03_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n04_candidate_good",
                "frag_n04_candidate_envy",
                "frag_n04_candidate_tear",
                "frag_n04_candidate_play",
                "frag_n04_candidate_past",
            },
            ["id"] = "tpl_n04",
            ["letterId"] = "letter_n04_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n05_candidate_good",
                "frag_n05_candidate_count",
                "frag_n05_candidate_sad",
                "frag_n05_candidate_talk",
                "frag_n05_candidate_fork",
            },
            ["id"] = "tpl_n05",
            ["letterId"] = "letter_n05_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n06_candidate_good",
                "frag_n06_candidate_pain",
                "frag_n06_candidate_stop",
                "frag_n06_candidate_sleep",
                "frag_n06_candidate_split",
            },
            ["id"] = "tpl_n06",
            ["letterId"] = "letter_n06_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n07_candidate_good",
                "frag_n07_candidate_soft",
                "frag_n07_candidate_acid",
                "frag_n07_candidate_discount",
                "frag_n07_candidate_bucket",
            },
            ["id"] = "tpl_n07",
            ["letterId"] = "letter_n07_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n08_candidate_good",
                "frag_n08_candidate_slow",
                "frag_n08_candidate_wait",
                "frag_n08_candidate_child",
                "frag_n08_candidate_military",
            },
            ["id"] = "tpl_n08",
            ["letterId"] = "letter_n08_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n09_candidate_good",
                "frag_n09_candidate_doubt",
                "frag_n09_candidate_hedge",
                "frag_n09_candidate_grace",
                "frag_n09_candidate_grain",
            },
            ["id"] = "tpl_n09",
            ["letterId"] = "letter_n09_followup",
            ["opening"] = "",
        },
        {
            ["baseFragmentIds"] = {},
            ["closing"] = "",
            ["fallbackFragmentIds"] = {},
            ["fragmentIds"] = {
                "frag_n10_result_3",
                "frag_n10_result_2a",
                "frag_n10_result_1a",
                "frag_n10_result_2b",
                "frag_n10_result_1b",
            },
            ["id"] = "tpl_n10",
            ["letterId"] = "letter_n10_followup",
            ["opening"] = "",
        },
    },
    ["fragments"] = {
        {
            ["coversFacts"] = {
                "e01_result_rested",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_rested",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_rested",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[早上是妹妹找围裙把我弄醒的。她怕吵着我就没点灯，找半天找不到，最后还是我爬起来拿给她。窗外刚有点亮，我这一觉睡得好，身上有劲，便顺手把昨晚剩的汤搁火上热了下肚。

今天在码头卸货没再出岔子，一起抬箱子的汉克还问我是不是好些了。我让他放心抬他的那头，别总打量我。

收工回来正好赶上补鞋铺还没关门。师傅把鞋底拆开，指给我看里面的线都烂透了。我坐在凳子上等，听他絮絮叨叨讲前几天那场大雨，一路听到他把线扎紧断好，我也没打半个瞌睡。

今晚鞋就搁在床边晾着，妹妹端锅过来时，不用再费劲绕开我那双伸在外面的脚了。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_mother_dream",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_mother_dream",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_mother_dream",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚又梦见娘在旧桌子旁补衣裳。

我坐在旁边帮她牵着线，她嫌我扯得太紧，伸手在我手背上轻拍了一下。我松了松手，她就接着缝，针尖从磨薄的布里穿过去，又快又密。

早上妹妹叫我时我还记着梦里的事，边穿鞋边跟她讲。妹妹听完笑了，说那件衣裳后来短得露手腕，娘想拆自己的旧袖子给我接长，可她自己的衣裳也是补了又补，最后接上去的布两边颜色都不一样。

说着说着差点耽误她去面包坊，我送她走到巷口才往码头走。今天身上有劲，歇脚时跟同伴说笑几句，心里还记挂着那件双色袖子，想着晚上回去再跟妹妹唠唠。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_song_faded",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_song_faded",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_song_faded",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚躺下没多久就睡过去了。早上听见妹妹在屋里起床的动静，我也跟着起来，就着凉水吃了两口硬面包就去码头。今天搬货顺当，清点箱数也没差错，歇下来时只想找桶水痛快喝几口。

晚饭后妹妹在水盆边洗碗，嘴里哼着娘以前常唱的那段调子。我听着熟，想跟着接两句，可哼到后半截怎么也记不起词，调子也拐不回去。

妹妹以为我没听清，转过头又放慢哼了一遍。我试了两次还是卡在同一个地方，干脆不哼了，拿过干布站在她旁边替她擦碗。

她问我今晚还烤不烤脚，我把鞋底翻过来给她看补好的新线。她摸了摸，叮嘱我明早出门看着点脚下的泥坑，别刚补好又泡烂了。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_mother_unclear",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_mother_unclear",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_mother_unclear",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[今早醒来胳膊腿都不僵了，去码头搬重货时，再没让旁边的汉克照顾我。可歇下来坐在木箱上，心里却总想着昨晚的梦，越琢磨越不是滋味。

昨晚梦里有个人坐在门口，膝盖上摊着件没缝完的衣裳。我走过去，她抬起头看我，好像等着我叫她。我看她面熟得很，可站在那儿愣了半天，张着嘴就是喊不出名字。

早上吃稀饭时我跟妹妹讲起这事，她停下筷子问我是不是梦见娘了。我本想应声，可仔细去想，连梦里那人的脸和说话声都模糊得像隔着雾，心里慌得厉害，只能让妹妹多给我讲讲娘以前的事。

她讲起娘如何在油灯下穿针，讲起那件接长了袖子的旧布衫。这都是梦里的事情，可我自己回想又想不起来。

妹妹收拾碗筷准备走，我还想听她再多说几句，伸手把她手里的空碗接过来清洗，让她坐着讲完再出门。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_fish_choir",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_fish_choir",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_fish_choir",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚梦见娘站在码头边上，面前整整齐齐排着一溜大白鱼，全都张着嘴等她领头唱。

她拍着手打拍子，前面的鱼倒跟得上，就末尾那条大胖鱼总是慢半拍。我想过去帮她把那条鱼抓出来，抱起来才发现那鱼身上全是滑溜溜的黏液，脱了手掉在地上瞎蹦腾。娘还嫌我挡着鱼看她的手势，嚷嚷着让我快放回去。

早上把这事讲给妹妹听，她正嚼着面包，笑得直咳嗽，渣子掉了一桌。她说娘以前带我俩唱调子也是这样，我老是抢拍子唱错，反倒去怪妹妹没跟上。

今天在码头搬鱼箱，看着箱子里堆的死鱼，我忍不住多看了两眼。旁边的同伴打趣问我是不是想顺一条回家煮汤，我摆摆手，一把将箱子扛上肩。干了一整天活都没觉得乏，晚上回铁锚巷，还要跟妹妹比划比划母亲指挥众鱼的模样。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_walking_crates",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_walking_crates",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_walking_crates",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚梦见我又回到了码头，娘手里捧着个大账本坐在搬货的木台子上，催我赶紧把搬完的货报给她算工钱。

我跟她说我不识字看不懂账本，她白了我一眼，说让我只管报箱数，字由她来写。我点着头去数，刚数到十二，后头三个大木箱突然伸出几条木腿，撒丫子就往栈桥底下跑。我赶忙追过去抱住一个，另外两个又顺着水洼溜了。

娘抱着账本坐在台上笑，笑够了才起身帮我把最小的那只箱子拦在路中间。我解下裤腰上的麻绳，把这几只长腿的箱子一个个硬给拴成一串，这才抹抹汗重新数。

睁眼时天已经大亮，睡得踏实。到了码头，看着堆得老高的货物，我心里还记着昨晚数的数。今天卸完货跟工头清点，箱子都老老实实码在原地，报完最后一个数也没跑。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_fragmented_dream",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_fragmented_dream",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_fragmented_dream",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚梦里颠颠倒倒的全是鱼。一会儿是在深海里游，一会儿又全排在码头结工钱的木桌前。

最小的那条小杂鱼嫌工头给的铜板少，贴着桌角往前挤，硬是不肯走。工头拍着桌子让它再去搬一箱来，它就在桌沿上猛拍尾巴，拍得上面的铜钱叮当响，撒了一地。我蹲在底下帮着捡铜钱，捡着捡着，手里的硬铜钱又变成了浅水滩里滑溜溜的石子。

早上醒来脑子里就剩下这点零碎片段，跟妹妹说的时候我自己都觉得没头没尾。她笑问我那条小鱼到底领到工钱没有，我说还没等工头数清钱，我就被邻街的鸡叫声吵醒了。

今天搬了一整天货，头一点没昏。中午吃饭时汉克还凑过来，问我今天怎么没犯恶心。]=],
        },
        {
            ["coversFacts"] = {
                "e01_result_fragmented_song_faded",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_e01_result_fragmented_song_faded",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "e01_result_fragmented_song_faded",
            },
            ["templateId"] = "tpl_pa_01",
            ["text"] = [=[昨晚的梦碎得很，一会儿是深水里游着的鱼，一会儿又排到了码头结工钱的木桌前。最小那条嫌工头给的铜板少，贴着桌角往前挤，不肯挪窝。工头拿手背敲桌子赶它，它偏在桌沿上甩起尾巴，把铜钱拍得叮当响，滚了一地。我蹲下去帮着捡，捡着捡着，手里的铜钱变成了浅水滩里滑溜溜的石子，再往后就断片了。

早上我跟妹妹讲这个梦，讲得没头没尾，她听得也稀里糊涂，笑问我那条小鱼后来领到工钱没有。我说没等着看，反正没数清。

今天在码头搬货，头一点没昏，一上午都跟得上趟。中午汉克凑过来，问我这两天吃了什么养神的药，我说没吃药，就是睡整了。他说那你可得一直这么睡下去。

晚饭后妹妹在水盆边洗碗，嘴里又哼起娘以前常唱的那段调子。我听着还是熟，跟着接了两句，后半截的词却怎么也捞不上来。妹妹怕我没跟上，从头放慢再唱了一遍，我跟了两遍，还是在那儿断住。以前整段我都唱得下来，如今只剩一头一尾，中间空着。我把她手里的碗接过来擦，没提这回事。

她问我今晚还烤不烤脚，我把鞋底翻过来给她看补好的新线。她摸了摸，叮嘱我明早出门看着点脚下的泥坑。我应了一声。擦完碗，我又在心里哼了一遍，还是断在半路，也就算了。]=],
        },
        {
            ["coversFacts"] = {
                "n01_result_departure_agreed",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n01_result_departure_agreed",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n01_result_departure_agreed",
            },
            ["templateId"] = "tpl_n01",
            ["text"] = [=[大清早铺子还没上客，炉膛里的柴火刚点着。我把老板堵在后厨灶间，深吸了一口气，把在心里滚了三天的硬话砸了出来：“老板，我想清楚了，我决定去给抄写员当学徒。”

他手里正捏着刮板，听完动作停了停。他没有像昨天那样摔抹布，也没当笑话讽刺我，只是转过头，皱着眉盯了我好一会儿，沉着嗓子问：“想真切了？不后悔？”

“想真切了。”我说，背挺得笔直。

老板没再吭声。他把手撑在洒满白粉的面案上，粗粝的手指有一搭没一搭地叩着木板，那是在算计工时和人头：算每天几百个面包的分量、算找新伙计要贴多少告示、算得花多少工钱。过了好半晌，他吐了口浊气，头也不抬地说：“行。再留一个月，等新伙计招来，你把他手艺带熟了再走。”

我站在原地，原本肚子里还备好了几句剖白心迹的话，甚至想说“这最后一个月工钱您看着扣一半都成”，可他已经转过身去，弓着腰拿铁钩拨弄炉膛里的火星了。通红的火光映在他脸上，像一堵严严实实的墙，把什么交情都挡在了外头。

中午趁着歇脚的当口，我一口气跑到老先生的抄写铺回话。老先生摘下厚厚的眼镜擦了擦，眼角露出点笑纹，点了点头说：“那就月底过来，先把旧东家的活计理利索，做事要有始有终。”

夜里回到小阁楼，我把床板底下那几页纸样抽出来，想塞进收拾好的旧包袱里。就着月光，我又把那几行字摸了一遍，最后还是咬咬牙，重新压回了床底下。]=],
        },
        {
            ["coversFacts"] = {
                "n01_result_departure_conflict",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n01_result_departure_conflict",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n01_result_departure_conflict",
            },
            ["templateId"] = "tpl_n01",
            ["text"] = [=[今早我刚起了个头，话还没落定，老板整个人就炸了。

他一把将手里的粗面团摔得粉碎，指着我的鼻子大骂，说我翅膀硬了就想飞，说我忘恩负义、白吃了铺子里四年的干饭。

那些话太难听，像淬了毒的鞭子一样抽在我脸上。这四年来咽下的委屈轰地一下全冲上了脑门，我再也忍不住了，红着眼一条一条冲他吼了回去：“我白吃你的饭？这三年每天天不亮是谁开的门？！早市柜台账目乱成一团是谁一笔笔记下来的？！你喝得烂醉睡到日上三竿，又是谁守着炉子没让铺里焦过一个面包？！”

他被我顶得脸上一阵青一阵白，反手抄起案上油腻的湿抹布劈头盖脸砸在桌上，指着门冲我咆哮：“滚！现在就给我滚！晨炉面包坊不养你这种白眼狼！”

当天下午，我就把阁楼上自己的破被褥和换洗衣裳卷成了一个包袱，头也没回地迈出了铁锚巷。

老先生见我提着行李找来，吓了一跳。问明原由后，他叹了口气，没多责备，腾出后屋堆杂物的小隔间让我先挤几晚，说明天一早就正式跟着他认纸磨墨。

夜里躺在硬邦邦的木板床上，外头下着冷雨，我浑身的血还在突突地跳，恨意顶着天花板。可翻了个身，指尖无意间摸到自己那件打满补丁的旧夹袄，脑子里冷不丁又撞进了前年冬天——我高烧不退，老板骂骂咧咧从自己屋里抱出一床厚棉被甩在我身上，又下楼替我熬了一大碗姜汤。

胸口像被塞进了一大团没发酵的死面疙瘩，又堵又硬，泛着酸疼。

这学徒我铁了心是要当下去的，谁也拦不住。只是我想着，等过些日子老板的气彻底消了，我还是得买上一包好烟丝走回铁锚巷，当面把我吼出的那几句狠话收回来。]=],
        },
        {
            ["coversFacts"] = {
                "n01_result_stayed_for_promise",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n01_result_stayed_for_promise",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n01_result_stayed_for_promise",
            },
            ["templateId"] = "tpl_n01",
            ["text"] = [=[今早铺子里只有我们俩，我深吸一口气刚要摊牌，老板却像是早就料到了。

他擦了擦手，脸上忽然堆起一种我从没见过的热络笑容，快步走过来拍了拍我的胳膊：“行了行了，卢卡，昨天是我说话没过脑子，你别往心里去。我知道你心里憋着股劲儿。”

我愣住了，准备好的一肚子话全卡在喉咙里。

“这么着，下个月起，你的工钱我给你涨两成，跟外头正经学徒一个价。”他压低声音，冲我眨了眨眼，那神情仿佛在恩赐一件天大的宝贝，“你不就喜欢摆弄那些字和数么？行，往后铺里的账本我亲自教你管，等熬过这个冬天，明年一开春，柜台的大账本全归你摸。”

“账本”两个字像有魔力一样，重重砸在我心尖上。在铁锚巷，一个泥腿子伙计能名正言顺管账，那是天大的体面。说实话，那一刻我胸口发热，我全信了。

当天下午，我硬着头皮挪到了老先生门前。面对老先生关切的目光，我舌头像打了结，吞吞吐吐半天，只挤出一句干瘪瘪的“我不去了，铺子里走不开”。

老先生定定地看着我，厚镜片后的目光锐利得像能照出我的软弱和动摇。他什么也没问，只是极轻地叹了口气，把那扇充满墨香的木门缓缓合上了。

我失魂落魄地走回面包坊，上楼就把床板底下那几张视若珍宝的字狠命塞回了最深处。

第二天清早，我早早把面揉好，搓着手凑到老板身边，小声问起学看大账本的事。

老板正在往炉子里添炭，眼皮都没抬一下，随口敷衍道：“哎呀急什么，没看铺子里忙得脚后跟打后脑勺吗？等忙完这阵子再说吧。”

说话的时候，他的眼睛一直没往我这边落。

我僵立在滚烫的灶台前，死死盯着他那肥厚、冷漠的后脑勺，盯了足足有半炷香的工夫。外头天光大亮，买早点的熟客开始拍门叫喊。我垂下眼，默默抓起挂在钩子上的围裙，系紧了带子，把整张脸重新埋进了白生生的面粉雾里。]=],
        },
        {
            ["coversFacts"] = {
                "n01_result_missed_place",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n01_result_missed_place",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n01_result_missed_place",
            },
            ["templateId"] = "tpl_n01",
            ["text"] = [=[那几天我真觉得自己是个能撑起大局的角色，两头我都答应得滴水不漏。

我对老板信誓旦旦：“您放心，一日为师，我绝不撂挑子，肯定手把手把新来的学徒教到能独当一面我再走。”

扭头跑到老先生那里，我也拍着胸脯保证：“先生，我把铺子里的活计料理得差不多了，很快就过来报到！”

我以为自己算无遗策，两头的情面和前程都能稳稳攥在手心里。

可现实根本容不得你两头讨好。新招来的学徒笨得像块石头，教他认秤砣他能把磅和两看得岔，看火候能把整炉上等白面包烤成黑炭，连记个订货单子都要我一句一句在耳朵边吼。我每天忙得像个陀螺，两脚不沾地，身上永远挂着面粉和汗泥。

终于到了老先生给的最后期限。那天清晨我就该过去报到的，可偏偏赶上新学徒头一回独立开炉。我守在灶前寸步不离，满脑子都是“等这炉麦香浓了我就走、等帮他挑完第一炉我就去”。

等我把最后一批焦黄的面包挑出炉膛，在水盆里匆忙洗净手上的生面团、解下围裙冲出铁锚巷时，日头早已经沉甸甸地偏向了西边的城墙。

气喘吁吁跑到老先生家门口，我的脚步猛地刹住了。

屋门开着，台阶前站着一个二十岁上下的年轻人，身上穿着一套浆洗得笔挺、干干净净的青色细布长衫，脚边搁着齐整的行李箱笼。那是行会管事正式荐过来的后生。

老先生正领着他往里走，听见动静回过头，看见满头大汗、袖口还沾着白粉的我。

老先生在台阶上站定，目光平静得像一潭死水，只淡淡说了一句：“卢卡，等到晌午不见你来，名额就给了别人。”

门“吱呀”一声关严了。

我一个人站在逐渐泛青的暮色里，冷风吹透了汗湿的单衣。]=],
        },
        {
            ["coversFacts"] = {
                "n01_result_started_learning",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n01_result_started_learning",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n01_result_started_learning",
            },
            ["templateId"] = "tpl_n01",
            ["text"] = [=[去见老先生的那天早晨，我胸口其实憋着一股暗劲儿。这四年里我替整条巷子写了上百封家书，街坊们人人都夸我字写得漂亮、脑子灵光。我跨进老先生门槛的时候，胸脯挺得老高，急着想在这位饱学宿儒面前露一手，证明自己不是个只会搬烤盘的粗鄙伙计。

老先生倒没说什么，随手从案头抽出一张泛黄发硬的羊皮纸，递给我一柄削好的鹅毛笔：“这是官署送来备存的港口租借契文，字迹有些褪了。你先照着底下空处，把前头半页临摹一遍给我看看。”

我信心满满地蘸饱了墨水，挽起袖子就落了笔。

可才写出头两行，我手底下的笔尖就猛地滞住了。

那纸上的字根本不是我平时写惯的家常白话。密密麻麻的墨迹里，充斥着大段大段生僻古怪的行会律条、拉丁缩写，以及层层叠叠的法律定式。好多个字昂着头横在我眼前，每一笔每一划我都觉得似曾相识，可连在一块儿，我一个字的意思都吃不透。墨水在笔尖凝成了圆坨，迟迟落不下去，在昂贵的羊皮纸上晕开了一个尴尬的黑点。

一股热血轰地一下冲上头皮，我的脸颊烫得像是贴在了面包炉的铁门上。

“纸太花哨了”、“这屋里背光、窗子太暗看不清”……无数句狡辩的托词像滚水一样在嗓子眼里冒泡，只要张嘴就能吐出来遮羞。

老先生慢条斯理地端起粗瓷茶杯抿了一口，将杯子轻轻搁在桌案上，发出清脆的一声响。他就那么静静地坐在光影里，透过厚厚的镜片看着我，不催促，也不拆穿。

屋子里静得只有外头穿堂风的声音。

我的手抖得厉害，掌心里全是汗。良久，那股自以为是的傲慢终于被一点点碾成了碎渣。我咬着牙，慢慢把鹅毛笔横放在砚台边，双手将那张羊皮纸平平整整推回老先生面前，低下头去：

“先生……这些字，我认不全，文法我也不懂。您要是肯收我，请从头教我吧。”

老先生看着我泛红的眼眶和低下的脑袋，嘴角微微动了动，眼角的皱纹舒展开来。

他伸手敲了敲对面的小木凳：“坐下吧。把腰挺直了。”

那天上午，他没有让我去碰那些华丽的契文，而是翻开了一本泛黄发毛的启蒙字帖。在满屋清苦的墨香里，我坐在木凳上，老老实实从第一行最简单的字母开始，一笔一划地重新学起。]=],
        },
        {
            ["coversFacts"] = {
                "n02_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n02_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n02_candidate_good",
            },
            ["templateId"] = "tpl_n02",
            ["text"] = [=[他推门进屋的时候，外头天刚擦黑，靴面上结着一层厚厚的干白海盐和泥灰。

我没去翻他的行囊，也没急着打听船上的事，先拧了一把滚烫的热粗布巾子塞进他手里，只轻声问了句：“路上颠簸得厉害吧？”

他擦着脸，长长舒了口气。我把热腾腾的汤锅端上桌，揭开盖子，热汽一下子把两人的眉眼都蒙上了白雾。他端起粗瓷碗闷头喝了几大口，喝到一半，自己伸手从盐罐里添了小半勺，咂着嘴笑：“妈，还是你煮的这个味儿，一点儿都没变。”

我坐在他对面，就着昏黄的烛光看他狼吞虎咽。趁他低头的当口，我顺手把他的旧呢褂子领口翻过来摸了摸——果然，边儿全让海风和绳缆给磨得起毛了。我说：“踏实吃，吃完了搁在案上，娘夜里给你重新走几道暗线。”

他咧开嘴笑了，痛痛快快把手里的空碗往前一推：“好！那您再给我添一勺满的！”

那顿饭娘儿俩直吃到二更天，桌上的油灯芯我都伸手剪了两回。他眉飞色舞地跟我讲海上的浓雾、吃人的大鱼，还有他亲手刨出来的新龙骨。很多大船上的机关我这辈子都听不明白，可他说什么，我都安安静静地听着，抿着嘴冲他点头。

临睡前吹灯的时候，他走过去，伸手把那张高背木椅轻轻往饭桌边挪了挪，摸着发亮的木扶手说了一句：

“走了这么多码头，还是咱家里这张老椅子坐着最稳当。”]=],
        },
        {
            ["coversFacts"] = {
                "n02_candidate_swallowed",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n02_candidate_swallowed",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n02_candidate_swallowed",
            },
            ["templateId"] = "tpl_n02",
            ["text"] = [=[他跨进门槛的那一刻，我脸上是笑着迎上去的，可胸口却像拉紧了一根细鱼线，绷得生疼。

我盛了满满一碗汤递过去，他捧着碗，边喝边跟我念叨这趟在船上给甲板换木梁的事。我坐在对面听着，看着他被海风吹得发黑起皮的脸，那股压了整整两年的慌乱猛地就撞了上来——“那这一趟歇几天？下趟又要跟着大船往哪儿漂？”

这话已经顶到了舌尖上，几乎就要脱口而出。我牙齿一咬，硬生生把它咽回了肚子里，咽得嗓子眼发紧。嘴唇动了动，吐出来的却是一句干瘪瘪的：“……汤咸不咸？不够我再给你添点水。”

那一顿饭，我前前后后起身给他添了三回热汤，可除了添汤，我几乎没敢再多说半句整话。

孩子到底是个心细的，喝完最后一口，他抬头瞧着我，笑着问：“妈，平时信里不是攒了一肚子街坊闲话么，今天怎么不大爱吭声了？”

我避开他的眼神，抬手擦了擦围裙：“白天窗根底下接的活儿太赶，改裤脚费神，嗓子累得发干。”

夜里在灶台边收拾碗筷，两只粗瓷碗和木勺子，我心不在焉地来回理了两次才摆整齐。

这顿饭到底是平平常常地吃完了，谁也没红脸，谁也没摔门。]=],
        },
        {
            ["coversFacts"] = {
                "n02_candidate_escaped",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n02_candidate_escaped",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n02_candidate_escaped",
            },
            ["templateId"] = "tpl_n02",
            ["text"] = [=[锅里的热汤端上桌的时候，我心里明明千遍万遍地告诫过自己：把嘴闭紧，千万别提找活，千万别提银钱。

可他喝了几口汤，放下面包，兴致勃勃地提起下一趟船要跟着大商队往更远的海上去，甚至要穿过没风的死水峡湾。

“远海”这两个字像针一样猛地扎在我心尖上。隔壁老木匠的儿子当年就是死在远海的礁石上的，两年来我日夜悬着的那块巨石，轰的一声全砸塌了，我脑子一热，脱口就问了出来：

“跑那么远的海……东家一个月到底能给你几个工钱啊？”

话音落地的瞬间，整间屋子死一样寂静。

艾文脸上的笑意一点一点冻住了。他手里的铁勺在粗瓷碗沿上“当啷”轻磕了一声，慢慢放了下来。他看着我，眼底全是疲惫和发红的血丝：“妈，我这才刚进家门，靴子上的土都还没抖落呢。”

“我……我不是那个意思！”我心里一慌，急着想把话往回圆，可手忙脚乱之中，嘴里却越描越黑，“我就是想着，隔壁那家面包作坊前天刚贴了招工的告示，风吹不着雨淋不着的，你手艺那么巧，要是能……”

他没有发火，甚至连一句顶撞的话都没说，只是闭上嘴，低着头，一口一口极慢地把碗里剩下的残汤咽了下去。

喝完，他站起身，拍了拍裤腿上的浮灰：“船坞里还有两根料子没点完，我先回屋歇了。”

门“吱呀”一声轻轻掩上，堂屋里冷清得能听见灯油燃烧的细微毕剥声。

我一个人僵坐在冰凉的桌边。昏暗的油灯下摆着两只旧瓷碗，一只已经见底了，另一只却还冒着微弱的热气，那是刚才趁他说话时，我高高兴兴替他添上的第二碗。]=],
        },
        {
            ["coversFacts"] = {
                "n02_candidate_care",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n02_candidate_care",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n02_candidate_care",
            },
            ["templateId"] = "tpl_n02",
            ["text"] = [=[他推门进屋的那一刻，我笑得合不拢嘴，一把接过他肩上沉甸甸的帆布行囊，连声催他快去铜盆边洗手。

饭桌上，热气腾腾的肉汤和刚出炉的麦面包早就摆得齐齐整整。艾文瞧着那一整只大陶锅，笑着说我煮了足足三个人的分量。我哪肯听他的，只嫌他脸颊凹了下去，切下一大块抹了厚厚猪油的面包硬塞进他手里。

头一碗汤他刚喝到一半，抹了抹嘴角，高高兴兴跟我讲起上个月在船坞换主龙骨的事。我心里欢喜得不行，脚底下却闲不住，赶忙起身去灶台边给他再舀一大勺热的。等我端着陶碗小跑着回来，他已经说到了几十个水手怎么合力把湿木梁吊上甲板，我错过了前半截，只得拉开椅子催他从头再讲一遍。

他倒是有耐心，咽下面包又重新起了个头。可我坐在对面，眼睛一瞟，冷不丁瞧见他左边袖口裂开了一道寸长的大缝，露出了里头磨红的皮肉。我手一伸，下意识就捏住了那块破布头：“好孩子，你嘴里先嚼着，娘去拿顶针给你把这儿走两道暗线，省得待会儿一抬胳膊又给扯大了。”

“妈，吃完了再弄吧，”他把勺子停在碗沿上，叹了口气看着我，“您先坐下。”

我嘴里连声应着“好好好”，可身子骨根本不听使唤，一转头就又挪到了窗根底下翻针线匾子。好不容易把粗麻线穿进了针鼻，我脑子里猛地一激灵：坏了，西屋里那床晒透了的芦花被还没给他铺开呢！

我顺手把针线往桌角一撂，小跑着钻进里屋，又是抖被单又是拍枕头，弄得满屋子灰。外头隐隐传来艾文喊我的声音，我忙不迭拍着围裙跑出来，急声问：“怎么了？是不是汤放凉了？不够锅里还有！”

艾文已经把铁勺搁下了。他坐在桌边，就那么直愣愣地抬眼看着我，眼神里透着一股说不出的乏意：

“够了，妈。您瞧瞧，您自己面前那碗汤，现在一勺都还没动呢。”

我愣了一下，讪讪地坐下来，低头匆匆抿了两小口。一抬眼，瞧见他那只大粗瓷碗见了底，我两只手又不由自主地伸向了长柄汤勺——他小时候每回喝汤都要添第二碗，这我哪能忘？

满满一勺浓汤刚舀出来，艾文却伸手把自己的空碗往回缩了缩，避开了我的勺子。

“真饱了，妈，”他苦笑着拍了拍肚皮，“您瞧，我连皮带扣都松开一格了。”

他撑着桌子站起身，把自己的空碗端回灶台，又转过身，把我面前那碗早就凝了油皮的冷汤端起来，重新搁在灶火上替我温热了一遍。

那一瞬间，我心口泛起一阵说不出的懊恼和发虚。我从他进门起就前后脚忙个不停，又是喂饭、又是张罗被褥针线，可整整一个晚上，我甚至连他讲的那根大木梁到底安在船头还是船尾都不知道。

我接过他替我热好的汤碗，伸手轻轻拽了拽他的袖口，语气几乎带着点讨好：“艾文……方才那条船上的事，讲到哪儿了？你坐下，娘这回真不乱跑了，娘坐着听你说。”

他站在桌边，冷不丁打了个大大的呵欠，抬手揉着通红的眼角，疲惫地笑了笑：

“明天再讲吧，妈。在海上颠了整整一个月，今天实在熬不住了。”

他转过身，拖着沉重的步子进了里屋去睡。

我一个人呆呆坐在昏暗的堂屋里，隔着薄薄的木门，听见他在里头扬声问我枕头搁在哪儿。

“就在床头木柜上放着呢。”我大声回了一句。]=],
        },
        {
            ["coversFacts"] = {
                "n02_candidate_doubted",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n02_candidate_doubted",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n02_candidate_doubted",
            },
            ["templateId"] = "tpl_n02",
            ["text"] = [=[他推门进屋的那一刻，我高高兴兴把炖了很久的肉汤端上桌。

艾文大口喝着，脸上挂着笑，同我讲起这一趟跟着大船出海其实顺当得很，掌舵的老舵工看他机灵，闲下来还教他在海图上认了几处要命的暗礁。

可我坐在桌对面，死死盯着他手肘上那截磨得发白的破布，胸口那团疑云怎么也散不开。这孩子打小就嘴硬，信里回回都写着“万事顺遂”，可海上的风浪多凶险、船上的大副多苛刻，他在外头真要是遭了罪、挨了欺负，哪一回肯老老实实同家里人吐露半句？

沉甸甸的帆布行囊就歪倒在门槛边。我借着起身的工夫，嘴上念叨着“给你找件干爽的换洗褂子”，手底下就自作主张地解开了外头绑得结结实实的麻绳扣。

包袱一扯开，最上头就裹着一件洗得发硬的粗布褂子。我抖开一看，两边腋窝底下补了巴掌大一块粗麻布，针脚歪歪扭扭；再往下摸，底下的两双厚线袜子，脚后跟那一块磨得薄如蝉翼，早就能透光了。

我心口一紧，攥着破衣服转过身去质问他：“艾文，你在船上到底过的是什么日子？这衣裳怎么能糟践成这副破烂模样？东家是不是连喘口气的工夫都不许你歇？！”

艾文夹菜的动作僵住了。他慢慢放下手里的陶碗，耐着性子解释：“妈，我是船上的木工，整天要在大梁底下钻来钻去，磨破衣裳是常有的事。袜子也是穿了两个年头没舍得扔罢了。”

听了这话，我心里的火气和惶恐反倒烧得更旺了。我把那件破褂子平摊在自己大腿上，低着头，粗粝的手指一寸一寸、神经质地摸索过去，恨不得把里头的线缝全给翻开，好查出他到底瞒了我多少事。

“妈，您有什么话当面问我就成，”艾文的声音冷了下来，“别翻我的包。”

我猛地抬起头，脸上还强挂着做母亲的笑：“我是你亲娘！生你养你一场，做娘的看一眼儿子的行囊，有什么看不得的？我还能害了你不成？！”

他站起身大步走过来，伸手想把褂子夺回去。我偏不松手，两边一扯，我反手一把死死攥住了他伸过来的手腕，不由分说把他的粗布袖口狠狠往上一推——

泛青的小臂上，赫然横着两三道早己愈合的暗红浅疤。

我像抓住了什么铁证一样，眼眶通红地逼问他：“你还敢说你过得好？！这道印子是怎么来的？是谁打的？真是搬木头刮的吗？！艾文，你在外头要是叫哪个恶人给欺负了，你必须跟娘说明白！”

艾文站在阴影里，浑身紧绷得像块石头。他猛地一发力，把自己的手腕从我干瘪的掌心里狠狠抽了回去。

他脸上原本那点回家的笑意，这一刻彻底荡然无存了。

他垂着眼看着我，一字一句地说：“妈，进门到现在，您问一句，我答一句。可我答完了，您心底里从头到尾就没信过一个字。既然您认准了我满嘴谎话……那您还非逼着我坐在这儿说什么？”

“我、我是为你好啊！”我心里又慌又乱，手足无措地站在桌边抹眼泪，急着替自己辩解，“你从小就报喜不报忧，娘挂念你整整两年，难道当娘的在家里连多嘴问一句的资格都没了吗？！”

他没再跟我大声争辩半个字。

他只是咬着牙，一言不发地蹲在冰凉的门槛边，把我刚才翻得乱七八糟的破衣烂衫，一件一件重新叠好、塞回包袱里去。最后，他甚至从我僵硬的手里，轻轻把那件磨破的粗布褂子也给抽了回去。

看着他那副冷漠的背影，我整个人慌得快要站不住了，亦步亦趋地跟在他身后，近乎哀求地小声念叨：“艾文，汤还热着呢……你先回桌边把饭吃了，娘不问了，娘往后一句都不多嘴了，成不成？”

他站起身，沉默地走回桌边，端起那只大瓷碗，仰起脖子一口气把剩下的肉汤全咽了下去。桌上的热面包，他碰都没碰一下。

咽完最后一口，他拎起收拾好的行囊，头也不回地大步迈进了里屋，“砰”的一声，把那扇木门给死死掩上了。

我像个做错了天大事情的孩子，失魂落魄地走到紧闭的门前，抬手轻轻叩了叩门板：“艾文……你的袖子都裂开了，总得让娘给你补一针再睡啊……”

隔着厚厚的木板，里头死一样寂静。

良久，才传来他闷闷的声音，冷得像港口深冬的海水：

“不用了。明天我自己缝吧。”]=],
        },
        {
            ["coversFacts"] = {
                "n03_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n03_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n03_candidate_good",
            },
            ["templateId"] = "tpl_n03",
            ["text"] = [=[早上天刚亮，我就把大篮子跨在胳膊上准备出门。娘在后头大声喊：“艾莉，千万别把盐给落下了啊！”我脆生生地应了一声。

一过小石桥拐个弯就是集市啦。我照着娘画的路线走，一步都没走岔，神气极了！

蓝围裙叔叔的摊子前头正好空着一块平地，我蹲下来把大萝卜一根一根排开，排得整整齐齐、白白胖胖的。有人凑过来问价钱，我心里咚咚跳了一下，但马上大声把娘教我的数报了出来，一点儿都没磕巴！收铜板的时候我仔仔细细数了两遍，才妥妥当当揣进小兜里。

斜对面有个卖小铜铃铛的摊子，晃起来叮当叮当响。我真想过去问问摊主，铃铛怎么没长在黄牛的脖子上呢？不过我摸了摸兜里的盐钱，还是忍住了脚，一步都没乱跑。

嘿，大萝卜全卖光啦！篮子一下子变得轻飘飘的。我去买盐的时候，两只手规规矩矩地拎着提梁，一整路都没有缩着脖子去抱它挡脸！

一回到家，我先把白花花的盐包举得高高的给娘看，又把空篮子倒过来朝她使劲抖了抖——看，一根萝卜也没剩下！娘笑眯眯地夸我真能干。天哪，我心里那块甜滋滋的地方简直要冒泡泡了！]=],
        },
        {
            ["coversFacts"] = {
                "n03_candidate_hide",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n03_candidate_hide",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n03_candidate_hide",
            },
            ["templateId"] = "tpl_n03",
            ["text"] = [=[早上我还是把篮子背出门了。路上走得好好的，可一扎进集市，黑压压全是大人，我的心又开始慌了。我先在路边靠着墙站了好一会儿，等腿不发软了，才磨磨蹭蹭挪到蓝围裙叔叔旁边。

我刚把萝卜摆开，就有个高个子叔叔走过来问价。我脑子里嗡的一下，两只手又自作主张地把大篮子举了起来，直直挡在鼻子前面，只露出一双眼睛看人。我憋得脸通红，嘴巴张了半天才把价钱挤出来。还好买菜的人没笑话我，蓝围裙叔叔也没催我。

萝卜最后倒是一根不剩地卖出去了，铜板我也数得准准的，可我心里一点儿都不高兴。

回来的时候我故意绕开了卖铃铛的摊子，我怕自己要是走过去就迈不动腿，一个忍不住把盐钱花了可怎么整。盐倒是买到了，可一回到屋里，我就气鼓鼓地把那个破篮子底朝天扣在床头。我明明在心里说好了不要躲的！两只手怎么就那么不听话呢？那股窝囊和不服气的劲儿，堵在心口大半天都散不掉。]=],
        },
        {
            ["coversFacts"] = {
                "n03_candidate_freeze",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n03_candidate_freeze",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n03_candidate_freeze",
            },
            ["templateId"] = "tpl_n03",
            ["text"] = [=[早上我还是硬着头皮出门了。可一走到集口，人多得像麦浪一样挤来挤去，闹哄哄的声音全往我耳朵里钻。我站在路口呆呆地看路边的木牌子，一块、两块、三块……数着数着，脑子里全乱套了，我连该往哪边拐都拿不准了。娘画的那张纸明明就压在篮子底下，可我吓得手脚僵硬，连蹲下去翻一翻的胆子都没有。

蓝围裙叔叔的摊子其实就在前头不远，他隔着人堆看见我，扯着大嗓门喊：“艾莉，来卖萝卜呀？”

听到这一声，我的两只胳膊一下子把篮子死死勒在怀里，嘴巴张了张，嗓子里却像塞了一团棉花，半点声音也发不出来。我连脚都挪不动了。

后来，我顺着原来的路一步一步往家走。篮子里的萝卜一根也没少，沉得勒手，可我一根都没能卖出去。路过盐摊的时候我停了停脚，伙计热络地问：“小丫头，要买几袋？”我把手伸进口袋，里面空荡荡的，一文钱也没有。我什么话也说不出来，只使劲摇摇头，低着头飞快地走开了。

回到家，娘一句骂我的话都没说，只是默默叹了口气，把萝卜都收进了灶房。晚上锅里炖了一大盆萝卜汤，我坐在桌边捧着碗，吃得比平时慢好多好多。一碗汤喝了很久很久，眼泪一直在眼眶里打转，我始终没敢抬头。]=],
        },
        {
            ["coversFacts"] = {
                "n03_candidate_salt",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n03_candidate_salt",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n03_candidate_salt",
            },
            ["templateId"] = "tpl_n03",
            ["text"] = [=[今天我一迈进集市的大拱门，一下子就瞅准了那个蓝围裙叔叔！我两只手稳稳提着大菜篮子，昂首挺胸走到他跟前，脆生生地喊了一声：“叔叔好！”

蓝围裙叔叔乐呵呵地夸我精神，麻利地往旁边挪了挪筐子，给我腾出一块平平整整的好地儿。我蹲下身，把大水萝卜一根挨着一根摆开，水灵灵的特别招人喜欢。有人凑上来问价，我小嘴叭叭的，半点都没磕巴，收来的铜板我一枚一枚点清，全揣进了小布兜里。

还没到吃午饭的时辰呢，最后两根大萝卜就被一个胖婶婶全挑走了！我一把把空篮子举得高高的给叔叔瞧，嘿，底朝天，一根都没剩下！叔叔直夸我是个顶顶能干的小当家，还特意拍拍我的脑门提醒我：“快去东街把盐买了，早些回家。”我使劲拍了拍腰间鼓鼓囊囊的小口袋，铜板撞得叮当响，我响亮地应着：“好嘞！”

结果我才蹦蹦跳跳走出没几步，斜对面那个卖小铜铃铛的摊子就“丁零零”响起来了。

摊主手里捏着个金灿灿的小铃铛，随手一晃就叮叮叮地响，可一放在桌面上，它就跟睡着了一样哑巴了。我肚子里那只好奇的小猫一下子就抓心挠肝起来，这回我可一点儿也不认生了，两步凑到摊子前，趴在桌边仰着脸就问：“叔叔，它肚子里藏了什么小宝贝呀？怎么拿在手里就会唱歌，躺下就不吱声了呢？”

摊主是个和气人，笑着把一只小铃铛底朝天翻过来给我看。我把脑袋凑过去一瞧，哎呀，原来里面用细铜丝吊着一颗圆滚滚的小铜珠子！我忍不住伸出食指轻轻拨了一下，又是“叮”的一声脆响！

可我又瞅见旁边挂着个巴掌大的大铜铃，声音闷闷的，像老黄牛在叹气。明明里面也吊着小铜片，怎么叫出来的调调差这么多呢？

我心里有数不清的“为什么”，干脆把空篮子往脚边一放，蹲在摊子旁边看他编红绳。我帮他递小铃铛，还伸出两只手帮他把搓毛的麻绳头拧得紧紧的。摊主笑得胡子直翘，直夸我手巧。我听得心里美滋滋的，连肚子咕噜噜叫唤都舍不得挪窝。

直到摊主把铜铃铛一个一个往木匣子里收，我一抬头才猛地愣住了——原本挤得水泄不通的街道怎么空荡荡的了？太阳都快落到屋顶后头去了，大半摊子早就收得连影子都没了！

天哪！坏事了！我的盐！

我抓起大篮子拔腿就往盐铺死命跑，跑得两只鞋底直打滑，风呼呼往嗓子眼里灌。可等我气喘吁吁冲到店门口，盐铺的伙计已经把最后一块厚门板严严实实合上了，手里拎着空水桶准备锁门。我扯着嗓子追上去喊要买盐，伙计回过头，指了指那把挂在门上的大黑铁锁，直摆手：“小姑娘，明早赶早吧，今天封账了！”

我傻愣愣站在冷风里，小口袋里的铜板一枚也没少，沉甸甸地硌着大腿。

一路耷拉着脑袋挪回了家。一进院门，娘先瞧见我手里晃荡的空篮子，满脸是笑地迎上来问：“哟，艾莉真能干，全卖空啦？”

我硬着头皮拼命点头，把兜里攥热的铜板一股脑掏出来堆在娘的手心里。可一说到买盐，我的嗓门就像泄了气的皮球，越说越小，最后蚊子哼哼似的缩成了半截。

我本来想撒个谎遮掩过去，可娘一拉我的手，温温柔柔问我下午到底去哪儿玩了，我嘴一瘪，还是把看铜铃铛、帮人搓麻绳的事全招了。

娘没拿笤帚疙瘩揍我，只是叹了口气，把铜钱收进围裙兜，转身从灶台上拿出一只小粗瓷碗。她说锅里的杂菜汤已经滚了三遍了，正眼巴巴等着下盐呢，只能去隔壁婶婶家先借一勺救急。

我的脸颊一下子烫得像被灶火烤过一样，心里羞愧得不行。我一步冲上去，抢着把那只空碗紧紧抱在胸口：
“娘！我去！我去借！”我吸了吸鼻子，挺起小胸脯大声说，“我现在胆子可大了，我敢去敲门，也一点儿都不怕跟生人说话了！”

我捧着空瓷碗，一溜烟跑到隔壁门前，咚咚咚敲得门板山响，扯开清脆的大嗓门喊：

“婶婶，是我，艾莉！我今天一个人去集上把大萝卜全——卖光啦！就是光顾着高兴把盐给忘脑后了，能借我们家一小勺盐吗？”]=],
        },
        {
            ["coversFacts"] = {
                "n03_candidate_protect",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n03_candidate_protect",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n03_candidate_protect",
            },
            ["templateId"] = "tpl_n03",
            ["text"] = [=[今天一迈进集市的大道，我的小腰杆挺得像田里的麦秆一样直！我迈着大步走到蓝围裙叔叔跟前，脆生生喊了他一声，嗓门亮堂堂的，比周围那些扯着脖子招揽客人的大人还要神气。

叔叔赶紧笑呵呵地给我腾出摊位正中间的好地儿，让我把大篮子挨在他脚边，水灵灵的白萝卜就齐整整摆在他那堆青菜旁边。

我今天可一点儿都没往后缩。有个抱着布包的婶婶刚停下脚，我立刻把娘教我的价钱报得清清楚楚、一个字都没漏。叔叔还在旁边帮腔，夸我家的萝卜皮薄水多、早晨刚从泥里拔出来的。那个婶婶高高兴兴挑了两根顶大的，爽快地数了铜板递给我。

我两只手把铜板死死攥在手心里，心里高兴得直冒泡，恨不得插上翅膀飞去跟芬炫耀——看吧，不仅你会卖菜，我也会！

这时候，蓝围裙叔叔低头瞅了瞅我剩下的萝卜，忽然伸出一只长满老茧的大手，一把抓起里面最粗、最白的那根大萝卜，嘴里念叨着说：“小艾莉，细小的先挪到后头去，把粗壮白净的排在最前头，客人才一眼瞧得上……”

可他那只手刚一伸过来，我脑子里那根弦“崩”的一下就紧了！

他自己也是个卖菜的，凭什么把手伸到我的摊子上指手画脚？他是不是看我是个十岁的小丫头好糊弄，想把我家最好、最压秤的大萝卜顺手顺到他自个儿的菜堆里去？回头卖了钱，全偷偷塞进他自己的蓝围裙兜兜里？！

一想到这儿，我浑身的刺全竖起来了！我猛地扑上去，两只手使出吃奶的力气一把将大萝卜从他手里硬生生夺了回来，死死抱在胸口：

“这是我家的萝卜！你摊上自己明明有一大堆，干吗非要伸手拿我的？！”

叔叔整个人僵住了，悬在半空的手尴尬得不知道往哪儿放。他眨了眨眼，急着跟我解释：“小丫头，我是好心替你理一理……你瞧，这空地也是你娘前两天特意塞了我两个贴饼子，求我给你留出来的呀……”

可他越解释，我心里越起疑：他干吗非逼着我留在他眼皮子底下？他肯定是憋着坏主意想占我便宜！我必须得把家里的萝卜看牢了！

我一句话也不听了，气呼呼地蹲下身，手忙脚乱地把刚摆好的白萝卜连滚带爬全塞回大篮子里。我一把挎起重邦邦的篮子扭头就走。

叔叔在后头大声喊我，急得直跺脚，说这地方人多才好卖菜。我连头都没回，梗着脖子甩回去一句：

“不用你管！我自己也会卖！”

我一口气跑出了最热闹的主街，在一条阴森森、背着光的小巷子口寻了块没人的青石板。我气喘吁吁地把萝卜重新一根根排好。这里多好呀，冷冷清清的，没有大人挤来挤去，更没有外人敢碰我的大菜篮子。

巷口只要走过一个人，我就使劲扯开嗓门大喊一声。

可走过的大人们手里早就拎满了买好的鱼肉青菜，有的连眼皮都懒得掀一下，有的走得急匆匆的，不耐烦地冲我摆摆手：“去去去，小丫头，不买不买。”

我就那么孤零零地蹲在冷风里，扯着嗓门喊了很久很久，喊得喉咙眼像吞了沙子一样又干又疼，眼泪都在眼眶里打转。可面前的白萝卜还是那么多，连一根都没少。

到了日头偏西，整条巷子彻底没人了。我只能垂头丧气地把沉甸甸的萝卜重新装回篮子里，慢吞吞地往回挪。

路过蓝围裙叔叔的摊位时，我看见他正跟隔壁摊主有说有笑地收菜捆筐呢。我做贼心虚似地缩着脖子，死死低着头，故意从街市的最另一边绕了个大圈溜了过去。

“不能让他碰我的萝卜，谁也别想碰……”这一路上，我只能把这句话颠三倒四地咬在嘴里，给自己壮胆。

等我灰头土脸跨进家门时，娘迎上来接下沉得勒手的篮子，掀开布一看，愣住了：“艾莉，怎么……怎么还剩这么大半篮子？”

我眼眶一下子红了，嘴硬地告状：“蓝围裙叔叔手脚不老实！他伸手就要抢我的大萝卜，我怕他偷咱家的东西，就搬到别处去卖了！”

娘听完没发火，只是拉着我冰凉的手，平静地看着我的眼睛问：“那他到底拿走你几根萝卜了？”

我绞着衣角，支支吾吾半天，声音小得像蚊子：“……没、没拿走，都让我手快抢回来了。”

“那他收了你多少占地儿的铜板钱？”娘又问。

我呆呆地摇了摇头。他连半个铜板都没找我要过。

娘没再说话。她默默叹了口气，把篮子里的冷萝卜一根一根拿出来，又重新安安静静地码整齐。

屋里静得吓人。我站在桌子边上，刚才在街上那股张牙舞爪的凶狠劲儿早跑得一干二净，只觉得心口酸溜溜的，难受得要命。

我把兜里好不容易挣来的那两枚孤零零的铜板掏出来，塞进娘长满粗茧的掌心里。我把头埋得低低的，带着哭腔小声央求：

“娘，萝卜没卖完，白盐也没买着……我求求你，回头你千万千万别跟芬她娘说漏嘴呀……”]=],
        },
        {
            ["coversFacts"] = {
                "n04_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n04_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n04_candidate_good",
            },
            ["templateId"] = "tpl_n04",
            ["text"] = [=[第二天再去扫钟楼，台阶上没有那些挂着的破旗子碍事，扫帚一挥顺溜多了，灰尘一堆一堆老老实实被我归拢到了墙角。

扫到一半，皮特就蹬蹬蹬跑上楼来找我玩。他兜里居然还揣着昨天剩下的那半块饼，顺手掰了一大角递到我鼻子底下。这回我接过来直接塞进嘴里，连看都没看一眼到底谁手里的更厚——管它呢，嚼在嘴里全是一样甜！

我们蹲在门口，把大石头底下的纸旗子全翻了出来，一张一张把褶子抹平。最大的那一面被我塞进他手里，我封他当“旗王”，不过我先跟他讲好规矩：当旗王可以，但绝对不准找我收税！皮特乐疯了，举着他的“旗王”在大铁钟下面的楼梯上呼哧呼哧跑上跑下，风把旗子吹得呼啦呼啦响。我靠着扫帚杆笑得肚子疼，笑得连手里的扫帚都快攥不住了。

收工的时候，我们俩头顶着头把那些纸旗子重新叠齐整，搬大石头压得严严实实。我们约好了明天还来这儿玩——我扫我的地，他接着当他的旗王。]=],
        },
        {
            ["coversFacts"] = {
                "n04_candidate_envy",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n04_candidate_envy",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n04_candidate_envy",
            },
            ["templateId"] = "tpl_n04",
            ["text"] = [=[今天我把台阶上的灰一路从墙角扫到塔门口，堆得比昨天还要高出一大截。

皮特跑来找我玩，我们俩蹲在地上，把压在石头底下的纸旗子翻出来看。他一眼就指着最大的那张，扯着嗓子说这张最神气、最威风。

可我瞅着那张大旗子，脑子里不知道怎么搞的，又冷不丁冒出他手里那半块更厚的糖饼来。胸口那股小家子气的憋闷劲儿死活散不掉，弄得我跟他说起话来都硬邦邦的，短得只有几个字。皮特没察觉，还手舞足蹈地给我讲了个街上的笑话，我跟着咧了咧嘴笑了一声。

皮特眼巴巴地说要再玩一会儿，我拿扫帚扫了扫地上的灰，冷着脸说活儿还没干完呢。他愣愣地在旁边站了一会儿，大概觉得没趣，就一个人低着头慢吞吞地下了塔。

收工的时候，我把纸旗子重新塞回石头底下，这回搬石头我用了死力气，狠狠压在上面。明天要是再碰见他，我非得当面问清楚不可：他那半块糖饼，到底是从哪儿弄来的？]=],
        },
        {
            ["coversFacts"] = {
                "n04_candidate_tear",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n04_candidate_tear",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n04_candidate_tear",
            },
            ["templateId"] = "tpl_n04",
            ["text"] = [=[今天皮特又蹬蹬蹬跑上塔来了。昨天剩下的那半块糖饼他居然一直没舍得吃，今天特意掏出来在我眼前晃悠，挤眉弄眼地说要当着我的面一口吞掉。

我死死盯着那半块泛着甜香的厚饼子，越看心里那股邪火烧得越旺，总觉得他占了天大的便宜还特意跑来寒碜我。我脑子一热，张嘴就冲他嚷：“你昨天分饼就是故意留了厚的那块，你少得意！”

皮特一下子愣住了，瞪大眼睛涨红了脸喊：“你放屁，你瞎说！”

我一听火气彻底炸了，根本没过脑子，扑上去一把从他手里夺过那块饼，使出浑身力气狠狠砸在石阶上。“啪”的一声，薄薄厚厚的甜饼子当场摔成了好几瓣碎渣。

皮特的眼圈一下子全红了。他蹲下身，咬着嘴唇，把地上的碎饼渣一块一块捡起来死死攥在手心里。他抬起头狠狠剜了我一眼，带着哭腔吼：“奥托，我以后就算扔了也再不给你留了！”说完扭头就冲下了楼梯，脚步踩得咚咚响。

整座钟楼一下子静得吓人。我一个人在冷冰冰的塔楼上转来转去，胸口那团火烧得我难受，却连个撒气的地方都没有。我冲到门口，发了疯似地把大石头掀翻，把叠好的纸旗子一把扯出来，找出里面最大、最神气的那张，“刺啦”一声，恶狠狠地撕成了两半！

白纸裂开的声音刺耳极了。刚撕完，我的手就僵在了半空，后悔一下子像潮水一样漫上来。可我又抹不开面子追下塔去找他。最后，我只能把剩下的破旗子胡乱塞回石头底下压好，耷拉着脑袋，灰溜溜地回了自己的小屋。]=],
        },
        {
            ["coversFacts"] = {
                "n04_candidate_play",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n04_candidate_play",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n04_candidate_play",
            },
            ["templateId"] = "tpl_n04",
            ["text"] = [=[第二天我拎着扫帚上楼，才扫了两级台阶，皮特就从门外探进半个脑袋来。他嘴里嚼着糖饼，把剩下的一角递给我，我一把接过来，嚼得满嘴甜，连他手上还剩多少都没顾上瞧。

他看我扫地，忽然蹲下来指着台阶上的灰说：“你这山堆得真高，马都跑不过去。”

我听着就乐了，把扫帚往胯下一夹，抬腿跨过那堆灰，冲他喊：“谁说跑不过？我这匹马腿长！”

皮特笑得直拍大腿，掉头去门口翻纸旗子，挑了一张小的，塞进扫帚杆上那道裂缝里。我骑着这匹插旗子的马，在楼梯底下跑了一圈，回来时他正举着另一张旗子等我，硬说自己是守城门的，过路得交半块糖饼。

“饼已经进我肚子啦，你有本事拿去！”

他扑过来挠我的腰，我笑得两条腿都站不稳，抱着扫帚缩到门后。皮特也没好到哪儿去，追了两步就靠着门框直喘气，手里的纸旗子一抖一抖的。

我心里痛快极了，昨天那点酸溜溜的难受早不知道跑哪儿去了。他要回街上，我还拉着他的袖子不让走，说楼梯拐角那块地方也得算我的城，得再打上一仗。

扫帚已经不是拿来扫地的了。我把它横在门口当栅栏，皮特拿旗杆挑开，我们俩一趟趟踩过台阶，刚扫拢的灰全被鞋底带散了。我瞧见了，可他又在外头扯着嗓子喊要进城，我赶紧转身去拦，把扫地的事往后拖了拖。

后来皮特跑得口渴，我们又下楼去厨房讨水喝。他喝得太急，水顺着下巴往衣领里流，我指着他笑，他也笑，还故意把空碗倒过来给我看，说他的下巴已经替他喝了半碗。

等我们捧着肚子回到塔门口，管事正站在楼梯下头，手里捏着我丢在台阶上的一张纸旗子。

“奥托，你今早就在这儿骑马呢？”

我一下子不敢笑了，赶紧把扫帚从门口抽出来，攥在手里装作要扫。他往上指了指，几级台阶都留着乱七八糟的鞋印，角落里那堆灰还叫我们踢出去老远。

“厨房都开饭了，这楼梯还没扫完。先把活儿干了再去吃。”

皮特站在我旁边，脸也红了，小声说他来帮忙。管事让他把散开的旗子收好，自己转身下了楼。

我肚子已经饿得咕咕叫，心里有点发虚，低下头赶紧往墙边扫灰。皮特蹲在石头旁边，把纸旗子一张张抹平，叠回去，抬头问我明天还骑不骑马。

我差点又笑出来，忍住了，拿扫帚毛戳了戳他的鞋尖：“你先抬脚，灰都压你底下了。”]=],
        },
        {
            ["coversFacts"] = {
                "n04_candidate_past",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n04_candidate_past",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n04_candidate_past",
            },
            ["templateId"] = "tpl_n04",
            ["text"] = [=[第二天皮特来找我的时候，我已经把扫帚靠在厨房门边，正蹲在灶前往里头添柴。帮灶的婶婶给了我一小把糖屑，我全倒进了那只小铁锅，又舀了半瓢水进去，想熬一锅老厨娘从前做的甜汤。

皮特一听有甜汤，立刻搬了张矮凳坐下来，说熬好了就端到塔门口喝，喝完再去玩旗子。

我满口答应，拿木勺在锅里转来转去，糖屑很快就化开了。皮特凑过来闻，说已经有甜味了，我让他拿只小碗来，舀了一点吹凉，自己先尝了一口。

甜是甜，可我心里还是不大满意。去年节庆的时候，老厨娘往大锅边上一站，袖子卷到胳膊肘，拿长柄勺搅两下，满屋子的人就都凑过去了。今天厨房里冷冷清清的，只有皮特蹲在我旁边，巴巴地等着喝。

“她熬出来的香得很，这锅还差着呢。”我把碗里的汤倒回去，又往灶里塞了一根柴。

皮特说甜一点淡一点都能喝，不如盛出来，他的嘴都等干了。我不肯，死盯着锅里那点汤，想让它再熬浓些，非得熬出我记得的那股味儿才行。

锅里的水滚得噗噗响，我拿木勺刮了刮锅沿，低头看了半天。皮特伸手去拿碗，我一把拦住，让他再等等，他只好把碗放回桌上。

我又跟他讲老厨娘分糖屑的事，说她从前还会把沾在勺上的糖刮下来，多给我一点。说着说着，我心里难受起来，真想她这会儿就推门进来，把我的勺子接过去，告诉我到底还缺了什么。

皮特已经坐不住了，起身去门外看了一眼，回来时手里多了两张纸旗子。他把一张塞给我，说拿着它到楼上跑一圈，汤就差不多了。

我没接，怕他搁在灶边烧着，让他拿远一点。

“你不是说今天跟我玩吗？”他问。

“熬好了就去。”

“刚才你也是这么说的。”

我心里烦得很，抬头冲他说：“你先别催！她从前熬一大锅都没这么快，你又不会，怎么知道好了？”

皮特把旗子放回门外，端起桌上那碗凉水喝了，坐在门槛上没再说话。我心里也不痛快，拿勺子的手越搅越急，可怎么闻都闻不出记得的香味。

等我低头再看，小锅里的水已经浅得盖不住勺头，锅底冒出一层细泡。我还想把黏在边上的糖刮下来，勺子刚贴着锅底一推，一股焦苦味就冲到了鼻子里。

我慌了，赶紧往里添水，锅里嗤地响了一声，溅得我往后退了两步。再把勺子伸进去，底下已经结了一片黑乎乎的糖壳，汤也变成了浑黄的颜色。

皮特跑过来帮我垫着布把锅端下灶。我不甘心，舀了一小勺吹凉，刚碰到舌头就苦得全吐了出来，站在灶边难受得一句话也说不出。

帮灶的婶婶进来一瞧，让我把坏汤倒了，把锅泡上水，下午再把糊底刷干净。她又问我楼梯扫完没有，我低着头摇了摇。

皮特把那两张旗子叠好，压回门口的大石头底下，回来跟我说家里还等他，得走了。

我想叫他留下，可小锅还泡在盆里，扫帚也靠在门边，一早上什么都没弄好，哪还有脸再让他等。我小声应了一句，他就顺着楼梯下去了。

下午我蹲在水盆前刷锅，焦糖粘得死紧，怎么刮都刮不干净。我憋着眼泪，把湿布拧了又拧，手上全是那股苦味。]=],
        },
        {
            ["coversFacts"] = {
                "n05_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n05_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n05_candidate_good",
            },
            ["templateId"] = "tpl_n05",
            ["text"] = [=[席间我仍旧坐在老位置，靠窗的那张高背软椅上。

头一道浓汤端上来时，我的手在垂下的雪白桌布底下攥了攥，指甲陷进掌心，片刻后又慢慢松开。汤是滚烫的，奶油和盐的分量调得极好。我握紧银勺，一小勺、一小勺地将它喝完了。温热的汤水落进空落落的胃里，整个人好像终于踏实了些。

烤鹅端上桌时，香气扑鼻。表姐执起银餐叉，替我分了一块肥嫩的鹅胸脯。那叉柄背面上刻着展翅的云雀家徽，我再熟悉不过，和我们去年变卖的那套银器一模一样。有那么一瞬间，那些数字几乎又要涌进脑子，但我硬是压了下去，没有去算它在当铺能折多少钱。我切下一小块鹅肉送进嘴里，连带着旁边酸甜的野莓果酱也仔细尝了。

姑母侧头看了我两眼，神色很静，什么也没说。

回程的马车里有些穿堂风，姑母伸手替我拢了拢肩上的薄呢披肩。车轮在碎石路上辘辘地响着，到家推开月桂坡的旧门时，我的肚子是饱的，身上也是暖的。]=],
        },
        {
            ["coversFacts"] = {
                "n05_candidate_count",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n05_candidate_count",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n05_candidate_count",
            },
            ["templateId"] = "tpl_n05",
            ["text"] = [=[今晚表姐家的席面摆得比上回还要体面。

头一道热汤端上来时，我喝得很顺，甚至悄悄松了口气，以为自己终于能像个普通客人那样吃完这一餐。

可当整只泛着金黄油光的烤鹅被侍者端上桌时，蜡烛的光映在描金瓷盘的边缘，晃得人眼晕。我脑子里那架算盘毫无预兆地又自己拨弄了起来：这样一只填满香料的肥鹅要耗费多少银币？换成粗煤能烧几天？如果折成面粉，又能撑过几个星期？

我握着刀叉的手不知不觉慢了下来，最后干脆悬在半空，迟迟没能落下去。表姐察觉到了，侧过身问我是不是菜色不合胃口。我勉强牵了牵嘴角，轻声回她说不是，只是平日里吃惯了慢食。

后半席端上来的精巧甜点和烤肉，我几乎再没动过一刀一叉，只垂着眼，就着微凉的水把剩下的半碗清汤慢慢咽了下去。

回程的马车里，车厢里暗得很。姑母拍了拍我的手背，低声说：“今晚比上回强多了。”我知道那是句体恤的安慰，可听在耳朵里，心里沉甸甸的，比挨了训斥还要难受。]=],
        },
        {
            ["coversFacts"] = {
                "n05_candidate_sad",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n05_candidate_sad",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n05_candidate_sad",
            },
            ["templateId"] = "tpl_n05",
            ["text"] = [=[今晚我依旧坐在那个靠窗的软椅上。

第一道汤端上来，银勺拿在手里分外沉重。我试着低头舀起一勺，可喉咙深处仿佛又被一根看不见的细绳狠狠勒紧了，胃里一阵发紧，连咽下一滴水的余地都没有。

表姐越过我同姑母闲聊，席间笑声不断，宾客们的谈吐优雅又惬意。我融不进那些话里，只能低下头，把目光钉在铺得平整的桌布上。我开始数那繁复滚边的刺绣针脚：一针、两针、三针……绣完这样一整张台布需要费多少工时？如果拆下这些细亚麻线拿去换，又够不够抵上一捆过冬的干柴？

我一边数着，一边任由那些数字在脑海里堆积成山。等到主菜撤下去的时候，我面前的那只瓷盘干干净净，连一丝油星都没沾上。

这回在回程的马车里，姑母没有像上次那样数落我的失礼。黑暗中，她只是疲倦地靠在车壁上，轻声说了一句：“明天让厨房多煮些芜菁汤吧。”

我点点头，把冻得冰凉的手藏进磨了毛的袖口里。我没敢应声，更没敢告诉她，其实整个晚上，我都饿得胃里发疼。]=],
        },
        {
            ["coversFacts"] = {
                "n05_candidate_talk",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n05_candidate_talk",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n05_candidate_talk",
            },
            ["templateId"] = "tpl_n05",
            ["text"] = [=[今晚第一碗浓汤端上来时，我便闻到了奶油的香气。胃里空了许久，我低头喝了一勺，觉得很好，便把剩下的也慢慢喝完了。

烤鹅摆上桌，我不去想煤价，只看着表姐替我切下那块酥脆的鹅皮。她问我配不配野莓酱，我点了点头，又添了一小块面包，把盘底的酱汁蘸干净。

表姐瞧着我，笑着说：“这才对。上回你什么都不吃，我还以为是厨房做得不好。”

我心里轻松了些，也有点不好意思，赶紧说不是。她又替我添了一点菜，问我近来在家过得如何，姑母的腿入冬后还疼不疼。

这些话平常听着总让我紧张，可今晚吃着热饭，我竟不觉得难堪了。我告诉她姑母的腿还是怕冷，我们把起居室关了，只在小饭厅生火，坐得近些便暖和。表姐伸手碰了碰我的手背，说难怪我的手一直这样凉。

她的语气很亲近，我听着心里一软，不知不觉又多说了几句。我说厨房近来煮芜菁汤的时候多，姑母每回都把厚的那片面包留给我，自己说不饿；那张大餐桌抬走后，小饭厅空出许多地方，连仆人擦地都省事了。

姑母在旁边轻轻叫了我一声，我还以为她嫌我只顾说话，连忙切下一块鹅肉放进嘴里。

表姐的笑慢慢收了，问我桌子是什么时候卖的。

“去年深冬。”我咽下鹅肉，顺口答了，“那阵子正要买煤，账房的单子又……”

姑母把酒杯放回桌上，声音很轻，却把我的话截住了：“吃饭吧，塞西莉亚。”

我这才停了嘴。隔着桌子坐的客人正看着我们，方才还在说话的那位夫人也放下了餐叉。我脸上渐渐发烫，赶紧低头去切盘里剩下的肉。

表姐没有追问，只把话转到了庄园新栽的果树上。我努力跟着听，也继续把饭吃完，后面端来的甜点还是甜的，可每咽下一口，都忍不住往姑母那边看。

她坐得很端正，偶尔应一句话，面前的菜却剩了不少。我想同她说方才只是和表姐闲聊，没有要让别人可怜我们的意思，可饭桌上又实在找不到机会。

临走时，表姐把我们送到门厅，让仆人提来一只小篮子，说厨房还有些没切的鹅肉，带回去明天热一热正好。

姑母道了谢，把篮子递给跟车的仆人。我站在一旁，连抬头看表姐都有些不敢了。

马车驶出院门，我小声同姑母说：“我不是故意把那些事说出来的。”

“我知道。”她答。

我等了片刻，还是忍不住问她是不是生我的气。她疲倦地摇了摇头，把披肩往膝上拢了一点。

“家里不宽裕，她知道。可面包吃多吃少，不必让一桌子的人都知道。”

我羞愧得说不出话。那只装鹅肉的篮子搁在脚边，车轮一颠，盖布滑了下来，我弯下腰，把它重新掖好了。]=],
        },
        {
            ["coversFacts"] = {
                "n05_candidate_fork",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n05_candidate_fork",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n05_candidate_fork",
            },
            ["templateId"] = "tpl_n05",
            ["text"] = [=[今晚我原本表现得还可以。

热汤喝了大半碗，面包也吃下去一块，胃里暖了，握着银勺的手不再僵硬。表姐问我味道如何，我还认真回了她，说比家里的汤浓一些，香料也放得恰好。

烤鹅送上来时，我甚至有些期待。表姐用餐叉按住鹅胸，拿刀替我切肉，叉柄一转，背面的那只云雀便露了出来，翅膀下的细纹清清楚楚。

我盯着它，心里猛地难受起来。去年运货的人来收银器，姑母把木匣子一格一格打开，我站在旁边看着，也是这样的云雀，这样细长的叉柄。如今家里早已换上旧铁叉，这里却还拿它压着肥嫩的鹅肉。

表姐把瓷盘推到我面前，我没有动刀，先问了她一句：“这套餐叉，你是什么时候得来的？”

她正在同旁人说话，听见了便转过头来，说是成婚时带来的，一直用到现在。

可我心里已经起了疑。她是不是买下了我们家的银器，又怕姑母难堪，所以故意不肯承认？上回我一口菜都没吃，这回她还特意派仆人来告诉我们有肥烤鹅，难道也是想让我们瞧瞧，那些卖出去的东西在她家用得多么好？

我拿起面前的银叉，把背面翻给她看，声音比方才高了些：“我们去年卖掉的，也是这一套。”

姑母的手立刻按在了我的腕上，低声叫我把叉子放下。我却没有松手，心口堵得厉害，非要听见表姐说清楚不可。

表姐看着那只云雀，先是有些不解，随后便皱起眉来。

“塞西莉亚，我们本来就用同一个家徽。我的嫁妆里有这套银器，你姑母也见过。”

我当然知道我们同族，可那一刻，我怎么都不肯相信只是看错了。我又追问她，是不是从旧货商那里收来的，价钱给得高不高，问完才察觉整张桌子都安静了，连替客人倒酒的仆人也停在一旁。

姑母把我的手指一根根从叉柄上拨开，将银叉放回桌面。

“她出嫁时，我帮着看过那套银器。”姑母看着我说，“那是三年前，家里的银器去年才卖。”

我的脸一下子烫了起来，嘴唇动了动，却没能说出话。方才还觉得自己受了委屈，如今一桌子的人都看着我，我连眼睛该往哪儿放都不知道了。

表姐让仆人继续上菜，自己放下了分鹅肉的刀，轻声说：“这顿饭是请你们来吃的。”

我听得心里发慌，很想说我没有别的意思，可我已经问了那些话，连自己都觉得这句辩解站不住。我低头望着面前的鹅肉，原先盼着尝的那块脆皮贴在盘边，油汁正一点点凝起来。

姑母示意我吃，我拿起刀，切下一小块，送到嘴边又放了回去。喉咙紧得难受，什么也咽不下。

后来客人们又说起别的事，表姐照常应着，偶尔朝我这边看一眼。我知道该向她道歉，可每次想开口，都怕旁人再转过头来听，只能把那句对不起一次次咽回去。

姑母替我推说身子不适，提前告了辞。站起身时，表姐仍旧送我们到门口，我只能低着头说了声多谢款待，连她的眼睛都没敢看。

回程的马车里，我小声问姑母，表姐是不是很生气。

“她没有做错什么。”姑母说。

我没有再问，攥着袖口坐了一路。到家后，厨房给我留的芜菁汤已经凉了，我请人重新热了一小碗，端到桌前，仍旧喝不进去。

姑母上楼去了。我把碗往旁边挪了挪，找来一张纸，写下表姐的名字，又在后面添了句对不起。写到该解释的地方，我握着笔停了很久，纸上落了一团墨。]=],
        },
        {
            ["coversFacts"] = {
                "n06_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n06_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n06_candidate_good",
            },
            ["templateId"] = "tpl_n06",
            ["text"] = [=[新榫头推着旧卯眼，只听“喀哒”一声闷响，严丝合缝地咬死了。

我没急着上漆，先拿自己这把干瘦的老骨头坐上去结结实实压了压，左右晃了三晃。木料吃住了劲，四平八稳的，再也不用冲着饭桌低头作揖了。

黄昏时对门的皮匠过街来取。他一屁股坐上去，前倾后仰地试了半晌，咂着嘴直夸：“嘿，莱昂，这简直跟换了把新椅子没两样！”

我一边收拾台面，一边慢悠悠地回他：“说什么胡话，它还是那把使惯了的旧物件，不过是我替它把走丢的那条腿给找回来了。”

送走老邻居，我按着老习惯，抽出一块浸了油的粗布，把用过的凿子一柄一柄擦拭干净，刃口朝里，归进木架子上的老凹槽里。哪一柄卷了微刃、明天该上磨刀石，用粉笔在板子上记得清清楚楚。那条厚围巾不知什么时候又滑落到地上，我弯腰把它从碎刨花里捞起来，使劲拍打掉上面的白木屑，齐齐整整叠好，锁进了底下的抽屉。

诶，可不能再拿老伴的心意当木屑袋兜灰了。]=],
        },
        {
            ["coversFacts"] = {
                "n06_candidate_pain",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n06_candidate_pain",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n06_candidate_pain",
            },
            ["templateId"] = "tpl_n06",
            ["text"] = [=[榫头到底还是砸进了卯眼，只是这一趟活走得太磨人。

腕子里的骨头一阵阵抽着酸疼，疼劲儿一窜上来，我就只能把家伙什撂在台子上停一阵。下几凿，直起腰喘几口粗气，再凑近了把红粉笔划下的线重对一遍，确认分毫没偏，才敢硬着头皮再敲下一记。

皮匠来搬椅子的时候，坐上去晃了晃，笑着说这回稳当了。抬头瞧见我的脸，他冷不丁愣了一下：“外头刮干冷风呢，你这额头上怎么冒这么一层虚汗？”

我用袖口在脑门上抹了一把，平着嗓子掩饰过去：“天冷，屋里漏风，手僵了就容易使蛮力。”

等他扛着椅子过了街，屋里只剩我一个人。我把今天动过的凿子一字排开，在纸上记下哪把明天得磨。手腕子在暗处一跳一跳地泛着酸胀，整整一天，它都在清清楚楚地提醒我：你老了。

椅子是严严实实修好了，对得起老街坊，可我坐在昏暗的屋里，心里半点从容的得意也没有。]=],
        },
        {
            ["coversFacts"] = {
                "n06_candidate_stop",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n06_candidate_stop",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n06_candidate_stop",
            },
            ["templateId"] = "tpl_n06",
            ["text"] = [=[凿到榫肩最吃紧的一刀，腕子里突然像被细针狠扎了一下，猛地一抽。

我手腕一哆嗦，铁刃在离木线不到半厘的地方硬生生煞住了。屋里一下子死静死静，只有外头钻进来的风声，我整颗心跟着往下坠。

我咬着牙想把这记凿子敲下去，可那股怕劲儿先从心底冒了出来：这根料子的榫肩我前后量了三遍，要是手底下这一晃走偏了刀路，整条硬木椅腿可就彻底废了。

握着木槌的手就那么僵在半空，停了很久。

放下工具歇了两次，手心搓得发烫，可心里那股准头到底没能聚回来。我叹了口气，没再勉强，把料子收进筐里，抱起那把没修完的跛椅子，一步一步给对门送了回去。

皮匠开门见我抱回来，神色有点发紧：“怎么，莱昂，这椅子没得救了？”

“木头底子是好的，有救。”我看着他的眼睛，实实在在地开了口，“是我这双手今天不敢下那一凿子。改日吧，等手稳了再给它合榫。”

走回来的路上，弄堂里的穿堂风直往我空荡荡的袖口里钻。我把老伴织的那条围巾在怀里紧紧按了按，一路走一路搓着巴掌。

两只老手搓得通红，可指尖还是像石头一样，怎么也暖不透。]=],
        },
        {
            ["coversFacts"] = {
                "n06_candidate_sleep",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n06_candidate_sleep",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n06_candidate_sleep",
            },
            ["templateId"] = "tpl_n06",
            ["text"] = [=[今天下凿的时候，手倒真稳当。木槌先在料上轻敲三下，凿刃顺着划好的线往里吃，一片片薄木屑翻出来，榫肩留得方方正正。

我心里舒坦，凿子顺着划好的线走，几处榫口都修得齐整。过了午，我把榫口挨个摸过，拿尺子又量了一遍，尺寸都对，接下来只等把椅腿装回去。

皮匠隔着街喊了一声，问傍晚能不能来拿。我推开窗，朝他晃了晃新凿好的椅腿，说来吧，误不了他的晚饭。

话说得满，其实干活时我就有些犯困，一直撑着才没歇下。午饭只啃了半块冷面包，凿子敲了半天，耳朵里还留着那阵笃笃声。我把家伙什靠里搁好，寻思先坐一会儿，喘匀了这口气再合榫。

老伴那条围巾收在抽屉里，我拿出来搭在膝上，背靠着墙，坐得暖和。窗外有辆货车经过，轮子碾得石板咯咯响，我听了一阵，眼皮就有些撑不住了。

我本来只想闭一闭眼，谁知道这一坐，真睡沉了。

醒来的时候，屋里已经暗了，膝上的围巾垂到地上，外头有人正在拍门，声音急促。我赶紧站起来，腿坐麻了，还得扶着桌沿缓一缓才走得动。

皮匠在门口，见我出来先松了口气。

“我来两趟都没叫开门，还以为你又不舒服了。你闺女今儿没来，我正想找人陪我把门撞开呢。”

我脸上有些挂不住，赶紧说没事，不过是干完活坐着睡了一觉，身子还撑得住。

他往我身后看，问椅子能不能搬了。我也跟着转过头，工作台上搁着做好的椅腿，旧椅架还躺在旁边，那条腿还没装回去。

“榫口是凿完了。”我说，“就是还没合上。”

皮匠瞧了瞧窗外，说家里已经开饭，再晚回去都凉了。他问我有没有能坐的旧杌子，先借他一晚。

我把墙角那只矮杌子搬出来，替他拍掉面上的灰。原本想着今晚就能让他舒舒服服坐回自己的旧椅子，结果叫他来来回回跑，最后搬走个连靠背都没有的小物件，心里实在过意不去。

他还笑着说矮点也好，端着碗吃离嘴近。我跟着笑了笑，让他明早来，这回真不误事了。

送他过街，我回屋把围巾叠好放回抽屉。新榫头上的木屑还没擦净，我点亮灯，拿粗布一点点抹了，给椅架腾出一块干净地方后，拿起了木槌。]=],
        },
        {
            ["coversFacts"] = {
                "n06_candidate_split",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n06_candidate_split",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n06_candidate_split",
            },
            ["templateId"] = "tpl_n06",
            ["text"] = [=[今天我手里拿着凿子，沿榫肩一边边走下来，木线留得清楚，我凑近看了两遍，心里还挺得意，想着闺女下回再来，得让她瞧瞧我修好的椅子，别一进门就劝我收家伙什。

新椅腿凿好时，皮匠正好过街来。他伸手想帮我扶着椅架，我摆摆手，让他坐旁边等一等，这点活我自己还干得了。

我把榫头对着旧卯眼往里推，进去一半，便卡住了。拿木槌轻轻敲了两记，仍旧紧，椅腿底下悬着，离该坐实的地方还差一截。

本来这也不算什么大事。修旧物件，试着合一遍，抽出来再削一点，是常有的。我把椅架按在台上，正想去拿小凿子，皮匠却瞧见我额头上的汗，起身把木槌接了过去。

“你先喘口气，我替你敲两下。要是还合不上，留到明天也成。”

我心里一下就不舒坦了。他是怕我累，我知道，可那声“留到明天”听着怎么都像是认定我这双老手已经不顶用了。我干了大半辈子的木工，临到一把椅子，倒得叫做皮鞋的来帮我收尾？

我把木槌从他手里拿回来，平着嗓子说：“你坐着吧。榫口咬得紧，椅子才结实。”

皮匠还想说什么，我已经把椅架换了个方向，垫牢底下的木块，照着椅腿又敲了一记。榫头往里进了些，皮匠在旁边扶了一把，我嫌他碍着手，让他站远点。

我那时心里憋着气，只想赶紧把这条腿装进去，让他看看不用人帮，我一样能交活。木槌攥得死紧，我不肯停下来歇手，敲下去的每一下都实实在在落在同一处。

可木料已经吃不住这股劲了。

第三记重槌落下去，椅架里忽然响了一声脆的。我手里一顿，低头看，卯眼旁边裂开了一道口子，裂缝沿着旧木纹往外爬，连边上的漆皮都掀了起来。

皮匠赶紧扶住椅背，让我别再敲了。我把木槌搁下，伸出指头按了按那道裂口，木头两边已经能错开，新榫头是进去不少，但不可能咬得牢了。

我胸口发闷，站在台边半天说不出话。方才还嫌人家来帮忙碍事，这会儿椅子叫我敲坏了，皮匠却还在替我扶着它。

“不能搬回去了。”我低声说，“裂的这块得换料，光修一条腿不成了。”

他伸头看了看裂口，问还修不修得好。我说修得好，只是要多花几天，木料的钱我出，不能叫他掏。

皮匠没有同我争钱，只拍了拍椅背，说这把椅子用了十几年，能留就留，别再硬敲了。说完他把椅架放稳，自己过了街。

我坐回台前，心里懊恼得厉害。那把小凿子就搁在手边，刃口磨得亮亮的，抽出榫头，削去一点，原本费不了多少工夫，是我偏要把那几下重槌敲给人看。

我把椅架从台上搬下来，垫在两块干净木头上，找了块旧布罩住。木槌搁回架子里，敲落的几片碎漆皮还在地上，我蹲下身，一片片捡进了废料筐。]=],
        },
        {
            ["coversFacts"] = {
                "n07_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n07_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n07_candidate_good",
            },
            ["templateId"] = "tpl_n07",
            ["text"] = [=[大清早，我把收条按日子一张叠一张理得整齐，揣在衣襟里进了石鸥客栈的大堂。

掌柜正端着茶碗站在柜台后头，抬眼瞧见我，眼珠子一转，脚跟转过去就想往账房里头躲。我两步赶上去，把最上头那张浸着碱水渍的收条重重拍在油亮的木柜面上，声音不大，但在清早的堂子里格外扎耳：“掌柜的，慢着点儿步子。天亮了，今天咱们当面把账算清楚再走。”

我垂着眼，一条接着一条念：哪月哪日交的货、几床大单、几件被面，落款是谁的字。念到第六条，他脸色有些挂不住，又想拿出那套打哈哈的做派，摆着手说：“哎呀贝娅，你瞧大早上的，下回一并结给你还能短了你的？”

“没有下回。”我硬生生截住他的话头，眼睛直直钉在他脸上，“今天就算今天的。我拿力气挣的嚼谷，等不起哪个下回。”

邻桌几个吃早酒的行商转过头来看热闹。掌柜的脸颊抽了抽，到底是要顾及大堂里的体面，没敢当众耍泼，沉着脸朝账房偏了偏头。

账房慢吞吞抱出钱匣子，当着满堂人的面，一个一个数出九套床单的铜子儿排在桌上。剩下的那十二套，我逼着他拿炭笔写了还账的硬日子，当面按了暗红的掌柜印。

跨出门槛的时候，晨光正照在青石板路上。沉甸甸的铜板坠在袖袋里，撞在腕子上生疼。我心里没有多痛快，只觉得浑身筋骨松泛了些——该说的话，我全说了。

这一回，天理和气性，实打实全站在了我这边。]=],
        },
        {
            ["coversFacts"] = {
                "n07_candidate_soft",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n07_candidate_soft",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n07_candidate_soft",
            },
            ["templateId"] = "tpl_n07",
            ["text"] = [=[我去得挺早，收条一张张排得妥妥当当，憋在心口的那几句话也练了一宿。

刚进门那会儿，我话说得极硬。我把签了字的底单一张一张排开，推到他鼻子底下：“这是上上个月的十二套，这是前头的九套。掌柜的，白纸黑字画着押，账本上可不认‘下回’这种字眼。”

掌柜没像往常那样冷脸，反倒长长叹了口气，弓着背跟我诉起苦来：说外头的货船被封在冻河里，过客都赊账，客栈后厨的伙计都快揭不开锅了。

他那张苦脸看在眼里，我心头不知怎么的，冷不丁就撞上了昨晚自家那间黑黢黢、四面漏风的背阴小屋。大家在这条破巷子里挣命，谁又比谁好过呢？那股狠劲儿在喉咙里打了个转，嗓门一下子就软了半截。

心一软，嘴里的数就跟着乱了套。我先说了这十六套新单子，又慌忙翻出上上个月的旧账，他借势挑出两张折了角的收据，皱着眉让我理顺了再算。我两手发虚，在柜台前手忙脚乱地重排了半天，手心里全是一层冷汗。

最后，他像施舍似的让账房摸出五套的工钱，随手扔在柜上。

我咬着唇，把剩下的收条默默收回围裙兜里。走出老远，冷风迎面一吹，我才猛地想起——我原本是打定主意要替妹妹把这季做新鞋的钱一并要回来的。这趟门出了，气还在心口堵着，可手里的活钱，却只讨回来了一层皮。]=],
        },
        {
            ["coversFacts"] = {
                "n07_candidate_acid",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n07_candidate_acid",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n07_candidate_acid",
            },
            ["templateId"] = "tpl_n07",
            ["text"] = [=[我到底还是按捺着性子去了客栈。收条整齐地压在柜台上时，我的手平平稳稳，半点没抖。

可掌柜的才皮笑肉不笑地念叨了两句“年景不好、客栈难做”，我脑子里嗡的一声，冷不丁冒出了斜对街那个洗衣的寡妇。上个月交活，掌柜可是当着所有人的面，客客气气把整吊的铜钱码进她手里的。

为什么偏偏只短我的？只克扣我们姐妹俩的？

这个念头一旦冒了头，胸口原本那股滚烫的怒火，不知怎么搞的，瞬间全变作了一股冰凉刺骨的泛酸。眼眶一胀，嘴底下的数就全错乱了——我硬生生把九套错念成了十二套。我慌忙低头去翻那张签条自证，可那几张纸片在指尖抖得像秋天的落叶，越翻越乱，最后哗啦啦散了一柜台。

掌柜冷眼瞅着我这副窘迫窝囊的模样，嘴角扯了扯，像是看穿了我的底细：“行了行了，瞧你这心慌意乱的。改天把账算明白了再来吧，先把新担子挑回去。”

我没有撒泼，甚至连眼泪都没让它掉下来。收拾好碎纸片，回家的那一路上，我把背挺得直直的，手里抱着那些客人送洗的细麻衬衣。

天黑透了，屋里冷得厉害。妹妹在窄桌边喝着照得见人影的稀汤，小声问我今天到底要回来多少。

“……没要成。”我说。

妹妹停了手，放下粗瓷碗，借着微弱的油灯愣愣地看着我：“姐，你的脸怎么红成这样？”

我低下头，伸手把衣领往上拉了拉，盖住发烫的脖颈。

“外头风大，”我说，“让风刮的。”]=],
        },
        {
            ["coversFacts"] = {
                "n07_candidate_discount",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n07_candidate_discount",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n07_candidate_discount",
            },
            ["templateId"] = "tpl_n07",
            ["text"] = [=[大清早我进了石鸥客栈，把两叠旧收条按日子一张张排开在柜台上，先念上上个月的十二套，再念上个月的九套，合起来整整二十一套。

掌柜眼珠子一转，脚跟转过去又想往账房里缩。我眼疾手快，把最后那张盖了印的底单一把推到他眼皮子底下，让他把上头自己的亲笔画押看个真切。他扯着嘴角，还想拿“客人退了两套”的老话来搪塞。我直接冷着脸反问他：“退回来的脏床单在哪儿？哪位客人退的？哪一天退的？您现在就当着满堂客人的面拿出来，咱们一件一件对着看。”

他被我堵得哑口无言，脸上的肉皮抽动了两下，手指在油腻的柜面上哒哒敲着，皮笑肉不笑地压低声音：“贝娅，你还想不想在石鸥客栈接长远活计了？”

我胸口那团火猛地往上撞，直视着他的眼睛回敬他：“掌柜的，接活就该给账。您不能拿明天的生计，来赖昨天的血汗钱！”

柜台边刚好有几个排队结房钱的行商，听见动静全转过头来看热闹。掌柜的脸上到底挂不住体面，咬了咬牙，冲里头喊了一嗓子，终于把账房给叫了出来。

账房抱着沉甸甸的木钱匣，当着众人的面把黄澄澄的铜板一排一排整整齐齐码在柜面上。看着那几排铜钱，我后背紧绷的筋骨才稍稍松泛下来。可我的手刚伸过去，掌柜那只肥厚油腻的大手猛地按在了那堆铜板上头。

“旧账，我今天一个子儿不少全结给你。”他身子往前倾了倾，眯缝着眼，“不过，前天送去你那里的十六套急用单子，得换个新价。”

我盯着他问怎么换。

“如今码头生意淡，住店的散客少，客栈贴不起原先的价码。”他笑得像只吃饱的黄鼠狼，“这一担，按原先的一半算。你应下了，往后的活计照旧全归你做。”

“半价？！”我当场就把头摇成了拨浪鼓，“十六套床单！我烧的硬柴、买的碱面、熬的浆粉，哪一样能给我折成半价？！凭什么只给一半的工钱？！”

掌柜也不跟我争辩，只是朝账房偏了偏下巴。账房立刻伸手，作势要把柜面上的铜钱重新扫回黑匣子里。掌柜端起茶碗，慢悠悠抿了一口：“你要是不乐意，那成啊。等下个月客栈账上宽裕了，咱们两笔一并结。”

看着匣子盖一点点落下去，我猛地伸出两只发抖的手，死死扒住了木匣的边缘！手背上的青筋全凸了出来。

钱就在眼前，触手可及。我的房东昨晚已经拍门催了第二回租，妹妹脚上那双单鞋的底子早就张了口，正冻得直打哆嗦。这笔钱今天要是带不回去，只要一出门槛，天知道过两天他又会编出什么脏话来赖账。

我僵立在柜台前，牙齿把嘴唇咬出了印子，掌心被匣子棱角硌得生疼，可我死死不肯松手。

掌柜笃定吃死了我，慢条斯理地吹着茶沫子，眼神冰冷地等着我自己把骨头折断。

对峙了良久，我喉咙发干，从牙缝里硬挤出一句：“……就这一担？”

“就这一担十六套。”他立马撂下茶碗，眼神里闪过一丝得逞的精光，“痛快点，别把后头结账的客人都给堵在门口。”

“……成。”

那一个字从嘴里吐出来的时候，苦得像咽了一大口生黄连。

账房把铜钱一把推到我怀里，我低着头，一枚一枚数得清清楚楚，颤着手包进随身的蓝布兜里。掌柜麻利地提笔写了张新条子：十六套，半价，送齐验货后结清。我死死盯着他把数目和折价写得分明，逼着他按了指印。

旧账到底是要回来了。我揣着沉甸甸的铜板跨出门槛，脚步比来时快得多。路过街口的面包铺，那股麦香味直往鼻子里钻，我咬咬牙，破例摸出几个零碎铜子，买了两个刚出炉的热麦面包，拿干净帕子裹着抱在胸口带回家。

推开门，妹妹闻到面包香，听说旧钱全拿到了，高兴得眼睛发亮，立刻搬出藏在床板底下盛房租的铁皮小盒。我把该交房租的铜钱分给她，顺手从衣襟里抽出了那张皱巴巴的新价单，平平整整按在桌面上。

妹妹数钱的手停下了，凑过去看了一会儿，抬头轻声问我：“姐……这十六套新单子，怎么只剩下一半的数了？”

“他拿旧账的活钱压着我，”我低着头，声音发涩，“……我认了。”

妹妹没再多问半个字。她默默低下头，把手里的铜板一个、一个，轻轻放进了盒子里，屋里只有金属撞击的清脆响声。

桌上的热面包还冒着白气，可我毫无胃口。我把新条子挪到昏暗的油灯底下，借着微光，拿炭条一点点算着这十六套单子要耗掉的柴禾、粗碱和浆粉……算到最后，那点被折掉一半的工钱薄得像纸，连给妹妹扯半尺做新鞋面的粗布都不够。

小院里还晾着昨天没收透的湿布料，明早天不亮就得赶去河滩接着漂。]=],
        },
        {
            ["coversFacts"] = {
                "n07_candidate_bucket",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n07_candidate_bucket",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n07_candidate_bucket",
            },
            ["templateId"] = "tpl_n07",
            ["text"] = [=[今天去石鸥客栈，我不仅把收条贴着胸口放好，还天不亮就挑上了那整整十六套新洗好的大床单。

昨晚在院子里连夜晾好，天刚擦亮就收下来，熨干、折齐，四个角对得严严整整，连妹妹都揉着发红的眼睛爬起来，帮我用重木板压了整整两大摞。

进了客栈大堂，我把两只沉甸甸的木桶往柜台前一顿，横着扁担，死活不让跑堂的伙计往后院搬：“掌柜的，新货我挑来了。先算清旧账，再卸新担子！十二套加九套，二十一套洗浆工钱，白纸黑字是你自己画的押，今天必须当面结清。”

掌柜正打算给客人算酒钱，听我一口气念完了账目，脸上又堆起那副黏糊糊的笑，摆手说：“哎呀贝娅，你办事向来稳妥，大家都是老街坊了，何必大清早在这儿闹得人下不来台呢？”

我没像从前那样陪着笑脸，一把将写着“收讫无损”的纸单子拍在他面前：“掌柜的，收货的时候您白纸黑字写着没损，怎么一到付钱的时候就平白坏了两套？你那双验货的招子，难道一沾上铜板就瞎了不成？！”

大堂里正吃早饭的几个客商扑哧笑出了声。

掌柜脸上的假笑瞬间挂不住了，面皮青一阵白一阵。他啪地合上账本，冷冷盯着我：“贝娅，漂布巷会浆洗的妇人多得是，不是非你不可！嫌客栈的差事难伺候，你大可以滚蛋！”

“往后伺候不伺候另说，”我胸脯剧烈起伏着，一步不退，“今天先把欠我和妹妹的工钱交出来！”

他根本不接茬，扭头就冲后厨的伙计使眼色：“愣着干什么？把货搬进去，别耽误前头换房！”

两个粗使伙计上来就抓木桶的麻绳。我急红了眼，手里的硬杂木扁担横空一扫，狠狠架在桶沿上，厉声喝道：“放下！没给钱谁也别想碰！”

掌柜在柜台后头阴阳怪气地冷笑：“瞧瞧！钱还没摸着呢，倒先学会拿客栈的东西占山为王、要挟起东家来了！”

那一瞬间，我胸口那团火轰地一下烧毁了所有的理智——我在这刺骨的冷水里泡了整整两个月，两双手冻得皮开肉绽，怎么临到头，反倒成了我这个讨血汗钱的在要挟他？！

我死死攥着收条，转过头去同他厉声理论。就在这时，身旁的伙计猛地伸手去拽我的扁担，嘴里骂骂咧咧催我让路。

“滚开！”

我被扯得一个趔趄，咬着牙发狠猛地往回一抽扁担，只想把伙计的手甩脱。

可两只大木桶被扁担这么狠命一带，在脚底下猛烈一晃，沉重的湿木桶沿狠狠磕在了客栈高起的坚硬石门槛上——

“咚！”的一声闷响。

整整一挑压得整整齐齐的雪白床单，像雪崩一样，顺着倾斜的桶口稀里哗啦滑了出去！

客栈门外就是淌着洗菜水和污水的烂泥沟。

最上面的三四套白床单，直愣愣地铺进了那道乌黑发臭的污水坑里。

“啊——！”我尖叫一声，脑子里一片空白，扔了扁担扑通一声跪倒在泥水里，发了疯似地伸手去捞那些浸透了脏水的床单。可手刚碰到床单，掌柜已经跨着大步从柜台后头绕了出来。

他指着泥水里的我，扯开大嗓门，唯恐堂里的食客听不见：

“大家伙都睁开眼瞧瞧！这就是她口口声声洗干净的好东西？！拿这种发臭的烂抹布，也敢跑来找我结二十一套的工钱？！”

一股腥甜的气血猛地冲上嗓子眼，我气得浑身发抖，眼前阵阵发黑。我猛地站起身，冲他歇斯底里地吼：“这是刚才被伙计撞翻的！旧账是旧账，这十六套是这十六套，你不能混在一块儿赖！”

“我赖账？我还没找你赔这几床昂贵的细麻料子呢！”掌柜皮笑肉不笑地抱起胳膊，眼神恶毒得像条蛇，“想结账？行啊，先把这一地烂泥给我赔干净了再说！”

周围吃茶的客人都探着脖子看笑话。一个穿着体面的行商从门里出来，皱着眉嫌恶地抬了抬皮靴，踢开泥水里的布角：“要吵滚远点吵，别把污水溅在客人的衣服上！”

那一刻，四周所有的目光都像针一样扎在我的脊梁骨上。

我再也说不出一句话。

我咬紧牙关，慢慢蹲下身子，用颤抖的双臂，把那些浸透的沉重床单抱回木桶里。冰冷发臭的泥水顺着湿透的裙摆，一点点渗进了单薄的鞋袜里，冻得骨头节发酸。

我还得手忙脚乱地从泥水里抢出怀里的那叠收条，死死护在衣襟里，免得被脏水浸烂了最后的凭证。

收拾好最后一角，我还想着去找掌柜理论。可一抬头，大堂的伙计早就在拿拖把擦拭门槛边的水渍了，而掌柜的早已退回了账房。

“砰！”

那扇雕花厚木门当着我的面狠狠摔上了。

我扑上去死命拍门，拍得手掌通红。门里头，只慢悠悠飘出来一句冷酷的耻笑：

“先滚回去把你弄脏的东西洗干净了，再来同我谈银子吧。”

我僵立在门前，拳头攥得指甲陷进肉里，指缝里渗出泥水来。

我像个游魂一样挑着沉甸甸的脏木桶挪回了漂布巷。

门一推开，妹妹急忙迎上来替我卸担子。她掀开盖布的一瞬间，整个人僵住了：“姐……这床单怎么全湿透了？怎么……怎么这么脏？”

我靠在潮湿冰冷的土墙上，浑身发抖，牙齿打着颤：“桶翻了……钱，一个铜板也没要到。”

妹妹惊愕地看着我满身的污泥和湿透的布鞋，眼圈一下子红了。

我闭上眼，眼泪终于没能忍住，断了线似地砸在手背上：“是我……是我抽扁担的时候，自己把桶给掀翻了。”

屋里死一样的寂静。

妹妹没有埋怨我，甚至连一声叹息都没有。她默默转过身，从熄了火的灶台边提来仅剩的半桶干净井水，倒进了大洗衣盆里。

我咬着牙把床单一件件掏出来扔进盆里。黑黄的泥汤瞬间漫了上来，昨晚好不容易漂得雪白的地方，全得从头过一遍浓碱水。

悔恨、委屈和窝囊像刀子一样绞着心口。冷水一激，手背上那几道被寒风冻裂的血口子猛地炸开，钻心地疼。]=],
        },
        {
            ["coversFacts"] = {
                "n08_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n08_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n08_candidate_good",
            },
            ["templateId"] = "tpl_n08",
            ["text"] = [=[这顿家常饭我吃得干干净净，锅底那点甘蓝汤都被我拿黑麦面包蘸着抹了光。

丫头腻歪地爬到我膝头上坐着，手里攥着小木勺，“当当”敲着空粗瓷碗的碗沿。敲两下，仰着小脸脆生生问一句：“爹，你今天还去城头站岗不？”

我伸手抹掉她嘴角的面包屑，笑着说：“不去。今天爹哪也不去，就在家踏踏实实陪着你们娘俩。”

她娘坐在桌子对面，竹筒倒豆子似地把这几天集市上的碎嘴事讲了一长串：外城那个头一回独自出来卖萝卜的小丫头，把一篮子萝卜摆得整整齐齐；洗衣房那位娘子抱着一叠收条，说要一笔一笔跟客栈掌柜把工钱念清楚……

讲到一半，小院的矮土墙外头突然传来一串急促的脚步声。我这双耳朵下意识地动了动，可手腕稳稳端着碗没动弹，凝神辨出是隔壁送炭的脚夫，才不慌不忙舀了口炖甘蓝嚼着咽下去。

撂下碗勺，我才拎起那只裂了口子的旧皮靴，大马金刀坐到了青石台阶上。

穿好打了蜡的粗麻线，铜锥子稳稳扎透发硬的牛皮鞋帮。我一针一针数着针脚：一针扎下去，一针拉回来，不急不躁，倒真像哨所里换防点名一样规矩。等我拉紧最后一记死结，剪断线头，院子里的日头已经斜斜抹过了西墙。

黄昏里，丫头趴在门槛边托着下巴，眼珠子骨碌碌瞧着我拿布头擦亮铜锥子。今天我身上没系那条硬邦邦的宽皮带，整整一天，眼珠子也没往院门外头乱瞄过一眼。

她看了我半天，冷不丁拍着手咯咯笑起来：

“爹，你今天在家里，总算不像根直愣愣立在门边的破木桩子了。”]=],
        },
        {
            ["coversFacts"] = {
                "n08_candidate_slow",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n08_candidate_slow",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n08_candidate_slow",
            },
            ["templateId"] = "tpl_n08",
            ["text"] = [=[这顿饭吃得极慢，我拿木勺的手也沉，舀一口菜要在嘴里嚼上好半晌。

媳妇坐在对面，讲面包作坊那个要去做抄写员的伙计，被老板当着买面包的人数落了半晌。我耳朵里听着那些话音，脑子里却空荡荡的，像被潮水泡软的旧棉絮，不知道神游到了哪条街面上。

她瞧我眼神发直，伸手在我眼前晃了晃：“想什么呢，魂儿都被风吹走了？”

我猛地回过神，揉了揉鼻梁：“没想差事，就是脑子一下子空得慌。”

她没生气，耐着性子把刚才那桩事又讲了一遍，我才算把里头的人和事给接上茬。她笑着叹了口气，把温水推到我手边：“行了，人卸了甲歇着是好事，怎么这双耳朵也跟着歇了防，连家常话都听不全了？”

撂下碗去台阶上补靴子，手底下的活儿也拖得慢极了。粗麻线穿进针鼻，我捏着锥子在鞋帮前悬了半天，只觉得浑身骨头节都在发沉，总想就着日头再多犯一会儿懒。锥子搁在石阶上，我靠着门框歇了好一阵，拿起来缝了两针，又不由自主地搁下。

就这么磨磨蹭蹭的，日头从东边挪过了大半截土墙，我才勉强把鞋帮上那道裂口给缝严实。

这一整天里，小院里没人扯着嗓子喊立正集合，院墙外头也没人跑警哨，日子到底安安稳稳地滑了过去。媳妇在灶房里瞧着我的邋遢样笑出声时，我愣了愣，慢了半拍才跟着咧开嘴傻笑。

她回头看了我一眼，眼神软软的，没出声催我。]=],
        },
        {
            ["coversFacts"] = {
                "n08_candidate_wait",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n08_candidate_wait",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n08_candidate_wait",
            },
            ["templateId"] = "tpl_n08",
            ["text"] = [=[这个休日，我陷在椅子里坐得可真叫一个瓷实。院里的日光从东墙一寸一寸挪到了西墙，我就那么瘫在竹椅里，连一根小拇指都懒得动弹。

院墙外头杂乱的脚步声来来回回踩过去好几拨，换作往常，我早蹦起来，手就按上了腰里的短棍。可今天我连眼皮都懒得掀一下。

今天是彻底不绷着了——整个人像被抽了筋的皮影，松垮得不成样子。青石台阶上，那只皮靴孤零零歪倒在杂草边，鞋帮上的破口子依旧大大咧咧地张着嘴，灌了一兜风。

正午那会儿媳妇掀帘子喊“开饭啦”，我瘫在竹椅里从鼻腔里应了一声，心里懒洋洋地想着：再晒会儿背，再缓口气就进去。

等我真拖着发沉的双腿迈进灶房时，小方桌上的两只粗瓷碗早就凉透了。丫头坐在长凳上，拿那把光溜溜的小木勺在碗沿上“笃、笃、笃”轻敲了三声——学得有模有样，那是夜里哨所打更收尾的梆子声。

她娘没开口数落我一句，只是默默端起那盆凝了白油的甘蓝汤，放回灶上重新生火热了一遍，擦了桌子，轻声让我坐下慢慢吃。

热汤到底是喝进肚里了，可那是一碗凉过一回又硬热起来的汤，喝着泛着一股说不上来的沉闷。台阶上靴子的破口子，到天黑透了也依旧敞着嘴。

这一整天，我安静得可怕。就像哨所檐角下挂着的那根老更梆，安安稳稳歇在阴影里，可从早到晚，一次也没被人痛快敲响过。]=],
        },
        {
            ["coversFacts"] = {
                "n08_candidate_child",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n08_candidate_child",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n08_candidate_child",
            },
            ["templateId"] = "tpl_n08",
            ["text"] = [=[进屋端起热汤，炖烂的甘蓝就着昨儿烤好的黑麦面包，我连吃了两大块。

媳妇讲起街口卖面包的老头嫌冷，把摊子挪到巷子另一头晒太阳，害她大清早多跑了一趟路。我听得直乐。丫头也跟着咧嘴笑，举着小木勺非要给我添菜，可她胳膊短，甘蓝没递进碗，汤先滴在了我的膝头上。我赶紧拿空碗接住，夸她懂得给爹加饭，她便乐得合不拢嘴，又往里舀了一勺。

撂下碗勺，丫头扯着我的手不放，闹着要骑马。我还惦记着台阶上裂了口的旧皮靴，蹲下同她商量好，就背一趟，爹还得去补鞋。

结果这一趟根本下不来。我把针线暂搁在窗台上，背着她从门口走到水井边，又晃晃悠悠转到院墙角。她踢蹬着两只小脚，一会儿指着东边说马儿该去吃草，一会儿又说客人还没送到。媳妇出来晾帕子，瞧见我们在院里转圈，笑着打趣：“马丁守卫，那只破靴子是自个儿长了手在补呢？”

我脸上一热，说送完这趟就开工。可背上的丫头搂得死紧，趴在我耳根边讲隔壁小猫怎么钻进菜篮子偷鱼。院外有大车轰隆隆碾过石板路，换作平日站哨，我耳朵早竖起来了，今天我只顾着歪过头，听丫头说那只猫怎么被邻居撵得上房。

等把她从背上卸下来，我腰都酸了。我想伸手拿靴子，她又抱来一只空木碗，蹲在地上装石子，非要跟我开饭馆。我想着难得有个整日子陪她，鞋晚点补误不了事，便蹲下替她挑了几颗干净石子，认认真真拿十颗石子买了她一碗“好饭”。

媳妇忙完也搬了矮凳坐过来，一边纳鞋底一边同我讲隔壁的鸡。丫头在旁边瞎掺和，院里热热闹闹的。

不知不觉日头就斜过了西墙。丫头靠在她娘怀里直打呵欠，媳妇把孩子抱进屋，叫我歇歇腿。我低头一瞅，皮靴还在脚边歪着，鞋帮上的裂口大张着嘴，半针都没动。

我赶紧去窗台拿针线，可院里天色暗得快，粗线穿了两次才进针鼻。铜锥子刚扎下去，借着暮色就偏了道。媳妇挑帘出来瞧见，问我还看得清针脚不。

“光顾着陪她疯了，”我有些懊恼，“原想着吃完饭几下就拾掇好的。”

天彻底擦黑了，我只得把家什端进屋里。媳妇把油灯往我跟前推了推，腾出半边桌子，自己在旁边接着扯线纳底。我把浸蜡的粗麻线死死拉紧，问起下午邻居家那只鸡的下落。她笑了一声，就着灯影，把没讲完的话接着同我细细絮叨起来。]=],
        },
        {
            ["coversFacts"] = {
                "n08_candidate_military",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n08_candidate_military",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n08_candidate_military",
            },
            ["templateId"] = "tpl_n08",
            ["text"] = [=[进屋坐下时，满桌一盆热腾腾的炖甘蓝。

丫头挨着我坐，拿起木勺敲了敲碗沿，脆生生喊开饭。我眉头一皱，手掌下意识按住了她的手腕：“站哨点卯呢？吃饭就老实吃饭，敲什么碗。”

孩子愣住了，慢慢收回了勺子。看她两只脚在长凳下晃荡，我又沉着嗓子补了一句：“坐正了，别扭来扭去的。”

媳妇在对面笑了一声，替丫头圆场，说孩子是盼我回家高兴。我没接茬，把菜碗往丫头跟前一推，叫她少说话快吃。

媳妇舀着菜，聊起隔壁婶子家要办喜事、来借洗菜盆的事。我听完第一反应就是查账：“借的哪只？什么时候还？”媳妇说用完自然送来。我听着直皱眉：“家里天天要用的家什，借出去得定准日子，不能由着人拖。吃完饭你去要回来。”

媳妇脸上的笑淡了：“我还没说完呢，人家说好傍晚就送来。”

气氛僵了一下。丫头在旁边啃面包，把中间掏空了，剩个硬圈递到我嘴边：“爹，给你车轮。”

我看着满桌的面包渣，心里那股值岗挑刺的火气直往上窜：“吃就好好吃，粮食是拿来胡闹的？弄得满桌子都是，谁给你收拾？”

媳妇放下木勺擦桌子，说擦一把就成，让我别老挑刺。我心里烦躁，觉得她没规矩，顺手把桌上的碗勺挨个往里推得整整齐齐：“吃饭就得有个吃饭的样子，桌上乱七八糟像什么话。”

丫头吓得想讨好我，伸手去够汤碗想帮忙端，手一抖，木勺把滚烫的菜汤带翻了一滩。

我猛地一把攥住她的胳膊，嗓门一下子炸了：“叫你别乱动！听不懂口令是不是？！”

丫头吓得浑身一哆嗦，眼泪哗的一下掉了下来，哇哇大哭。

媳妇一把将孩子搂过去，拿围裙擦着她手上的汤水，猛地抬头瞪我，眼圈都红了：“马丁！她才四岁！你吃这一顿饭，下官威下到自己闺女头上了？！”

我僵在桌边，看着丫头哭得直抽噎。难堪和懊悔像冷水一样浇下来，我嗓门立刻塌了：“我……我就是怕烫着她，没想凶她。”

没人理我。媳妇只顾着拍着后背哄孩子。桌上的甘蓝汤凉透了，我像个犯了军规的蠢兵，硬着头皮把剩下的冷饭扒进肚里，低着头溜出了屋。

坐在青石台阶上，我闷声不响地补靴子。铜锥子扎进厚牛皮，粗麻线狠狠勒紧，当值的手艺没丢，三下五除二就把裂口缝得死死的。可听着屋里丫头抽抽搭搭的声音，我心里堵得喘不过气。

我把手洗净钻进屋，半蹲到丫头跟前，小声赔不是：“丫头，爹刚才嗓门太粗，是爹不好，别生爹的气。”

孩子抱着木碗，红着眼圈看我，小声问能不能用石子做饭。我赶紧说能，爹去给你捡。

她却往后缩了缩，摇摇头：“不要爹。我要娘陪我玩……爹坐远一点。”

那一句话扎得我胸口生疼。

我没敢争辩，默默搬了张矮凳坐到最墙角。媳妇在地上铺了块旧布，陪她把小石子一颗颗摆进木碗里。我就那么缩在阴影里看着，再也没敢张嘴说一个字。]=],
        },
        {
            ["coversFacts"] = {
                "n09_candidate_good",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n09_candidate_good",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n09_candidate_good",
            },
            ["templateId"] = "tpl_n09",
            ["text"] = [=[午后，鲁本准时来了，穿了一身浆洗过的干净衣裳，手里紧紧攥着那顶褪了色的旧毡帽，拘谨地坐在长桌对面。

我没说多余的客套话，将两份发黄的契纸并排摊在桌上，就着窗外透进来的天光，从第一行起，一字一句往下念。念到关于修渠抵扣地租那一条，他那份副本上用铁胆墨水写得清清楚楚，而庄园的底册里那一栏空着。

我当即让人去档案室取来最初那份盖着家徽红印的原约，又一并抱来了当年修渠那几个月的劳工活计簿。

渠是哪一春挖的，鲁本领着几个佃户出了多少整工，该折算成多少工钱、如何分摊进往后几年的地租里——那些陈年的旧账簿上用炭笔记得一清二楚，每一笔都盖着管事的小印。

两相对照，事情就彻底明白了，是账房里那位老眼昏花的抄写员誊录底册时，粗心大意漏抄了这一整条。

错在庄上。

我清清楚楚认下了这桩错：“是我庄园办事不周，抄漏了字句，不怪你。你这几年按约少交的谷子，本就是你当年拿汗水挣下的工钱，一笔都不算欠。”

我随即取来新纸，照着原约的字句，亲手将修渠那一行工整地补回了底册。两份纸重新誊抄清楚，主仆二人头挨着头又仔细看了两遍，确认无误后，各自收执一份。

鲁本起身，小心翼翼地把新契纸叠好，妥帖地揣进怀里。走到书房门口时，他回过头，像是卸下了千斤重担，声音也比进门时亮堂了些：“夫人，那明年秋里交租，还是照着老日子来对账吗？”

“还是老日子。”我说。

他应了一声，脚步轻快地走了。

晚上妹妹进来，随手翻了翻我补好的那本底册。她的指尖在修渠那一条新添的墨迹上停了片刻，合上账本，淡淡说了一句：“这回字里行间都对得上了。”

我点点头，把蘸饱了墨的笔尖重新对准了下一份旧契。

“剩下的那些旧契，都照着这个法子重新对一遍。谁家少抄了，都给他们一并补回去。”]=],
        },
        {
            ["coversFacts"] = {
                "n09_candidate_doubt",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n09_candidate_doubt",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n09_candidate_doubt",
            },
            ["templateId"] = "tpl_n09",
            ["text"] = [=[两份契纸对到修渠那一行，鲁本刚要开口解释，我就不由自主地截住了他的话头。

我盯着他那份副本上深色的墨迹，心里那股不信任的劲儿还是冒了出来：“这份抄本是哪一年到你手里的？誊写的先生是哪一位？为什么单单这条关键的约定，只出现在你的抄本上，而庄园的底册里却找不到？”

我把那几句盘问翻来覆去地讲，像审讯官一样咄咄逼人。他一开始还耐着性子一连答了三遍，到最后，他只是沉默地把那张单薄的纸往我这边推了推，抿紧了嘴唇，不再开口为自己辩解。

后来我让人取来旧档，事情很快查清了，确实是庄园账房的疏漏。我当即拿出笔，将底册上的数目改了，两份租契也重新誊写了一遍。誊好后递给他时，我垂下眼，轻声承认：“鲁本，方才是我失礼了，那些话问过了头。”

他接过那张新纸，小心折好，只回了一句“知道了”，没再多说半个字。

他起身告辞的时候，后背的肩膀绷得像块石头。

账是算清楚了，可这场对谈，到底没有我先前预想的那份磊落与从容。]=],
        },
        {
            ["coversFacts"] = {
                "n09_candidate_hedge",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n09_candidate_hedge",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n09_candidate_hedge",
            },
            ["templateId"] = "tpl_n09",
            ["text"] = [=[念到修渠那一行，两份契纸明明白白地对不上了，他那份抄本上写得清楚，庄园的底册里却空着。

我心里其实已经有了七八分数，可就在那一瞬间，窗外那堵稀稀疏疏的篱笆墙猛地刺痛了我的眼睛。我没再往下念，而是将契纸往旁边一推，冷冷地抬起头，先问他：“鲁本，去年秋里你那车甜菜撞折了我的花篱，这笔账你打算怎么算？”

我甚至没等他答话，便又紧接着追问：“你这份抄本，这些年里到底有没有动过手脚？”

他被我这突如其来的诘问弄得满脸通红，嘴唇哆嗦着说：“夫人，当年的原约就在您的柜子里，您尽可以先取出来看！”

我没有去拿。

那股压抑了一整年的火气像开了闸的洪水，话一句比一句尖刻，账还没对完，我就把去年那半架蔷薇数落了个底朝天。

他攥着手里的旧毡帽，脸先是涨得像块猪肝，后来渐渐褪成了死灰。最后，他什么也没说，只是默默站起身来。

后来我到底还是让人取来原约，照着上面的字句把账目改了回去。等我把新租契誊写到一半时，抬头再看，他对面的椅子已经空了——人早就出了庄园的大门。

账面上的黑白字迹，错了能改。可今天这半个时辰里烧起来的火，是从去年那半架花篱的旧怨上引过来的，最后却劈头盖脸全烧在了他的脸上。

那几句说出口的刻薄话，像泼出去的水，再也收不回来了。]=],
        },
        {
            ["coversFacts"] = {
                "n09_candidate_grace",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n09_candidate_grace",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n09_candidate_grace",
            },
            ["templateId"] = "tpl_n09",
            ["text"] = [=[鲁本把旧契平摊在长桌上，我让管事取来了最初的原约与出工簿。三份纸并在案头，修渠抵租的约定赫然在目，唯独庄园底册上空了那一行。

我心里松了口气，事由很清楚：是账房誊抄时漏了笔，错在庄上。我提笔重誊租契，鲁本在对面垂手候着，管事立在我身后，殷勤地帮我按平纸角。

落完最后一笔，我本该抬头对他说句公道话，认下庄园的疏漏。可管事就在身后看着，话到嘴边，我的舌根竟有些发僵。在这白桦庄园里，向来是我查旁人的错漏，如今要当着下人的面承认自己险些讹扣了佃户的谷子，脸面实在下不来。

我搁下笔，把新契推过去，语气端得一如往常般平稳：“修渠这一桩，我准你照旧折抵。先前让你补交的，便免了。”

管事一听，立刻凑趣冲鲁本笑道：“夫人仁厚体恤，你这下可安心了吧。”

这话刺得我耳廓微烫。那些谷子分明是鲁本拿汗水换来的，白纸黑字早有定数，哪轮得到我来施舍恩典？可有人替我把台阶搭好了，私心里图省事，我便端起水杯抿了一口，任由这话滑了过去。

鲁本按着新契没动。他盯着纸上的字，小心翼翼地问：“夫人，这数目……还是当年定好的工钱吧？”

“数目未变，往后照此交纳。”

他仍没收纸，迟疑着轻声问，前几年已经折抵的谷子，账房会不会还私下记着欠账。我有些着恼，觉得文书都改了，何必如此多心。可一触到方才那个虚伪的“免”字，心底又虚得厉害，只得翻开收租簿，强耐着性子把往年的账一笔笔勾销给他看。

“都不算欠，你不必补交。”我说。

听了这句实底，他的肩膀才彻底松垮下来，小心把新契折进怀里。出门时管事提醒他谢恩，他在门槛边停了停，躬身道了谢。我应了一声，自己听着都觉得干瘪难堪。

人走后，我把旧契收进抽屉，心里堵得发沉。鲁本方才问起工钱时，我有好几次机会把话说正，偏偏全让我拿冷冰冰的数目搪塞了过去。]=],
        },
        {
            ["coversFacts"] = {
                "n09_candidate_grain",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n09_candidate_grain",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n09_candidate_grain",
            },
            ["templateId"] = "tpl_n09",
            ["text"] = [=[鲁本来对账时，我手边已列好了这几年他“短交”的谷石细数。底册摊在案上，我把数目冰冷地念了一遍，问他几时能把亏空补齐。

他大惊失色，忙从怀里掏出磨破的旧契，争辩说当年修渠出力，每年少纳一袋粮是庄上应允的。我扫了一眼那行字，见底册上没有，便冷声反问为何庄园存底不见分毫。

他急得满头大汗，求我把柜里的原约取出来当面对质。可我正为庄上开支犯愁，心想庄园收租向来依底册办事，哪能容他家自立规矩？嘴上便硬邦邦地推脱，说先把欠收的补齐，原约改日得空再查。

鲁本把毡帽死死压在膝头，嗓门带了哭腔：“夫人，取张纸不过眨眼的工夫！我手里是庄上的字据，柜里的也是庄上的底，查明白了再收不行吗？”

这话听得我极不顺耳。他越是急躁逼迫，我越觉得不能让一个佃户在书房里牵着鼻子走。规矩是规矩，催收是催收，既然底册上没记，他就得先把短额垫上。

我唤来管事，将催收单递过去，吩咐傍晚便带车去鲁本家运粮。

鲁本猛地站起身，脸色惨白：“夫人连原约都不看便要抄粮，是认准了我手里的字据作废了吗？！”

“庄上百十来户，不能由着各人的口舌办。”我偏过头去，“查实了若错在庄上，自会退还予你。”

他说仓里早没余粮了，甚至还有留作开春播种的种粮。我心里清楚这笔罚数极沉，可管事已经领命，我不愿当众收回成命折了威严，只冷冷让他回去备好，休叫庄上的板车空跑。

他僵立片刻，一把夺回自己的旧契，攥着帽子跌跌撞撞出了门。

临近傍晚，管事满头大汗地回禀，说欠粮已全数拉回，正往大仓里卸。话音未落，妹妹便抱着沉重的陈年档案撞进门来，脸色铁青，进门就问我为何强征鲁本家的口粮。

她将当年修渠的原约与活计簿狠狠拍在我面前，手指按在那行抵租的墨迹上，一字一顿念了出来。

字句、年月、印章，与鲁本手里那张分毫不差。

我脑子里嗡的一声，立时慌了手脚，急声催管事：“快！把车套上，立刻原样送回去！”

管事脸色煞白，结结巴巴地说：“夫、夫人……鲁本家仓底掏空了也凑不齐，拿出了留种的麦子，剩下的还是跑去邻居家硬借的……方才伙计们贪图省事，车一进仓，已经把那几袋连同种粮……一并倒进公粮堆里了……”

“谁准你们倒的？！”我气得发抖，话一出口，后半截却生生噎在了嗓子里。

是我亲口吩咐的“先收归仓，查实再退”。仆从不过是奉命行事，真正作恶的，是我手里的傲慢。

我提起裙摆一路赶到粮仓。几只空麻袋歪倒在墙根，金黄的麦子混成了一座小山，哪一粒是能出芽的良种，哪一粒是寻常的陈粮，早已肉眼难分。

“把借邻人的几袋照数称足，立刻送回去！”我厉声吩咐，“再去庄上把懂挑良种的老农全请来，挑够了种粮给鲁本送去！”

管事连声应承，却面露难色：“天全黑了，这大粮堆里连夜也筛不完啊……”

院门外传来了低微的啜泣声。鲁本就守在门廊下，他是特意跑来求管事别动那袋救命种粮的，没承想已全倒进了粮海。

我迎着冷风走过去。看着他佝偻的身子，我的领主架子碎得一干二净，低头哑声道：“鲁本，庄上查明了，底册确实抄漏了字。粮不该收……是我办错了。”

他怔怔看着车板，没接我的赔罪，声音干哑如裂帛：“夫人，求您先把借隔壁的几袋还了……天寒地冻的，人家也指着下锅度日。”

“我让管事亲自押车去还，当面把庄园误征的原委说清。”我紧攥着冰凉的手指，“至于你的种粮，我会让人挑，在冬天之前，一粒不少给你送回仓里。”

他转过身，默默扶着车辕，踩着碎泥走了。

车辙声远去，妹妹将那张泛黄的原约递回我手里，一言不发。

我捧着那张轻飘飘的纸，指尖抖得厉害，羞愧得连头都抬不起来。]=],
        },
        {
            ["coversFacts"] = {
                "n10_result_3",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n10_result_3",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n10_result_3",
            },
            ["templateId"] = "tpl_n10",
            ["text"] = [=[第二天我起得比打鸣的公鸡还早。

作坊门还没卸门板，我就先把那个沉甸甸的铁皮钱匣子搬上了案台。就着清晨那点青亮的天光，我用裁好的粗草纸把钱包起来，塞进怀里贴肉的兜里，抬腿就往医馆奔。

清早巷子里有早起的街坊冲我打招呼，我没停脚跟人闲扯，只闷头点了下头，步子迈得又大又急。

到了医馆，我把草纸包往柜台上一拍，把诊费药钱交了个干干净净。伙计把压了三天的催单当面划掉、递还给我。跨出医馆门槛的那一刻，清晨的凉风迎面吹过来，我站在青石台阶上狠狠吐了一口浊气，这才觉得胸口那块压了三天的死木头，总算被风给吹散了。

走回作坊，米洛已经在窗根底下的木墩上坐着了。

我把他叫到案台跟前，看着他的眼睛：“从今天起，这半个月你就给我在家里老老实实歇着养骨头，隔三天去医馆换一回药，药钱我已经记在作坊的账上了，不用你掏一个铜板。”

孩子愣在了原地，嘴唇动了动，小声问我：“师傅，那我……哪天能回来上工？”

“满半个月那天。”我拍了拍他没受伤的那边肩膀，“少一天，你都别想跨进我这道门。”

他默默把那只伤手重新套回胸前的灰布带里，规规矩矩应了声“好”。

吃过午饭，我换了件干净褂子去了石鸥客栈。跟掌柜商量六把靠背椅的交付日子，交货得往后延十天，我会先把打好的头两把送过来给他应急，剩下的四把，我夜里点着油灯赶出来。

掌柜盯着我看了半天，在心里盘算了盘算，到底念着我手艺扎实，点头应下了。西街铺子那边本就是熟客，听说我正给客栈赶急活，只交代我把榫眼的尺寸拿捏准，多等几天无妨。

天擦黑回到家，那碗热腾腾的汤盛上来，我一口气喝了个底朝天。吃完饭，我挽起袖子把作坊里的油灯添满油，坐到案板前，握着墨斗，开始给客栈那一批椅子下料。]=],
        },
        {
            ["coversFacts"] = {
                "n10_result_2a",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n10_result_2a",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n10_result_2a",
            },
            ["templateId"] = "tpl_n10",
            ["text"] = [=[第二天一早，我把铁皮钱匣子抱上案台，数好医药费，用粗纸妥帖包好。

可我手指头还没来得及从匣子边缘抽回来，门板就被人“砰砰”拍响了——又是石鸥客栈那个跑堂的伙计。他一步跨进门槛，探着脖子高声嚷嚷：“雅各布师傅！那六把靠背椅到底什么时候送来？掌柜的可等着摆大堂呢！”

前头两天我每回刚要动身都被打岔，今天又添上他站在门口这一顿催。看着他那张急赤白脸的模样，不知怎么搞的，胸口压了这几天的憋闷和窝囊火，轰地一下全冲上了脑门。

我猛地抬起头，一把将手里的粗布抹布摔在案上，红着眼睛顶了回去：“催催催！催什么催？！木头得一寸一寸拿刨子推、榫眼得一凿一凿对，我是个做木匠的，又不是街头变戏法的！还能平白给你变出六把椅子来？！”

话音砸在地上，整间屋子里瞬间死一样寂静。

跑堂的被我吼得愣在门口，脸上一阵青一阵白。窗根底下，米洛把头深深低了下去，伤手下意识地往胸口缩了缩。

跑堂的冷哼了一声，撂下一句“我如实回掌柜去”，甩着袖子扭头就走。

屋里静得吓人。我站在案板前喘着粗气，胸口那团火烧过去，剩下的全是懊恼和难堪。我揣上纸包，低着头快步赶去医馆把账结了，回来又硬邦邦地跟米洛把歇工的规矩交代清楚，直到太阳快落山，才赶着晚集去客栈给掌柜陪着笑脸赔不是，硬着头皮把交货的日子往后拖。

事情到天黑到底全办完了。可每一桩，都比最该办妥的时辰晚了一大截。

早晨在门口冲着跑堂吼出的那句混账话，像一块发了馊的湿木屑，恶心兮兮地卡在门槛边，收也收不回来了。]=],
        },
        {
            ["coversFacts"] = {
                "n10_result_1a",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n10_result_1a",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n10_result_1a",
            },
            ["templateId"] = "tpl_n10",
            ["text"] = [=[第二天门板一卸，作坊里就没断过人。

先是隔壁铁匠来借粗锉刀，接着是几家常客来结上个月的碎账。其实到了晌午那会儿，我脑子里猛地闪过医药费和交货日子的事，手都已经摸到了案角那张压着的单子上。可偏偏就在这时，一个生面孔客商踱步进门，指名要挑几块上好的硬杂木料。

我像是抓到了什么救命稻草一样，领着他在堆料的后院里转悠了大半个时辰，一块木头一块木头地敲给他看。等把客商送出巷口，那几件顶要紧的正事，又被我自欺欺人地抛到了九霄云外。

等我猛然惊醒过来的时候，外头的日头已经落尽了，天色擦了黑。

一天过去了。该交的钱、该报的期，我一件也没动。

昏暗的油灯下，米洛依旧坐在窗根底下的旧木墩上。他胸前吊着那只裹得严严实实的右手，就那么安安静静地看着我和另一个学徒埋头刨木头，一双眼睛在暗处黑黢黢的。

我手里的刨子越推越重，那双沉默的眼睛像针一样扎在我的后背上。心底那股被愧疚和拖延逼疯的焦躁，不知道怎么就扭曲成了一股无名火。我死死盯着他那只吊着的胳膊，嘴唇一动，刻薄的话竟然不受控制地从牙缝里挤了出来：

“骨头又没折，皮肉伤而已……就真得歇足半个月？”

话刚一出口，我自己的心就猛地沉到了底。

米洛坐在阴影里，整个人僵住了。

他慢慢抬起左手，把挂在脖子上的吊带取了下来。然后，他低着头，伸出完好的左手手指，捏着右手那层泛黄发灰的粗布条，一圈、一圈，极慢地把它解开。

染着草药汁和血痂的布条散落在地上。在昏黄的油灯照映下，他整只右手肿得像块烂木头，手背上那道皮肉翻卷的伤口狰狞地泛着暗红，连皮带肉都紧绷着，稍微一动就往外渗着黄水。

我只看了一眼，眼皮就像被烙铁烫了一样，狼狈不堪地把头扭开了。

屋里静得只有刨花落地的细微沙沙声。

米洛依旧没说半个字。他只是低着头，动作极其缓慢地重新捡起布条，一下、一下，重新将那只烂手缠紧、挂回脖子上。缠完，他默默把身子往阴影里缩了缩，重新坐回了那个矮木墩上。

案角处，医馆那张发皱的催单依旧在冷风里翻着边角，客栈和铺子的交货期我也都没脸去报。

案台最深处，那个铁皮钱匣子冷冰冰地躺在黑暗里，里面的铜板整整一天我都没碰过。]=],
        },
        {
            ["coversFacts"] = {
                "n10_result_2b",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n10_result_2b",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n10_result_2b",
            },
            ["templateId"] = "tpl_n10",
            ["text"] = [=[天刚亮，我便揣着包好的铜币赶去医馆。伙计验了钱，把催单划去，我又预支了往后半个月换药的开销，心里那块悬着的石头总算落了地。

回作坊后，我把收条递给米洛，打发他回家好生歇足半个月。小徒弟应下了，左手提着两件换洗衣裳出了门。看着他走远，我浑身筋骨一轻，觉得这拖了三天的难事，大清早便完成了一半。

午后去石鸥客栈，掌柜冷着脸问六把靠背椅还要等多久。我原打算宽限十天，可一见他眉头拧紧、拿眼角斜我，嘴里那句话不知怎么就缩了回去。

“后天一早，”我脱口而出，“六把一并给你拉来。”

掌柜有些吃惊，反复问我作不作准。我拍着胸脯打包票，说头两把早就落停，剩下四把夜里多点一盏灯，一准误不了。转头去了西街铺子，为了图个利索，我也脑子发热把柜门的交期硬压在同一天。

那晚回到家，我那口子听完交期直犯嘀咕，问这两天到底赶不赶得出来。我端起热汤连喝了几大口，嘴硬说以前赶活手里有谱，心里却在发虚。

一回作坊，把木料往案上一摊，我冷汗就下来了——剩下四把椅子的料，有两根根本还没刨平，榫头也只划了线；墙边立着的柜门，甚至连合页的槽都没开。

那两夜，作坊里的油灯直直熬到天亮。我两臂酸痛得快抬不起来，可一坐下喘气，脑子里全是字据上的日子，只能咬着牙爬起来接着推刨子。

到了约定的清早，石鸥客栈的板车准时堵在了门口。伙计进屋一点，能搬的只有四把，剩下两把还散在案上没装靠背。伙计当场把字据摔在台面上，指着上面的“六”字直嚷嚷：“掌柜的大堂都腾空了，缺下的两处叫谁来坐？！”

我脸上火辣辣地烧着，刚结结巴巴赔不是，西街铺子催柜门的伙计也跨进了门。

两家的人并排在门口冷眼瞪着我。我站在案板前，冷汗浸透了衣背，手底下还差着多少工夫我心里清楚，今天就算把我劈成两半，也交不齐这批活。

我只得赔着笑脸，求客栈先把四把拉走，余下的我上门给掌柜低头认罚；回头又赶到西街铺子，硬着头皮向东家赔礼求宽限。西街掌柜倒没骂街，只是冷冷撂下一句：“雅各布师傅，往后嘴上报日子前，先低头瞧瞧自个儿的案台。”

回到作坊，我把两张新改的字据压在案角，手还在抖。看着满屋子散乱的木料，我抹了把脸上的冷汗，叫徒弟把柜料搬过来，欠下的工，只能重新安排。]=],
        },
        {
            ["coversFacts"] = {
                "n10_result_1b",
            },
            ["excludesFacts"] = {},
            ["id"] = "frag_n10_result_1b",
            ["kind"] = "key",
            ["overrides"] = {},
            ["priority"] = 0,
            ["requiresFacts"] = {
                "n10_result_1b",
            },
            ["templateId"] = "tpl_n10",
            ["text"] = [=[清早去医馆把药钱结清，我心里踏实了许多。回到作坊，我把盖了印的收条塞给米洛，让他踏实回家养手，半个月内千万别碰重活。

小徒弟接过单子看了看，轻声应了，提起地上的布包准备走。

可他还没迈出门槛，拉木料的大车便堵住了巷口。车夫催得急，嚷着后头还要赶送别家。另一个徒弟正在后院腾料架，我单手吃不住劲，扛起一根长原木想先挪进屋，木料尾巴却死死卡在了门框上。

米洛停下脚，迟疑着问：“师傅，用不用我帮着扶一下？”

瞧见他胸前挂着的布带，我本该喝住他，叫后院的徒弟过来。可车夫在外头一声接一声地催，我贪图省事，便随口道：“行，用左手替我托一把板尾，只借个巧劲转过门框，不用你使死力。”

他把布包撂在门边，伸出左手照办。板子转过来了，我两手搬得发酸，又顺嘴支使他：“再帮我往后送送，靠到墙根才稳当。”

他单手够得吃力，半个身子都往前倾。我嘴里喊着“慢点”，手里却推得飞快，满心只想着赶紧卸完车，好腾出工夫去各家报交期。

长木料靠稳后，他又弯腰去拾布包。我扫了一眼车板，见还剩下几根短料，心头一松，又叫住了他：“先别走，这几根短的轻巧，你顺手拿左手抱进来，省得来回折腾。”

米洛看了看胸前吊着的右手，站在原地没动。

我有些起急，皱起眉来：“方才大板子都扶了，这几根短料算什么重活？搬完你就走，耽搁不了你几步路。”

他把头埋了下去，咬着唇，用完好的左手抱起两根短木往屋里挪。

我刚转身同车夫核对数目，冷不丁听见背后“咚”的一声沉闷巨响！

米洛跌坐在门槛边。一根木料脱手砸在地上，另一根横压在他大腿上。孩子慌了神，原本吊在胸前的伤手本能地抽了出来，下意识按在木头底下想去抢救。

我扔下炭笔冲过去掀开木料。

米洛整张脸煞白如纸，身子抖得像筛糠。他死死缩回右手，裹伤的灰布上，一层刺眼的鲜血正迅速洇开。他咬紧毫无血色的嘴唇，吓得连喊疼都不敢，只是带着哭腔哆嗦：“师傅……料没砸坏，我真不是故意松手的……”

那一刻，我浑身的血轰的一下凉透了。

我一把扶他坐上矮凳，手忙脚乱地想看他的伤，可他缩着胳膊，用左手死命抓着吊带想往脖子上套。

“师傅，我不疼，我不是故意的……”

看着那片迅速渗开的血迹，我喉咙像被滚水烫过一样，半个字都吐不出来。他本可以在家踏实养伤的，是我为了图自个儿省事，一句接一句地硬给他添活。说好歇半个月，我甚至连这半个早晨都没舍得让他歇完！

我叫停了手头的活，抓起他的布包，半扶半拽地领着他直奔医馆。

一路上他右手紧紧护在胸口。我伸手想替他托着胳膊，他身子却微不可察地往旁侧偏了偏，小声说自己能走。

进了医馆，伙计一见绷带上的血，愣住了。我低着头，声音细若蚊蝇，把早晨贪图省事叫他搬料的原委全招了。伙计没接我的话，沉着脸进去请医者。

我陪米洛坐在长凳上，如坐针毡。他脚边的布包散了口，露出一角洗得发白的旧布，我默默蹲下身替他塞好，哑着嗓子说：“米洛……今儿看完了就回家。作坊里的活归我，往后半个月，天塌下来你也不许碰一指头。”

他垂着眼睫，过了好久才轻轻问了一句：

“师傅……那要是下回您再喊我搭把手呢？”

那句话像烧红的凿子，狠狠扎进我的心窝里。

我脸上烫得无地自容，闭了闭眼，从牙缝里挤出回答：“……是师傅今天做事浑账，说了不算，全是我的错。”

医者掀帘子招手叫米洛进去。

我刚想跟上去，米洛已经自己咬着牙、护着胳膊，慢慢迈进了内屋。

我独自僵立在长凳边，听见里头的大夫问他哪处疼，心口像被重锤狠狠砸碎了一样发疼。]=],
        },
    },
    ["letters"] = {
        {
            ["address"] = "灰港铁锚巷12号 二楼",
            ["appearCondition"] = {
                ["dayMin"] = 1,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫埃利亚斯·沃德，在灰港码头搬了十几年货。我和在面包坊帮工的妹妹合住铁锚巷，靠两份工钱付房租和饭钱。

这阵子实在很累，脑子里像塞了团湿棉花，沉得抬不起头。白天站在码头边，明明{{困}}得眼皮直打架，{{合上眼}}又全是杂乱的动静：浪头撞在栈桥上的响声、绳索绷紧的吱呀声，还有同伴喊数字的粗嗓门。今天扛箱子走到斜坡上，腿一软差点把货砸了。隔壁的汉克伸手{{帮忙}}顶了一把，还以为是我肩膀的旧伤又发作，问我是不是该歇歇。我{{没好意思}}跟他说，我是因为困得{{神志不清}}，连脚下有块水渍都没瞧见，只能顺着他的话含糊应了一声。要是因为箱子搬不稳，工头少{{算}}我几铜板就不好了。

妹妹在面包坊帮工，每天天不亮就走，晚上回来时身上带着一股甜面粉的焦香味。她总把没人要的面包边带回来吃。我知道她想省下钱买新鞋，她那双鞋底都磨透了，一下雨就往里渗水。昨晚我俩围着火炉烤脚，她把鞋垫抽出来贴在铁罩子上，刺啦一声冒出一股水汽，她自己反倒先{{乐了}}。我也想笑，可笑完又觉得心酸。要是我这阵子能多搬几趟重货，早就够给她换双像样的麂皮鞋了。

昨晚迷迷糊糊{{梦见}}母亲了。她还是坐在旧桌子旁，就着油灯缝我那件破棉袄，嘴里轻声哼着小时候哄我睡觉的歌调子，针脚又密又齐。梦里我靠在她腿边，听着哼唱声和灯芯偶尔劈啪的那一声，心里特别踏实，真想就这么一直睡下去，永远别醒。可睁开眼，屋里只有冷冰冰的墙，还有墙缝里渗进来的海风。我也想把这些旧事都{{忘记}}，省得醒来心里空落落的，可真要是连这样的梦都没了，又舍不得。

我只希望哪天能安安静静地过一晚上，让我踏踏实实睡觉，第二天起来还有力气干活。

埃利亚斯·沃德

灰港铁锚巷12号 二楼]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_elias_sleep_alt",
                "word_candidate_elias_sleep",
                "word_candidate_elias_trust",
                "word_candidate_elias_fear",
                "word_candidate_e01_c1",
                "word_candidate_elias_reason",
                "word_candidate_elias_happy",
                "word_candidate_elias_dream",
                "word_candidate_elias_forget",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_pa_01",
            ["followupTemplateId"] = "tpl_pa_01",
            ["id"] = "letter_pa_01",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_pa_01",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "埃利亚斯睡好一晚，次晨能工作",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["sleep"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 80,
            },
            ["selfIntro"] = "来信人：埃利亚斯·沃德",
            ["senderId"] = "npc_passerby_a",
            ["title"] = "码头来的第一封信",
        },
        {
            ["address"] = "灰港铁锚巷12号 二楼",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_pa_01",
            ["id"] = "letter_pa_01_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_passerby_a",
            ["title"] = "埃利亚斯·沃德的回信",
        },
        {
            ["address"] = "灰港 铁锚巷8号 晨炉面包坊",
            ["appearCondition"] = {
                ["dayMin"] = 2,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫卢卡，今年二十二岁，在铁锚巷的“晨炉面包坊”当伙计，一晃干了四年。平时除了揉面生火，我也常替巷子里的街坊代写家信。街坊们大多大字不识，话说得前言不搭后语，我就耐着性子{{多问几句}}，理顺了写下来，封口前再一字一句念给他们听。

前些日子，城里的老抄写员到铺里买黑麦面包，正撞见我伏在柜台边替码头脚夫写信。他在旁边站着看了好一会儿，临走前冷不丁问我：“年轻人，愿不愿意跟我去当学徒？我年纪大了，眼睛不大顶用，想找个踏实人打下手。工钱虽说比不上大工匠，但能跟着学正经的抄写和誊录。”

我当时只当是老先生随口说的{{客套话}}，直到他补了一句，让我第二天带几张自己写的字去他家，我胸口才猛地一跳——他是认真的。

那天铺子打烊后，我点着蜡烛写到了后半夜。我反复挑出几张墨迹最干净、没涂改过的字，小心翼翼压在床板底下。第二天清早拿出来时，纸角还是被潮气给卷了边。我{{怕}}指甲缝里的面粉弄脏了纸，在井边就着冷水死命洗了两遍手，才把纸样揣在怀里送过去。

老先生戴着厚镜片看完了，点了点头，说我可以留下，让我回面包坊把铺子里的活计安排妥，三天内给他个准信。从他那间满是墨水味的屋子里出来时，我整个人高兴得像踩在棉花堆上，回铁锚巷的一路上，脑子里全在盘算该怎么跟老板开口。

老板当年收留我时，我才十八岁，骨瘦如柴，连一整袋黑麦面粉都扛不动，脱了手撒得满地都是，最后还是他{{骂骂咧咧}}帮我扫起来的。这四年里，他教我发面、看火候，还腾出阁楼上一间小隔间让我住，这些情分我都死死{{记在心里}}。我原本打定主意要跟他推心置腹地好好谈：我可以多留一个月，哪怕工钱减半，等他招到新人、我把新手教出来了再走。

昨天下午铺子里难得清闲，我搓着手，{{壮起胆子}}把这事提了。

老板听完，手里的抹布一摔，当场嗤笑出声：“给不识字的邻居写两封家信，还真当自己是能进官署的抄写官了？人家随口两句{{漂亮话}}捧捧你，你就不知道自己骨头有多重了！”当时柜台前还站着两个买面包的熟客，老板顺手往我脑门上一指，冲着客人大声嚷嚷，“你们瞧瞧这小子，刚来店里那会儿，连三个铜子儿的面包钱都算不明白，如今心气高了，倒琢磨着去替行会大老爷管账了！”

熟客们哄堂大笑，嘴里嚼着面包跟着起哄。我站在灶台旁，耳朵烧得滚烫，可人在屋檐下，也只能陪着干笑两声，讷讷地说“还没定下呢，就是先问问您”。

老板摆了摆手，把一摞刚出炉的滚烫铁烤盘塞进我怀里，这事就算被他硬生生掐断了。

整整一下午，我光着膀子在烤炉前搬烤盘，汗水砸在石板上滋滋地响，心里那股{{火气}}越烧越旺。他说我算不清账，那分明是我刚进店第一周的事！这三年里，铺子早市的柜台哪回不是我一个人盯着？账本收据全是我归拢的，我经手的账目，何曾短过他一个铜子儿？

可到了夜里，老板又特意在灶头上给我留了一大碗炖肉，拍着我的肩膀叹气，说外头那些戴假发的大人物阴险得很，哪会像他这样{{掏心掏肺}}地当我是自家人。那一刻，我肚子里原本准备好的那些硬话，又全被这碗温热的炖肉给堵死在嗓子眼里。

明天就是第三天，是老先生给的最后期限。他说后头还有几个行会推荐的年轻人在排队，这位置不可能一直空着等我。

明天一早，我必须把脊梁挺起来，清清楚楚地告诉老板：我已经决定走了，我要去做抄写员。

我感念他收留我的恩情，我可以加班加点干完这一批大单，甚至可以手把手把新来的伙计带熟。可我心里像明镜一样清楚——如果非要等到老板点头、觉得我“够格”走的那一天，那么再过四年、十年，我依然只能浑身沾满面粉，在这间昏暗的后厨里，一辈子替他搬滚烫的烤盘。

床底下的那几张字，我刚才又抽出来摸了摸。最上面那一页落了一层细细白白的面粉，我用袖口轻轻掸了掸，拂去粉末，底下的字迹依然黑亮分明。

卢卡
灰港 铁锚巷8号 晨炉面包坊]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n01_curiosity",
                "word_candidate_n01_suspicion",
                "word_candidate_n01_fear",
                "word_candidate_n01_a2",
                "word_candidate_n01_recall",
                "word_candidate_n01_brave",
                "word_candidate_n01_s2",
                "word_candidate_n01_anger",
                "word_candidate_n01_trust",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n01",
            ["followupTemplateId"] = "tpl_n01",
            ["id"] = "letter_n01",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n01",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "勇气帮助说清离职决定",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["brave"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 80,
            },
            ["selfIntro"] = "来信人：卢卡",
            ["senderId"] = "npc_luca",
            ["title"] = "去做抄写员学徒",
        },
        {
            ["address"] = "灰港 铁锚巷8号 晨炉面包坊",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n01",
            ["id"] = "letter_n01_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_luca",
            ["title"] = "卢卡的回信",
        },
        {
            ["address"] = "灰港 铁锚巷14号 一层临街补衣窗口",
            ["appearCondition"] = {
                ["dayMin"] = 4,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫诺拉，今年六十三了。在灰港铁锚巷临街的窗户底下，我支着一张窄木案，平日里就靠替码头工人和街坊们缝补破衣烂衫、收短裤脚讨生活。屋里常年就我一个人，空落落的。儿子艾文在海船上做木工，一年到头随着大船在风浪里漂，难得着一回家。

明晚他的船总算要靠港了。

今天一早，我就把他从前坐惯的那张高背木椅从墙角搬了出来，拿温水洗了粗布，里里外外擦得干干净净，端端正正摆在饭桌边上。整整两年没见着人了，信里总说一切都好，可当娘的哪能真把信上的话当真？不知道他在海上是遭了罪消瘦了，还是长壮实了；海风那么煞人，他带回来的粗布褂子要是磨破了领口袖口，等明晚吃过了热饭，我再就着油灯慢慢给他补严实。

明晚我想炖上一锅热汤。艾文小时候最馋这口，每次喝到底都要把碗舔得精光，扯着我的围裙角非要再添一碗。两年没吃过家里的灶火，也不知道海上的咸汤硬肉有没有把他的口味给吃变了。锅里的粗盐我得先少放半勺，要是嫌淡了，搁在桌上让他自己添。隔壁炉子刚烤好的面包我也买下了，明天一早我得起早把手里积压的几条裤脚赶完，省得他前脚推门进来，我还埋着头满屋子乱翻寻顶针和剪子。

两年前他走的那天，我们娘儿俩就在这张饭桌边上吵得不可开交。我{{哭}}着拽着他，非要他在城里的木工作坊找个安稳生计——港口风大浪急，海上一旦出了事，连尸骨都寻不回来，在城里干活好歹下了工就能回家喝口热汤。可他不依，涨红了脖子跟我吼，说他生来就想修吃水的大海船，不想这辈子连剪头发、买鞋袜都要由着我来替他拿主意。

走前我抹着眼泪应下了：下回他再回来，我只管做饭，绝不再拿留在城里的话去烦他。

可我这双手和脑子啊，上了年纪就是不争气。前几天瞧见隔壁面包作坊门口贴了招工的告示，我脚底下没管住，还是厚着脸皮凑过去替他打听了工钱和歇班的规矩。打听完了，走回窗下坐着，我心里直骂自己犯浑——明明答应过孩子的事，怎么临到头又把那份老毛病翻出来了呢？他好不容易靠岸歇上两天，我要是刚见面又拿这些绳索去捆他，他怕是连碗里的汤都没咽下去，就巴不得赶回船上去了。

听见船要靠港，我这心里哪能不{{高兴}}？可这几天夜里翻来覆去合不上眼，总悬着一股{{怕}}：怕他一脚踏进门，我嘴一张，又不由自主地问起他在海上挣了几个铜子、下趟船又是哪天开拔。人还没把背上的行囊卸下来呢，倒先要被我{{盘问}}出一头冷汗。

明晚，我真想把心放宽些。把脸上的愁纹抚平，笑着迎他进门，好好陪他吃一顿安生饭。

别提找活，别提工钱。进门先摸摸他的手，问一句“路上颠簸坏了吧”。他要是愿意跟我讲讲海上的大风浪和新打的船骨，我就老老实实听着，听不明白也不插嘴瞎指点；我呢，也攒了一肚子铁锚巷里街坊们的闲话能讲给他解闷。总不至于两个亲骨肉坐在一张桌上，除了催他留下来，就半句话都讲不出了。

两只旧粗瓷碗，我方才已经拿布揩得亮堂堂的，齐整整摆在桌角了。

明天的汤多炖一些。他要是推过碗来，还像当年那个毛头小子一样眼巴巴地说想再添一碗，我就立刻{{笑着}}接过来，给他盛得满满当当的。

诺拉
灰港 铁锚巷14号 一层临街补衣窗口]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n02_sadness",
                "word_candidate_n02_happy",
                "word_candidate_n02_fear",
                "word_candidate_n02_suspicion",
                "word_candidate_n02_h2",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n02",
            ["followupTemplateId"] = "tpl_n02",
            ["id"] = "letter_n02",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n02",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "这顿饭吃成了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["happy"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 80,
            },
            ["selfIntro"] = "来信人：诺拉",
            ["senderId"] = "npc_nora",
            ["title"] = "两个人的晚饭",
        },
        {
            ["address"] = "灰港 铁锚巷14号 一层临街补衣窗口",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n02",
            ["id"] = "letter_n02_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_nora",
            ["title"] = "诺拉的回信",
        },
        {
            ["address"] = "灰港 外城东麦田 佃户小院 3 号",
            ["appearCondition"] = {
                ["dayMin"] = 6,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫艾莉，今年十岁啦。我家住在外城东边，一推开门就是大片大片的麦田。我可聪明了，路边的木牌子我都认得，数数数得比我爹还要快呢！

明天是个大日子——我要{{头一回}}自己一个人去集市了。娘让我把家里收的一篮子大萝卜卖掉，再买一袋盐回来。娘怕我丢了，用炭条把路画在纸上，严严实实地压在菜篮子底下，前两天还特意领着我走过一趟呢。娘交代我说，到了集上就去找那个围蓝围裙的叔叔，他认得我们家的萝卜，我只要挨着他的摊子摆开就行。

虽然我嘴上跟娘说“全记住啦”，可其实我心里直打鼓，{{怕得要命}}。集市里的人总是挤得不行，大人们站在一起像一堵堵大高墙，说话声音又粗又响。上回有个抱着娃娃的婶婶朝我走过来，我吓得抱着篮子拼命往后缩，白萝卜差点全掉在泥地里。娘当时还拍我说：“傻丫头，抱着篮子像什么样，萝卜又不是拿来挡人的盾牌！”可我只要一紧张，两只手就自己抱上去了嘛，我根本管不住它们。

芬明天也要去卖菜，她数数{{比我还要快}}，而且一点都不怕跟生人说话。我才不要被她瞧见我缩在路边不敢走过去的窝囊样呢，那也太丢人了！

娘虽然摸着我的头说，卖不完也{{没关系}}，再拎回来就是了。可我不想拎回来，我想把带来的萝卜全——部卖光！

今晚早点睡，明天我的胆子一定要大一点。我要昂首挺胸地走到蓝围裙叔叔跟前，顺顺利利把萝卜卖掉，再也不要把自己藏在篮子后头躲人了。

等太阳快落山我回家的时候，大篮子里才不要有重邦邦的萝卜呢，里面就只准剩那一小袋盐！

艾莉
灰港 外城东麦田 佃户小院 3 号]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n03_c1",
                "word_candidate_n03_fear",
                "word_candidate_n03_e1",
                "word_candidate_n03_k1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n03",
            ["followupTemplateId"] = "tpl_n03",
            ["id"] = "letter_n03",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n03",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "顺利卖完",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["safety"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：艾莉",
            ["senderId"] = "npc_ellie",
            ["title"] = "一袋胡萝卜的远行",
        },
        {
            ["address"] = "灰港 外城东麦田 佃户小院 3 号",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n03",
            ["id"] = "letter_n03_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_ellie",
            ["title"] = "艾莉的回信",
        },
        {
            ["address"] = "灰港 老钟楼西侧 帮工宿舍 2 号 二层",
            ["appearCondition"] = {
                ["dayMin"] = 8,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫奥托，今年十一岁。我在老钟楼打杂扫地，住西边那间窄小的小屋。这楼里的大钟响得对不对，我耳朵一听就知道；台阶上的灰积了多少，我搭眼一瞧就心里有数。

一年到头，就数节庆那几天钟楼最热闹。整座塔上挂满了花花绿绿的纸旗子，从早到晚都有人跑上来撞钟、大声{{唱歌}}，厨房里整天都在熬甜滋滋的汤水。

可今年节庆一散，人全走了。那些纸旗子还拴在楼梯扶手上，被穿堂风吹得边角都毛糙了。今天轮到我来收。

但我扫得一点劲头也没有。大扫帚拖在地上慢吞吞地蹭，砖缝里的灰只顾着打转转，怎么也不肯扫成一堆。要是换作去年，厨房的{{老厨娘}}总会把剩下的糖屑倒在我们手心里，每人一小把，抿在嘴里{{甜极了}}。可她今年去闺女家了，走的时候明明说很快就回，结果一晃等到麦子都割完收进仓了，也{{没见她回来}}。

昨天皮特得了一小块糖饼，掰了半块给我。我嘴上冲他说了“谢啦”，可心里还是忍不住{{偷偷比了比}}：他手里留着的那半块，瞧着明显比我这块要厚一点。不过这事我咽在肚子里，没跟他说。

高处的旗子是我爬上去解的。绳结受了潮，一扯就死死粘在扫帚毛上，我使劲甩了三下才甩脱。它软趴趴躺在我手心里，看着就像是死活不肯承认节庆已经过完了一样。其实我也不肯认。可灰尘不等人啊，管你高不高兴，明天一早我还得老老实实接着扫。

我真想让自己再高兴一点。也不用太多，只要够我把手里的旗子好好收齐、够我跟皮特在一块儿痛痛快快大笑一场，那就足够了。

收工的时候，我把那些纸旗子整整齐齐叠成一厚摞，搬了块大石头严严实实压在钟楼门口，省得风又把它刮出来。

奥托
灰港 老钟楼西侧 帮工宿舍 2 号 二层]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n04_h2",
                "word_candidate_n04_r1",
                "word_candidate_n04_h1",
                "word_candidate_n04_s1",
                "word_candidate_n04_e1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n04",
            ["followupTemplateId"] = "tpl_n04",
            ["id"] = "letter_n04",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n04",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "高兴回来了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["happy"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：奥托",
            ["senderId"] = "npc_otto",
            ["title"] = "钟声过后还有一口甜",
        },
        {
            ["address"] = "灰港 老钟楼西侧 帮工宿舍 2 号 二层",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n04",
            ["id"] = "letter_n04_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_otto",
            ["title"] = "奥托的回信",
        },
        {
            ["address"] = "灰港 月桂坡 6 号 旧宅侧门",
            ["appearCondition"] = {
                ["dayMin"] = 10,
            },
            ["attachments"] = {},
            ["body"] = [=[我和{{姑母}}守着月桂坡六号的旧宅。我叫塞西莉亚，今年十七岁，每日的功课除了去庭院里侍弄那些月桂树，便是替姑母核对账房送来的单子。我自小受过算术教育，算盘打得极快，可近来我念账单时总忍不住停顿，那些开支和进项的条目，一年比一年短了。

宅子渐渐空得能听见回声。先是起居室里祖父的油画被取了下来，墙皮上留下一大块泛白的印子；接着是刻着家徽的银餐叉；直到去年深冬，连饭厅里那张能坐下十几人的长条橡木桌也被抬上了运货的马车。每当家里有东西被搬走，姑母总会抚平裙褶，用那种极体面的语调对我说：“东西是死的，塞西莉亚，人是活的。”每一次，她都这么说。

明晚表姐家设宴。她的婚姻体面，府上的席面一向奢华周全。上回赴宴，我整晚僵坐在软椅上，席间的菜肴一口都没动。回程的马车里，姑母压低声音斥责了我，说一位{{落魄}}贵族小姐若在宴席上露出那副拒人千里的清高模样，不仅失礼，而且难堪。

今天午后，表姐家的仆人又送来了烫金请柬，还特意捎了句口信，说席上专程备了庄园送来的{{肥烤鹅}}。我指尖捏着那张泛着甜香的硬卡纸，合上时，鼻尖却只闻到厨房里那锅正咕嘟冒泡的芜菁薄汤。我实在不想去，可这话我只能咽回肚子里。

不知从何时起，坐在旁人那铺着雪白台布的饭桌前，我的喉咙就像被丝带死死勒住了。明明是精巧的珍馐，可我握着刀叉，目光落在那只描金瓷盘上，心里的{{算盘}}就自顾自地拨动起来：这只白瓷盘要多少铜子？那只抹着名贵香料的肥鹅要几枚银币？摆满这长长一桌的精细吃食，折成硬煤，够我们在月桂坡烧上整整一个冬天。算到最后，盘里的菜渐渐凉了，凝结成一片浑浊的白油，而我胃里沉甸甸的，满脑子都是柴火和账目，再也咽不下一丁点东西。

我希望明晚能像个真正的客人那样，体体面面地把那顿饭吃完。不再去算那些令人难堪的价钱，也不用在仆人端上菜肴时，强撑着得体的微笑推说自己毫无胃口。

窗外已经彻底黑了。姑母从樟木箱底翻出了明天要穿的衣裳——那是条洗得有些发灰的蓝绸裙子。袖口的金线早就磨损起毛了，她正坐在壁炉边，就着昏暗的光线一针一线地细细缝补。

我没有说话，只是走上前去，替她换了一根烧得更亮的新蜡烛。

塞西莉亚
灰港 月桂坡 6 号 旧宅侧门]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n05_t1",
                "word_candidate_n05_s1",
                "word_candidate_n05_a1",
                "word_candidate_n05_q1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n05",
            ["followupTemplateId"] = "tpl_n05",
            ["id"] = "letter_n05",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n05",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "吃完了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["appetite"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：塞西莉亚",
            ["senderId"] = "npc_cecilia",
            ["title"] = "花圃比家徽好养",
        },
        {
            ["address"] = "灰港 月桂坡 6 号 旧宅侧门",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n05",
            ["id"] = "letter_n05_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_cecilia",
            ["title"] = "塞西莉亚的回信",
        },
        {
            ["address"] = "灰港 船匠巷 21 号 一层",
            ["appearCondition"] = {
                ["dayMin"] = 12,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫莱昂，整整七十了。从前我是造大海船的船匠，如今退了下来，守在船匠巷的老屋里，接点修修补补的零活打发日子。年轻那会儿手底下过的是龙骨大木，现在刨的是碎板椅腿。手头这几件家伙什还是当年的老物件，钢磨薄了，木柄盘得发亮，用惯了，比这世上的人还听使唤。

对门做皮匠的老伙计前天扛过来一把跛脚椅子，右后腿的榫口松脱了，人一坐上去就直挺挺往前栽。皮匠打趣说，这椅子像在冲饭桌鞠躬，一天到晚行礼，礼数太重。我听了直摇头。椅子哪能跟船比？船起了水，名字就死死刻在船头上，落成那天起一辈子都不兴改；一把破椅子连个名字都没有，倒先挑起虚礼来了。如今市面上那些新做派也{{粗糙}}，两颗铁钉子砸进去就算交工，图个快当，可哪有规规矩矩咬合的榫口经得起年头。昨天我把尺寸重新量了一遍，拿红粉笔重重记在工作台面上。字写得拳头大，我这双老眼还能跟得上。

只是这两天，手腕子骨头节里{{酸疼}}得紧。那股疼劲儿一窜上来，凿子走到细致处就忍不住打晃。我心里清楚，不是精钢凿子在晃，是我这只手在晃。这话我闷在肚子里，谁也没说过。上回闺女提着东西来看我，劝我把家什收了别再揽活，我低头磨铁，没接她的话茬。

下第一凿前，照老规矩，得拿木槌在料子上先轻敲三下。木头醒没醒我说不好，但敲完这三下“笃、笃、笃”，我自己{{手底下先实了}}，心也落了底。工作台就挨着破窗，窗纸破了个角，外头凉风钻进来，手指骨很快就冻得发僵，得两手合着死命{{搓热乎}}了，才敢握住凿柄。腿上搭着的那条厚呢围巾是老伴织的，干活一低头，它就顺着裤腿滑下去，一天得从刨花木屑堆里捞上三四回。

木料备齐了，榫卯线也拿划针扎得分明。今天我就盼着这双手能争点气，一凿一凿稳到底，把这几个榫口利利索索凿完。手里的老凿子啊，也得再听我一句使唤。

这就开工了。先把老伴的围巾叠好收进抽屉里，省得待会儿一弯腰，它又掉进木屑堆里去。

莱昂
灰港 船匠巷 21 号 一层]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n06_a1",
                "word_candidate_n06_p1",
                "word_candidate_n06_m1",
                "word_candidate_n06_w1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n06",
            ["followupTemplateId"] = "tpl_n06",
            ["id"] = "letter_n06",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n06",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "做完了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["steady"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：莱昂",
            ["senderId"] = "npc_leon",
            ["title"] = "椅子不该跪着迎客",
        },
        {
            ["address"] = "灰港 船匠巷 21 号 一层",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n06",
            ["id"] = "letter_n06_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_leon",
            ["title"] = "莱昂的回信",
        },
        {
            ["address"] = "灰港 漂布巷 9 号 后院二层",
            ["appearCondition"] = {
                ["dayMin"] = 14,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫贝娅，三十一岁，在漂布巷租了间背阴的屋子，靠替石鸥客栈洗浆被褥过活。我和妹妹两个人挤这一间房，全靠我这双手从冷水和碱汤里挣出来的铜板交房租、买面包。我母亲从前在杂货铺帮过工，教过我一套笨办法记账：进项列一行，出项列一行，纸上的账，得认得清活人的脸。

石鸥客栈的掌柜已经平白拖欠了我两个月的工钱。

上上个月交去的那十二套床单，他验货画押时，清清楚楚写着“收讫无损”四个字；可真到了结账的日子，他那张油光水滑的脸一变，改口说有两套被客人嫌弃退了回来，非要折价扣我的钱。我伸手找他要退单凭证，他两手一摊，只拿账房记了档来{{堵我的嘴}}。回到租屋，我在油灯下把那张签条对着光看了一遍又一遍——上面那行字墨色浓重，分明是他自己的手笔。

上回我横下心去店里问，正撞见他在大堂里陪几个商贩喝酒。他端着酒杯，当着满堂食客的面笑呵呵地夸我，说“贝娅最是个明事理的体面人，做事踏实，从来不催账”。满屋子的人都跟着哄笑，我站在油腻腻的过道里，{{骨节发白}}，也只能强扯着嘴角陪他{{干笑}}了一声。那晚回家，我守着那叠旧收条，摸着上面的褶子数了大半夜。

前天一早，客栈伙计又挑来两只沉甸甸的湿木桶，扔下整整十六套床单，扯着嗓子喊急用。担子我咬牙收下了。在这条巷子里，活儿要是不接，前头欠的钱就{{更没指望}}；可哪一套是哪天过的碱水、哪天在河滩晾干、最后又是谁签的字，我拿炭条在木板上记着，一笔都落不下。

明天，我不想再听他打哈哈了。我要把这些签了字的收条一张一张拍在他的柜台上，一笔一笔算给他听，把欠我和妹妹的嚼谷全要回来。我绝不再等他嘴里那些虚头巴脑的“下回”。

睡前我又仔细盘了一遍：账上实打实欠着我二十一套的工钱，脚边新担子里的十六套还没算。

吹灯前，身后的窄木床上，妹妹迷迷糊糊翻了个身，呼吸轻悄悄的。我摸黑把明天一早要穿的深色外衣整整齐齐叠好，沉沉地压在了那叠收条上头。

贝娅
灰港 漂布巷 9 号 后院二层]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n07_a2",
                "word_candidate_n07_a1",
                "word_candidate_n07_s1",
                "word_candidate_n07_f1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n07",
            ["followupTemplateId"] = "tpl_n07",
            ["id"] = "letter_n07",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n07",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "要回来了（一部分）",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["anger"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：贝娅",
            ["senderId"] = "npc_bea",
            ["title"] = "把工钱从下次里洗出来",
        },
        {
            ["address"] = "灰港 漂布巷 9 号 后院二层",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n07",
            ["id"] = "letter_n07_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_bea",
            ["title"] = "贝娅的回信",
        },
        {
            ["address"] = "灰港 南门街 17 号 木门",
            ["appearCondition"] = {
                ["dayMin"] = 16,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫马丁，今年二十九岁，在灰港当城镇守卫，家住南门街十七号。跟老婆和刚满四岁的丫头挤一个小院子。守了这几年夜哨，这双耳朵算是彻底练贼了，巷子口杂乱的皮靴声，哪一串是巡夜换防的弟兄，哪一声是心虚赶路的过客，我隔着两层土坯墙都能听得一清二楚。可这门站哨练出来的本事带回自己家里，实在不大讨人喜欢。

前天队里总算把{{轮休}}条子批下来了。我把那条挂着铁牌、沉甸甸的皮腰带解下来搭在床头木桩上。可那玩意儿挂上去了，不等于这颗当差的心就能跟着下了岗。昨天院门外头有人快步走过，我坐在竹椅上，后背蹭的一下就绷成了笔直一根木桩；丫头在院子里挥着木勺学官兵点卯，扯着小嗓门喊“集合”，我舌头一滚，喉咙里差点条件反射地吼出一声“到！”。她娘{{笑}}得手里正纳的鞋底都掉了，拍着围裙{{数落}}我：“行了马丁，把那张守门脸收一收，这屋里没长官点卯，用不着你立正应声。”

台阶上摆着我当差穿的那只破皮靴。右边鞋帮裂了道大口子，前几天夜里起海雾，阴冷的潮风顺着缝隙直往我脚踝骨头里钻，冻得生疼。我给自己派了道家务差事，就用在哨所里跟老军需官学的粗麻线和铜锥子把靴子补结实。

厨房铁锅里正温着午饭，甘蓝叶炖得烂烂的，揭开盖子直冒白汽，黑麦面包是昨儿烤好的，正搁在炉边温着。我想{{定定心心}}坐下来，{{安安稳稳}}吃顿家常饭，吃完了再去摆弄那只破鞋。这念头听着像句废话，可这大半年里，碰上城防戒严和码头闹事，我有一大半的饭都是靠在哨所冷墙根下、端着粗瓷大碗站着三两口扒完的。

今天我就想过个真正正正的休假日，把靴子补得严实，热饭吃得干净，再听媳妇坐在对面絮絮叨叨讲些街坊邻里的碎嘴闲事。

正午的日头一点点爬上了东边的院墙，暖烘烘的。她在屋里掀了门帘，扯着嗓子喊了一声：“马丁，开饭啦！”

皮靴、粗锥子和浸了蜡的粗麻线都整整齐齐码在青石台阶上。我拍了拍掌心里的浮土，应了一声，低头钻进了飘着菜香的屋里。

马丁
灰港 南门街 17 号 木门]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n08_r1",
                "word_candidate_n08_h1",
                "word_candidate_n08_a1",
                "word_candidate_n08_c1",
                "word_candidate_n08_c2",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n08",
            ["followupTemplateId"] = "tpl_n08",
            ["id"] = "letter_n08",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n08",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "休日过成了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["relax"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：马丁",
            ["senderId"] = "npc_martin",
            ["title"] = "休假的脚步不用列队",
        },
        {
            ["address"] = "灰港 南门街 17 号 木门",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n08",
            ["id"] = "letter_n08_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_martin",
            ["title"] = "马丁的回信",
        },
        {
            ["address"] = "灰港 北坡白桦庄园 账房",
            ["appearCondition"] = {
                ["dayMin"] = 18,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫阿涅丝，四十五岁，守着北坡的白桦庄园，管着庄上的地租出入和四时用度。底下佃户的口粮、我和妹妹的衣食，全系在这些账目上。说白了，我这辈子大半的光阴，都在替这片地里流血流汗的人称量公道。

但这几天，账房里的一桩旧事横在心头，惹得我{{寝食难安}}。

翻查早年的租约时，佃户鲁本手里那份副本，同我案头上的羊皮纸底册{{对不上}}了——{{底册}}上干干净净，单单少了一截关于修渠的字据。当年庄上出钱挖排灌渠，鲁本领着几个庄稼汉出了整整一春的大力，按说好的约定，这笔工钱要分摊进地租，准他每年少交一口袋谷子。

要是照着底册的{{死规矩}}办，他就得把这几年折抵的钱粮全补齐，这足够掏空他半间仓房；可若是当年账房抄漏了字，错在庄上，我不仅得把这一批旧契全翻出来重新核算，还得当着一个泥腿子的面，低头认下这个疏漏。

在这白桦庄园里，以我的权力地位，一句话就能把这事压死，我是领主，他拿不出别的{{旁证}}，只能自认倒霉。在刚发现这处差错的那天，我甚至心里隐秘闪过一丝侥幸：正好借着这由头罚他一笔就当赔罪。

去年深秋，鲁本拉着满满一车甜菜进院子，车辕撞歪了，硬生生把主屋前我照料了三年的大半架花篱撞得歪折。那些藤本蔷薇是我亲手栽的，断枝残花落了一地。当时我顾及贵族主人的风度，只让人默默打扫干净，没开口找他索赔。但那是装给外人看的宽容，实际上我把这笔账在心里狠狠记了一整年，每每在回廊瞧见那块稀疏的篱笆，那股{{暗火}}就止不住地往上冒。

今天我手里捏着两份契纸，眼神又不由自主地往窗外的花篱上飘。在一旁剪花的妹妹把剪刀往石台上一搁，“咔哒”一声脆响，冷冷地刺破了我那点心思：“阿涅丝，花是花，租是租。”

她比我小九岁，自小性子冷淡，说话像冰锥子一样不留情面。

可那一瞬间，我握着羊皮纸的手猛地僵住了，脸上火辣辣地烧起来，像是被人当面揭下了华丽的面纱。

我突然看清了自己内心里那个丑陋的念头，我竟然在盘算着用手里的领主特权，借着账房一个可能存在的疏漏，直接去惩罚一个打翻了我花架的佃农。若是庄上的底册真抄漏了，那是庄园失信。我若是把一架花的气撒在白纸黑字的地租上，克扣一个庄稼汉赖以活命的谷钱，那我算什么领地的主人？

那点狭隘的报复欲，被妹妹这一句话彻底砸得粉碎。羞愧过后，心底倒是想通了。

明儿午后，鲁本就要来庄园书房对账。我打算就将两份契纸平平整整摊在桌上，一条条当着他的面念下去。念到哪一行两边对不上，便停在哪一行上。谁抄漏的，谁就堂堂正正认下这桩错。要是账房当真漏了字，我自会当面给他赔个不是。

花篱是花篱，账目是账目。我手里的天平，不能因为自己的一点私心偏了分毫。

夜已经深透了，外头白桦树叶被风吹得沙沙作响。妹妹推开书房门，见我还在桌前坐着，轻声问了一句：“要不要我陪你，连夜再把当年的账目底稿翻出来{{核一遍}}？”

“用不着了，”我抬起头，冲她笑了笑，“道理已经想明白了，字迹都在纸上，眼前的灯也够亮。”

妹妹看着我的神色，没再多说什么。她走上前来，拿起银剪，替我把油灯里结了焦的灯芯剪掉，屋子里顿时又亮堂了几分。

阿涅丝
灰港 北坡白桦庄园 账房]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n09_f1",
                "word_candidate_n09_suspicion",
                "word_candidate_n09_t2",
                "word_candidate_n09_t1",
                "word_candidate_n09_p2",
                "word_candidate_n09_a1",
                "word_candidate_n09_q1",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n09",
            ["followupTemplateId"] = "tpl_n09",
            ["id"] = "letter_n09",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n09",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "对得上了",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["reason"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：阿涅丝",
            ["senderId"] = "npc_agnes",
            ["title"] = "花是花，租是租",
        },
        {
            ["address"] = "灰港 北坡白桦庄园 账房",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n09",
            ["id"] = "letter_n09_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_agnes",
            ["title"] = "阿涅丝的回信",
        },
        {
            ["address"] = "灰港 榫木街 4 号 木作坊 后门",
            ["appearCondition"] = {
                ["dayMin"] = 20,
            },
            ["attachments"] = {},
            ["body"] = [=[我叫雅各布，今年三十四岁，在榫木街开着一间挂了行会铁牌的木作坊，手底下带着两个学徒。

作坊是租来的，前两年为了盘下这间铺子，我东拼西凑借了一笔账，如今月月都得按时还利钱。进木料的本钱、作坊的租金、吃人的利钱，全指着柜台上那个沉甸甸的铁皮钱匣子进出。

三天前，作坊里出了大事。

小徒弟米洛在后头的料架下头搬硬木，没留神料垛松了，整整半垛橡木呼啦砸下来，结结实实压了他的右手。那是吃木匠饭的手，医者给看过了，骨头没折，但皮肉翻卷，伤了筋。大夫交代得极严，半个月内沾不得水，一点死力都不能使，三天还得换一次伤药。末了又冷着脸补了一句——这半个月要是养不好落了硬疤，往后这只手握刨子、掌凿子就再也使不上巧劲了。

米洛是跟我学手艺的，人在我的料架底下出了事，这桩责任全在我头上。

从医馆走出来那天，我当着他的面把话说得斩钉截铁：诊费和药钱全由作坊出，这半个月他就跑跑腿，不许干重活粗活。

话吐出口的那一刻，我心里比谁都清楚这意味着什么。柜台钱匣子里的铜板是有数的。把这一笔医药费结清，这个月进新料、交房租、还利钱，全得勒紧裤腰带。可即便紧得肋巴骨生疼，这笔钱我也得掏，这是规矩，也是良心。

可难处偏偏不只是钱。

这三天里，我无数次{{想起}}这件事，又无数次自欺欺人地把它撂在一旁。

前天清晨我明明想得好好的，一开门就把诊费给医者送去。可钱匣子刚搬上案板，送木料的马车就堵在了巷口，验尺寸、挑木纹、过数结账，等把一车原木安顿进棚子，日头已经歪到了西墙根，这件事就这么被活活挤没了。

昨天下午我又把医馆的催单翻出来，用墨斗压在案角，心里盘算着刨完手里这根料就动身。结果一位老主顾从后门挤进来，非要给家里的旧椅子改改榫眼。等我送走他，两只手不知不觉又摸上了锯把。那一下午，我把作坊里的三把细齿锯擦得锃亮如镜、能照见人影，可案角那两张轻飘飘的单子，自始至终连个角都没挪动过。

我是在拿手里的碎活儿逃避。

米洛这两天照样天天来。他伤手裹着厚厚的灰布，吊在胸前，就那么安安静静坐在窗根底下的木墩上，看着我和另一个学徒干活。他不开口问钱的事，也不问自己哪天能上工。可他不问，我这胸口反倒像堵了块发霉的湿木头，比挨一顿{{痛骂}}还难受，这孩子分明是在等我一句{{准话}}，而我却在装聋作哑拖着他。

外头的债也逼了上来。石鸥客栈那边打发跑堂的来催过两回，问订好的六把靠背椅什么时候交货，我都红着脸敷衍说快了，西街铺子的掌柜昨儿也探头问了一嘴。

昨晚回到家，我那口子没跟我吵，只是在饭桌上默默摆了三只空碗，看着我说：“一件事放一只碗。把事理顺了、摆开了，晚饭才有地方盛。”

等热乎的肉{{汤}}盛上来，我握着勺子，迟迟{{不敢}}低头喝第一口。我知道，如果还是这么浑浑噩噩，就等于把欠米洛的担当、把欠主顾的信誉，又硬生生咽回肚子里咽了一夜。

等明天一早，天亮我就把这事给收拾好！

交清医药费，再把米洛赶回家歇足半个月眼不见为净，最后上门给客栈和铺子定好交付的日子，哪怕夜里点着灯赶工也绝不失信。

先把点过头的事一件件做好，剩下的，等办完了再去扛。

雅各布
灰港 榫木街 4 号 木作坊 后门]=],
            ["bottleType"] = "normal",
            ["cutWordIds"] = {
                "word_candidate_n10_recall",
                "word_candidate_n10_anger",
                "word_candidate_n10_trust",
                "word_candidate_n10_soup",
                "word_candidate_n10_fear",
            },
            ["cuttable"] = true,
            ["directRuleSetId"] = "rules_n10",
            ["followupTemplateId"] = "tpl_n10",
            ["id"] = "letter_n10",
            ["kind"] = "order",
            ["ratingSetId"] = "rating_n10",
            ["requirement"] = {
                ["conditions"] = {},
                ["desc"] = "忆起承诺与安排",
                ["forbiddenEffects"] = {},
                ["tags"] = {
                    ["recall"] = 0.8,
                },
            },
            ["reward"] = {
                ["currency"] = 0,
            },
            ["selfIntro"] = "来信人：雅各布",
            ["senderId"] = "npc_jacob",
            ["title"] = "汤可以喝",
        },
        {
            ["address"] = "灰港 榫木街 4 号 木作坊 后门",
            ["attachments"] = {},
            ["bottleType"] = "normal",
            ["cuttable"] = false,
            ["followupTemplateId"] = "tpl_n10",
            ["id"] = "letter_n10_followup",
            ["kind"] = "direct_followup",
            ["senderId"] = "npc_jacob",
            ["title"] = "雅各布的回信",
        },
    },
    ["npcs"] = {
        {
            ["address"] = "灰港铁锚巷12号 二楼",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_passerby_a",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "e01_result_rested",
                        "e01_result_mother_dream",
                        "e01_result_song_faded",
                        "e01_result_mother_unclear",
                        "e01_result_fish_choir",
                        "e01_result_walking_crates",
                        "e01_result_fragmented_dream",
                        "e01_result_fragmented_song_faded",
                    },
                },
            },
            ["name"] = "埃利亚斯·沃德",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫埃利亚斯·沃德，在灰港码头搬了十几年货。我和在面包坊帮工的妹妹合住铁锚巷，靠两份工钱付房租和饭钱。",
        },
        {
            ["address"] = "灰港 铁锚巷8号 晨炉面包坊",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_luca",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n01_result_missed_place",
                        "n01_result_stayed_for_promise",
                        "n01_result_departure_conflict",
                        "n01_result_started_learning",
                        "n01_result_departure_agreed",
                    },
                },
            },
            ["name"] = "卢卡",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫卢卡，今年二十二岁，在铁锚巷的“晨炉面包坊”当伙计，一晃干了四年。平时除了揉面生火，我也常替巷子里的街坊代写家信。街坊们大多大字不识，话说得前言不搭后语，我就耐着性子多问几句，理顺了写下来，封口前再一字一句念给他们听。",
        },
        {
            ["address"] = "灰港 铁锚巷14号 一层临街补衣窗口",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_nora",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n02_candidate_doubted",
                        "n02_candidate_escaped",
                        "n02_candidate_swallowed",
                        "n02_candidate_care",
                        "n02_candidate_good",
                    },
                },
            },
            ["name"] = "诺拉",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫诺拉，今年六十三了。在灰港铁锚巷临街的窗户底下，我支着一张窄木案，平日里就靠替码头工人和街坊们缝补破衣烂衫、收短裤脚讨生活。屋里常年就我一个人，空落落的。儿子艾文在海船上做木工，一年到头随着大船在风浪里漂，难得着一回家。",
        },
        {
            ["address"] = "灰港 外城东麦田 佃户小院 3 号",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_ellie",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n03_candidate_protect",
                        "n03_candidate_freeze",
                        "n03_candidate_hide",
                        "n03_candidate_salt",
                        "n03_candidate_good",
                    },
                },
            },
            ["name"] = "艾莉",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫艾莉，今年十岁啦。我家住在外城东边，一推开门就是大片大片的麦田。我可聪明了，路边的木牌子我都认得，数数数得比我爹还要快呢！",
        },
        {
            ["address"] = "灰港 老钟楼西侧 帮工宿舍 2 号 二层",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_otto",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n04_candidate_past",
                        "n04_candidate_tear",
                        "n04_candidate_envy",
                        "n04_candidate_play",
                        "n04_candidate_good",
                    },
                },
            },
            ["name"] = "奥托",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫奥托，今年十一岁。我在老钟楼打杂扫地，住西边那间窄小的小屋。这楼里的大钟响得对不对，我耳朵一听就知道；台阶上的灰积了多少，我搭眼一瞧就心里有数。",
        },
        {
            ["address"] = "灰港 月桂坡 6 号 旧宅侧门",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_cecilia",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n05_candidate_fork",
                        "n05_candidate_sad",
                        "n05_candidate_talk",
                        "n05_candidate_count",
                        "n05_candidate_good",
                    },
                },
            },
            ["name"] = "塞西莉亚",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我和姑母守着月桂坡六号的旧宅。我叫塞西莉亚，今年十七岁，每日的功课除了去庭院里侍弄那些月桂树，便是替姑母核对账房送来的单子。我自小受过算术教育，算盘打得极快，可近来我念账单时总忍不住停顿，那些开支和进项的条目，一年比一年短了。",
        },
        {
            ["address"] = "灰港 船匠巷 21 号 一层",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_leon",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n06_candidate_split",
                        "n06_candidate_stop",
                        "n06_candidate_sleep",
                        "n06_candidate_pain",
                        "n06_candidate_good",
                    },
                },
            },
            ["name"] = "莱昂",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫莱昂，整整七十了。从前我是造大海船的船匠，如今退了下来，守在船匠巷的老屋里，接点修修补补的零活打发日子。年轻那会儿手底下过的是龙骨大木，现在刨的是碎板椅腿。手头这几件家伙什还是当年的老物件，钢磨薄了，木柄盘得发亮，用惯了，比这世上的人还听使唤。",
        },
        {
            ["address"] = "灰港 漂布巷 9 号 后院二层",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_bea",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n07_candidate_bucket",
                        "n07_candidate_acid",
                        "n07_candidate_discount",
                        "n07_candidate_soft",
                        "n07_candidate_good",
                    },
                },
            },
            ["name"] = "贝娅",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫贝娅，三十一岁，在漂布巷租了间背阴的屋子，靠替石鸥客栈洗浆被褥过活。我和妹妹两个人挤这一间房，全靠我这双手从冷水和碱汤里挣出来的铜板交房租、买面包。我母亲从前在杂货铺帮过工，教过我一套笨办法记账：进项列一行，出项列一行，纸上的账，得认得清活人的脸。",
        },
        {
            ["address"] = "灰港 南门街 17 号 木门",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_martin",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n08_candidate_wait",
                        "n08_candidate_military",
                        "n08_candidate_slow",
                        "n08_candidate_child",
                        "n08_candidate_good",
                    },
                },
            },
            ["name"] = "马丁",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫马丁，今年二十九岁，在灰港当城镇守卫，家住南门街十七号。跟老婆和刚满四岁的丫头挤一个小院子。守了这几年夜哨，这双耳朵算是彻底练贼了，巷子口杂乱的皮靴声，哪一串是巡夜换防的弟兄，哪一声是心虚赶路的过客，我隔着两层土坯墙都能听得一清二楚。可这门站哨练出来的本事带回自己家里，实在不大讨人喜欢。",
        },
        {
            ["address"] = "灰港 北坡白桦庄园 账房",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_agnes",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n09_candidate_grain",
                        "n09_candidate_hedge",
                        "n09_candidate_doubt",
                        "n09_candidate_grace",
                        "n09_candidate_good",
                    },
                },
            },
            ["name"] = "阿涅丝",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫阿涅丝，四十五岁，守着北坡的白桦庄园，管着庄上的地租出入和四时用度。底下佃户的口粮、我和妹妹的衣食，全系在这些账目上。说白了，我这辈子大半的光阴，都在替这片地里流血流汗的人称量公道。",
        },
        {
            ["address"] = "灰港 榫木街 4 号 木作坊 后门",
            ["background"] = "",
            ["family"] = "",
            ["id"] = "npc_jacob",
            ["inCase"] = false,
            ["initialState"] = {
                ["lastResult"] = "none",
            },
            ["initialStateSchema"] = {
                ["lastResult"] = {
                    ["type"] = "enum",
                    ["values"] = {
                        "none",
                        "n10_result_1a",
                        "n10_result_1b",
                        "n10_result_2b",
                        "n10_result_2a",
                        "n10_result_3",
                    },
                },
            },
            ["name"] = "雅各布",
            ["notes"] = "词值v02试用接入",
            ["occupation"] = "我叫雅各布，今年三十四岁，在榫木街开着一间挂了行会铁牌的木作坊，手底下带着两个学徒。",
        },
    },
    ["orderRatings"] = {
        {
            ["excludesFacts"] = {},
            ["feedback"] = "睡了个踏实觉",
            ["id"] = "rating_e01_result_rested",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_rested",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "又见到了母亲",
            ["id"] = "rating_e01_result_mother_dream",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_mother_dream",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "不再总想着那些旧事",
            ["id"] = "rating_e01_result_song_faded",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_song_faded",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "梦里的人认不出来了",
            ["id"] = "rating_e01_result_mother_unclear",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_mother_unclear",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "母亲领着一群鱼唱歌",
            ["id"] = "rating_e01_result_fish_choir",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_fish_choir",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "会走路的货箱",
            ["id"] = "rating_e01_result_walking_crates",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_walking_crates",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "一夜零碎的怪梦",
            ["id"] = "rating_e01_result_fragmented_dream",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_fragmented_dream",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "半截调子和零碎的梦",
            ["id"] = "rating_e01_result_fragmented_song_faded",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_pa_01",
            ["requiresFacts"] = {
                "e01_result_fragmented_song_faded",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "谈妥离职",
            ["id"] = "rating_n01_result_departure_agreed",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n01",
            ["requiresFacts"] = {
                "n01_result_departure_agreed",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "吵翻搬走",
            ["id"] = "rating_n01_result_departure_conflict",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n01",
            ["requiresFacts"] = {
                "n01_result_departure_conflict",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "加薪留下",
            ["id"] = "rating_n01_result_stayed_for_promise",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n01",
            ["requiresFacts"] = {
                "n01_result_stayed_for_promise",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "两边应承，错过机会",
            ["id"] = "rating_n01_result_missed_place",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n01",
            ["requiresFacts"] = {
                "n01_result_missed_place",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "承认不会，留下学习",
            ["id"] = "rating_n01_result_started_learning",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n01",
            ["requiresFacts"] = {
                "n01_result_started_learning",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "这顿饭吃成了",
            ["id"] = "rating_n02_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n02",
            ["requiresFacts"] = {
                "n02_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "话到嘴边又咽回去",
            ["id"] = "rating_n02_candidate_swallowed",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n02",
            ["requiresFacts"] = {
                "n02_candidate_swallowed",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "还是问出了口",
            ["id"] = "rating_n02_candidate_escaped",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n02",
            ["requiresFacts"] = {
                "n02_candidate_escaped",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "忙着照料，没顾上陪他",
            ["id"] = "rating_n02_candidate_care",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n02",
            ["requiresFacts"] = {
                "n02_candidate_care",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "他说了，我还是不信",
            ["id"] = "rating_n02_candidate_doubted",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n02",
            ["requiresFacts"] = {
                "n02_candidate_doubted",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "顺利卖完",
            ["id"] = "rating_n03_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n03",
            ["requiresFacts"] = {
                "n03_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "卖完了，但一直躲",
            ["id"] = "rating_n03_candidate_hide",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n03",
            ["requiresFacts"] = {
                "n03_candidate_hide",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "站住没敢开口",
            ["id"] = "rating_n03_candidate_freeze",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n03",
            ["requiresFacts"] = {
                "n03_candidate_freeze",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "卖光了萝卜，忘了买盐",
            ["id"] = "rating_n03_candidate_salt",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n03",
            ["requiresFacts"] = {
                "n03_candidate_salt",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "谁也别碰我的萝卜",
            ["id"] = "rating_n03_candidate_protect",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n03",
            ["requiresFacts"] = {
                "n03_candidate_protect",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "高兴回来了",
            ["id"] = "rating_n04_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n04",
            ["requiresFacts"] = {
                "n04_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "笑没笑到心里去",
            ["id"] = "rating_n04_candidate_envy",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n04",
            ["requiresFacts"] = {
                "n04_candidate_envy",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "撕了最大的那张",
            ["id"] = "rating_n04_candidate_tear",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n04",
            ["requiresFacts"] = {
                "n04_candidate_tear",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "笑够了，地还没扫完",
            ["id"] = "rating_n04_candidate_play",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n04",
            ["requiresFacts"] = {
                "n04_candidate_play",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "非要熬出从前的味道",
            ["id"] = "rating_n04_candidate_past",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n04",
            ["requiresFacts"] = {
                "n04_candidate_past",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "吃完了",
            ["id"] = "rating_n05_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n05",
            ["requiresFacts"] = {
                "n05_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "吃到一半又算了起来",
            ["id"] = "rating_n05_candidate_count",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n05",
            ["requiresFacts"] = {
                "n05_candidate_count",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "一口没动",
            ["id"] = "rating_n05_candidate_sad",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n05",
            ["requiresFacts"] = {
                "n05_candidate_sad",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "吃完了，却把家里的难处说了出来",
            ["id"] = "rating_n05_candidate_talk",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n05",
            ["requiresFacts"] = {
                "n05_candidate_talk",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "拿着银叉质问表姐",
            ["id"] = "rating_n05_candidate_fork",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n05",
            ["requiresFacts"] = {
                "n05_candidate_fork",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "做完了",
            ["id"] = "rating_n06_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n06",
            ["requiresFacts"] = {
                "n06_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "疼着，也做完了",
            ["id"] = "rating_n06_candidate_pain",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n06",
            ["requiresFacts"] = {
                "n06_candidate_pain",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "怕那一下，停了手",
            ["id"] = "rating_n06_candidate_stop",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n06",
            ["requiresFacts"] = {
                "n06_candidate_stop",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "榫口凿完了，却睡过了头",
            ["id"] = "rating_n06_candidate_sleep",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n06",
            ["requiresFacts"] = {
                "n06_candidate_sleep",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "急着证明没老，敲裂了椅架",
            ["id"] = "rating_n06_candidate_split",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n06",
            ["requiresFacts"] = {
                "n06_candidate_split",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "要回来了（一部分）",
            ["id"] = "rating_n07_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n07",
            ["requiresFacts"] = {
                "n07_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "说了一半，软了下来",
            ["id"] = "rating_n07_candidate_soft",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n07",
            ["requiresFacts"] = {
                "n07_candidate_soft",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "气下去，酸上来",
            ["id"] = "rating_n07_candidate_acid",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n07",
            ["requiresFacts"] = {
                "n07_candidate_acid",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "旧钱拿回来了，新活却应了半价",
            ["id"] = "rating_n07_candidate_discount",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n07",
            ["requiresFacts"] = {
                "n07_candidate_discount",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "桶掀翻了，钱也没拿到",
            ["id"] = "rating_n07_candidate_bucket",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n07",
            ["requiresFacts"] = {
                "n07_candidate_bucket",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "休日过成了",
            ["id"] = "rating_n08_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n08",
            ["requiresFacts"] = {
                "n08_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "慢半拍",
            ["id"] = "rating_n08_candidate_slow",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n08",
            ["requiresFacts"] = {
                "n08_candidate_slow",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "可以再等",
            ["id"] = "rating_n08_candidate_wait",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n08",
            ["requiresFacts"] = {
                "n08_candidate_wait",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "陪丫头玩了一天，靴子还没补",
            ["id"] = "rating_n08_candidate_child",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n08",
            ["requiresFacts"] = {
                "n08_candidate_child",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "把家里也当成了哨所",
            ["id"] = "rating_n08_candidate_military",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n08",
            ["requiresFacts"] = {
                "n08_candidate_military",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "对得上了",
            ["id"] = "rating_n09_candidate_good",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n09",
            ["requiresFacts"] = {
                "n09_candidate_good",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "没对成想要的样子",
            ["id"] = "rating_n09_candidate_doubt",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n09",
            ["requiresFacts"] = {
                "n09_candidate_doubt",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "数落起了旧花篱",
            ["id"] = "rating_n09_candidate_hedge",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n09",
            ["requiresFacts"] = {
                "n09_candidate_hedge",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "账改对了，却说成了自己的恩典",
            ["id"] = "rating_n09_candidate_grace",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n09",
            ["requiresFacts"] = {
                "n09_candidate_grace",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "没查原约，先收走了他的粮",
            ["id"] = "rating_n09_candidate_grain",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n09",
            ["requiresFacts"] = {
                "n09_candidate_grain",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "三只碗摆顺了",
            ["id"] = "rating_n10_result_3",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n10",
            ["requiresFacts"] = {
                "n10_result_3",
            },
            ["stars"] = 3,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "那句话顶了出去",
            ["id"] = "rating_n10_result_2a",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n10",
            ["requiresFacts"] = {
                "n10_result_2a",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "布解下来了",
            ["id"] = "rating_n10_result_1a",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n10",
            ["requiresFacts"] = {
                "n10_result_1a",
            },
            ["stars"] = 1,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "医药费交了，交货日子却答早了",
            ["id"] = "rating_n10_result_2b",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n10",
            ["requiresFacts"] = {
                "n10_result_2b",
            },
            ["stars"] = 2,
        },
        {
            ["excludesFacts"] = {},
            ["feedback"] = "叫米洛搭把手，伤口又出了血",
            ["id"] = "rating_n10_result_1b",
            ["priority"] = 0,
            ["ratingSetId"] = "rating_n10",
            ["requiresFacts"] = {
                "n10_result_1b",
            },
            ["stars"] = 1,
        },
    },
    ["recipes"] = {
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_rested",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_e01_1",
            ["letterId"] = "letter_pa_01",
            ["name"] = "一",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_mother_dream",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_e01_2",
            ["letterId"] = "letter_pa_01",
            ["name"] = "二",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_song_faded",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_e01_3",
            ["letterId"] = "letter_pa_01",
            ["name"] = "三",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_mother_unclear",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_e01_4",
            ["letterId"] = "letter_pa_01",
            ["name"] = "四",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_fish_choir",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_e01_5",
            ["letterId"] = "letter_pa_01",
            ["name"] = "五",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_happy",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_walking_crates",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_e01_6",
            ["letterId"] = "letter_pa_01",
            ["name"] = "六",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_reason",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_fragmented_dream",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_e01_7",
            ["letterId"] = "letter_pa_01",
            ["name"] = "七",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_ashen_herb",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "e01_result_fragmented_song_faded",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_e01_8",
            ["letterId"] = "letter_pa_01",
            ["name"] = "八",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_ashen_herb",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n01_result_departure_agreed",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n01_1",
            ["letterId"] = "letter_n01",
            ["name"] = "谈妥",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n01_brave",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n01_result_departure_conflict",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n01_2",
            ["letterId"] = "letter_n01",
            ["name"] = "冲突",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_anger",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n01_brave",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n01_result_stayed_for_promise",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n01_3",
            ["letterId"] = "letter_n01",
            ["name"] = "留下",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_trust",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n01_brave",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n01_result_missed_place",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n01_4",
            ["letterId"] = "letter_n01",
            ["name"] = "错过",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_fear",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n01_brave",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n01_result_started_learning",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n01_5",
            ["letterId"] = "letter_n01",
            ["name"] = "学习",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_curiosity",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n01_brave",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n02_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n02_1",
            ["letterId"] = "letter_n02",
            ["name"] = "吃成了",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n02_happy",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n02_candidate_swallowed",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n02_2",
            ["letterId"] = "letter_n02",
            ["name"] = "咽回去",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n02_fear",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n02_happy",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n02_candidate_escaped",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n02_3",
            ["letterId"] = "letter_n02",
            ["name"] = "问出口",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n02_fear",
                    "word_candidate_n02_sadness",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n02_happy",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n02_candidate_care",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n02_4",
            ["letterId"] = "letter_n02",
            ["name"] = "忙照料",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n02_h2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n02_happy",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n02_candidate_doubted",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n02_5",
            ["letterId"] = "letter_n02",
            ["name"] = "不相信",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n02_suspicion",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n02_happy",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n03_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n03_1",
            ["letterId"] = "letter_n03",
            ["name"] = "顺利卖完",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n03_k1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n03_candidate_hide",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n03_2",
            ["letterId"] = "letter_n03",
            ["name"] = "一直躲",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n03_fear",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n03_k1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n03_candidate_freeze",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n03_3",
            ["letterId"] = "letter_n03",
            ["name"] = "没开口",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n03_fear",
                    "word_candidate_e01_c1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n03_k1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n03_candidate_salt",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n03_4",
            ["letterId"] = "letter_n03",
            ["name"] = "忘买盐",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n03_c1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n03_k1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n03_candidate_protect",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n03_5",
            ["letterId"] = "letter_n03",
            ["name"] = "护萝卜",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_s2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n03_k1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n04_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n04_1",
            ["letterId"] = "letter_n04",
            ["name"] = "高兴回来了",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n04_h1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n04_candidate_envy",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n04_2",
            ["letterId"] = "letter_n04",
            ["name"] = "笑没入心",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n04_e1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n04_h1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n04_candidate_tear",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n04_3",
            ["letterId"] = "letter_n04",
            ["name"] = "撕旗",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n04_e1",
                    "word_candidate_n01_a2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n04_h1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n04_candidate_play",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n04_4",
            ["letterId"] = "letter_n04",
            ["name"] = "贪玩未扫",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n04_h2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n04_h1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n04_candidate_past",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n04_5",
            ["letterId"] = "letter_n04",
            ["name"] = "熬旧甜汤",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n04_r1",
                    "word_candidate_n04_s1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n04_h1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n05_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n05_1",
            ["letterId"] = "letter_n05",
            ["name"] = "吃完了",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n05_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n05_candidate_count",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n05_2",
            ["letterId"] = "letter_n05",
            ["name"] = "算菜价",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n05_q1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n05_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n05_candidate_sad",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n05_3",
            ["letterId"] = "letter_n05",
            ["name"] = "一口没动",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n05_s1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n05_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n05_candidate_talk",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n05_4",
            ["letterId"] = "letter_n05",
            ["name"] = "说家事",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n05_t1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n05_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n05_candidate_fork",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n05_5",
            ["letterId"] = "letter_n05",
            ["name"] = "质问银叉",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n01_suspicion",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n05_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n06_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n06_1",
            ["letterId"] = "letter_n06",
            ["name"] = "做完了",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n06_m1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n06_candidate_pain",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n06_2",
            ["letterId"] = "letter_n06",
            ["name"] = "疼着做完",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n06_p1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n06_m1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n06_candidate_stop",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n06_3",
            ["letterId"] = "letter_n06",
            ["name"] = "怕痛停手",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n06_p1",
                    "word_candidate_elias_fear",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n06_m1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n06_candidate_sleep",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n06_4",
            ["letterId"] = "letter_n06",
            ["name"] = "睡过头",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_sleep_alt",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n06_m1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n06_candidate_split",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n06_5",
            ["letterId"] = "letter_n06",
            ["name"] = "强敲开裂",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n06_a1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n06_m1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n07_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n07_1",
            ["letterId"] = "letter_n07",
            ["name"] = "要回部分",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n07_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n07_candidate_soft",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n07_2",
            ["letterId"] = "letter_n07",
            ["name"] = "软下来",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n07_s1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n07_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n07_candidate_acid",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n07_3",
            ["letterId"] = "letter_n07",
            ["name"] = "泛酸没要成",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n07_s1",
                    "word_candidate_n03_e1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n07_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n07_candidate_discount",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n07_4",
            ["letterId"] = "letter_n07",
            ["name"] = "应半价",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n07_f1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n07_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n07_candidate_bucket",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n07_5",
            ["letterId"] = "letter_n07",
            ["name"] = "掀桶",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n07_a2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n07_a1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n08_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n08_1",
            ["letterId"] = "letter_n08",
            ["name"] = "休日过成",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n08_r1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n08_candidate_slow",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n08_2",
            ["letterId"] = "letter_n08",
            ["name"] = "慢半拍",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n08_c1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n08_r1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n08_candidate_wait",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n08_3",
            ["letterId"] = "letter_n08",
            ["name"] = "可以再等",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n08_r1",
                    "word_candidate_n08_c2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n08_c1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n08_candidate_child",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n08_4",
            ["letterId"] = "letter_n08",
            ["name"] = "陪玩拖鞋",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n08_h1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n08_r1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n08_candidate_military",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n08_5",
            ["letterId"] = "letter_n08",
            ["name"] = "家如哨所",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n08_a1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n08_r1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n09_candidate_good",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n09_1",
            ["letterId"] = "letter_n09",
            ["name"] = "对上了",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n09_q1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n09_candidate_doubt",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n09_2",
            ["letterId"] = "letter_n09",
            ["name"] = "盘问失礼",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n09_suspicion",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n09_q1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n09_candidate_hedge",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n09_3",
            ["letterId"] = "letter_n09",
            ["name"] = "数落花篱",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n09_suspicion",
                    "word_candidate_n09_a1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n09_q1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n09_candidate_grace",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n09_4",
            ["letterId"] = "letter_n09",
            ["name"] = "改作恩典",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n09_f1",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n09_q1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n09_candidate_grain",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n09_5",
            ["letterId"] = "letter_n09",
            ["name"] = "先收粮",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n09_t1",
                    "word_candidate_n09_t2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n09_q1",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n10_result_3",
                },
                ["stars"] = 3,
            },
            ["id"] = "recipe_v02_n10_1",
            ["letterId"] = "letter_n10",
            ["name"] = "三星",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n10_recall",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n10_result_2a",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n10_2",
            ["letterId"] = "letter_n10",
            ["name"] = "顶嘴",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n10_anger",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n10_recall",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n10_result_2b",
                },
                ["stars"] = 2,
            },
            ["id"] = "recipe_v02_n10_3",
            ["letterId"] = "letter_n10",
            ["name"] = "答早",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n10_fear",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n10_recall",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n10_result_1a",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n10_4",
            ["letterId"] = "letter_n10",
            ["name"] = "怀疑",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n09_p2",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n10_recall",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
        {
            ["expect"] = {
                ["canDeliver"] = true,
                ["facts"] = {
                    "n10_result_1b",
                },
                ["stars"] = 1,
            },
            ["id"] = "recipe_v02_n10_5",
            ["letterId"] = "letter_n10",
            ["name"] = "再伤",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_n10_trust",
                    "word_candidate_elias_trust",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_n10_recall",
                ["specialItemIds"] = {},
            },
            ["requiresFutureSources"] = false,
        },
    },
    ["sampleCases"] = {
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 0.1,
                    ["sleep"] = 1.0,
                },
                ["facts"] = {
                    "e01_result_rested",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_rested",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_rested",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["sleep"] = "明显",
                },
                ["unstable"] = false,
            },
            ["id"] = "A",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 1.1,
                    ["sleep"] = 1.46,
                },
                ["facts"] = {
                    "e01_result_mother_dream",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_mother_dream",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_mother_dream",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "明显",
                    ["sleep"] = "强烈",
                },
                ["unstable"] = false,
            },
            ["id"] = "B",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 0.1,
                    ["forget"] = 0.6,
                    ["relax"] = 0.03,
                    ["sadness"] = 0.06,
                    ["sleep"] = 1.0,
                },
                ["facts"] = {
                    "e01_result_song_faded",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_song_faded",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_song_faded",
                    ["stars"] = 2,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["forget"] = "微弱",
                    ["relax"] = "微弱",
                    ["sadness"] = "微弱",
                    ["sleep"] = "明显",
                },
                ["unstable"] = false,
            },
            ["id"] = "C",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 1.1,
                    ["forget"] = 0.6,
                    ["relax"] = 0.03,
                    ["sadness"] = 0.06,
                    ["sleep"] = 1.46,
                },
                ["facts"] = {
                    "e01_result_mother_unclear",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_mother_unclear",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_mother_unclear",
                    ["stars"] = 1,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "明显",
                    ["forget"] = "微弱",
                    ["relax"] = "微弱",
                    ["sadness"] = "微弱",
                    ["sleep"] = "强烈",
                },
                ["unstable"] = false,
            },
            ["id"] = "D",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 1.1,
                    ["happy"] = 0.6,
                    ["relax"] = 0.03,
                    ["sleep"] = 1.46,
                    ["warmth"] = 0.06,
                },
                ["facts"] = {
                    "e01_result_fish_choir",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_fish_choir",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_fish_choir",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "明显",
                    ["happy"] = "微弱",
                    ["relax"] = "微弱",
                    ["sleep"] = "强烈",
                    ["warmth"] = "微弱",
                },
                ["unstable"] = false,
            },
            ["id"] = "E",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_happy",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 1.1,
                    ["reason"] = 0.6,
                    ["recall"] = 0.03,
                    ["sleep"] = 1.46,
                },
                ["facts"] = {
                    "e01_result_walking_crates",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_walking_crates",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_walking_crates",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "明显",
                    ["reason"] = "微弱",
                    ["recall"] = "微弱",
                    ["sleep"] = "强烈",
                },
                ["unstable"] = false,
            },
            ["id"] = "F",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_dream",
                    "word_candidate_elias_reason",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.07500000000000001,
                    ["dream"] = 0.55,
                    ["sleep"] = 1.5,
                },
                ["facts"] = {
                    "e01_result_fragmented_dream",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_fragmented_dream",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_fragmented_dream",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {
                    {
                        ["addTags"] = {
                            ["dream"] = 0.4,
                        },
                        ["ruleId"] = "se_dream",
                    },
                },
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["sleep"] = "强烈",
                },
                ["unstable"] = false,
            },
            ["id"] = "G1",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_ashen_herb",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.07500000000000001,
                    ["dream"] = 0.55,
                    ["forget"] = 0.8999999999999999,
                    ["relax"] = 0.045,
                    ["sadness"] = 0.09,
                    ["sleep"] = 1.5,
                },
                ["facts"] = {
                    "e01_result_fragmented_song_faded",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_fragmented_song_faded",
                },
                ["onsetDelayHours"] = 2,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_fragmented_song_faded",
                    ["stars"] = 2,
                },
                ["sideEffects"] = {
                    {
                        ["addTags"] = {
                            ["dream"] = 0.4,
                        },
                        ["ruleId"] = "se_dream",
                    },
                },
                ["stability"] = 1,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["forget"] = "明显",
                    ["relax"] = "微弱",
                    ["sadness"] = "微弱",
                    ["sleep"] = "强烈",
                },
                ["unstable"] = false,
            },
            ["id"] = "G2",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {
                    "word_candidate_elias_forget",
                },
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_ashen_herb",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 0.1,
                    ["sleep"] = 1.0,
                },
                ["facts"] = {
                    "e01_result_rested",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_rested",
                },
                ["onsetDelayHours"] = 1,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_rested",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = 0,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["sleep"] = "明显",
                },
                ["unstable"] = false,
            },
            ["id"] = "G3",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 1,
                    },
                    {
                        ["ingredientId"] = "ing_sea_salt",
                        ["quantity"] = 1,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
        {
            ["baselineId"] = "S0",
            ["expect"] = {
                ["canShip"] = true,
                ["durationHours"] = 8,
                ["effects"] = {
                    ["calm"] = 0.05,
                    ["dream"] = 0.1,
                    ["sleep"] = 1.0,
                },
                ["facts"] = {
                    "e01_result_rested",
                },
                ["failures"] = {},
                ["followupFragments"] = {
                    "frag_e01_result_rested",
                },
                ["onsetDelayHours"] = 0,
                ["rating"] = {
                    ["ruleId"] = "rating_e01_result_rested",
                    ["stars"] = 3,
                },
                ["sideEffects"] = {},
                ["stability"] = -2,
                ["tiers"] = {
                    ["calm"] = "微弱",
                    ["dream"] = "微弱",
                    ["sleep"] = "明显",
                },
                ["unstable"] = true,
            },
            ["id"] = "G4",
            ["purpose"] = "v02首单登记配方及不同原料验收",
            ["recipe"] = {
                ["auxWordIds"] = {},
                ["equipmentId"] = "kit_old_cauldron",
                ["ingredients"] = {
                    {
                        ["ingredientId"] = "ing_night_dew",
                        ["quantity"] = 2,
                    },
                },
                ["mainWordId"] = "word_candidate_elias_sleep",
                ["specialItemIds"] = {},
            },
        },
    },
    ["sourceHashes"] = {
        ["docs/文案/供给验算表_v02.md"] = "c24f30f7e10e5d13cda999883b56873acb30db5e8d1fb678915625b3a4a5a762",
        ["docs/文案/分支条件表_v02.md"] = "f832076207f49555f593eaaeaf29ce1a65d3474b4b13555c46f4a628cf6ca765",
        ["docs/文案/开场与首封来信_定稿_v01.md"] = "f592916fbdd9e44c223b180504b578ccf39977219d54701662f6a02493cdbc95",
        ["docs/文案/普通订单/N01_去做抄写员学徒_后续定稿_v01.md"] = "f0738e97d16f2020e2fbf8db74485d7db10923581812d79e4e16c8bc83963d43",
        ["docs/文案/普通订单/N01_去做抄写员学徒_来信定稿_v01.md"] = "9b7ca81ebdde45dc0306ef786bc6a35de8ccff9b2426c6936b68b6f5b5280dc3",
        ["docs/文案/普通订单/N02_两个人的晚饭_后续定稿_v01.md"] = "f53ddb7d2bb7767317b65534b9e847e71e26cde997eba529545c9a991aad4cd8",
        ["docs/文案/普通订单/N02_两个人的晚饭_来信定稿_v01.md"] = "ffdc237d1e0f1f94e3e33342f6b99b0a2a46b5ccfe6975dd495e316c8e86f268",
        ["docs/文案/普通订单/N03_一袋胡萝卜的远行_定稿_v01.md"] = "3ad6e8738536d24f46bf1d3c1f70caecdf4f64833484d3b6b9acf8db47d311de",
        ["docs/文案/普通订单/N04_钟声过后还有一口甜_定稿_v01.md"] = "a4448bdffc267f700298c8e4c6c4e1d855ee7f151f1a25be6dae97227a5e4e95",
        ["docs/文案/普通订单/N05_花圃比家徽好养_定稿_v01.md"] = "938cf893f1039197b64441d4e98d6213d750e20c636462fc56020b3522db6778",
        ["docs/文案/普通订单/N06_椅子不该跪着迎客_定稿_v01.md"] = "2d229a0d7acbce6a87aa822297f4fd8c2593552ce0bd79d40b477e06659f07aa",
        ["docs/文案/普通订单/N07_把工钱从下次里洗出来_定稿_v01.md"] = "2c0699f8df1b5254f35d5c08f1d4254b9e5c745b562667d49be89d55eb645a41",
        ["docs/文案/普通订单/N08_休假的脚步不用列队_后续定稿_v01.md"] = "2731afa4d30487816c7950db07b9bdd66fbedcc55c8cd773804a015825211032",
        ["docs/文案/普通订单/N08_休假的脚步不用列队_来信定稿_v01.md"] = "3fc6d93350bff1ce4991f1cd7ca6987f3d1851534a929d432baff1b88c95a4c9",
        ["docs/文案/普通订单/N09_花是花，租是租_后续定稿_v01.md"] = "819ecaf63e91fc2b23d5a5fad04c364b231ed373dc544976cb37e1fdbb287b52",
        ["docs/文案/普通订单/N09_花是花，租是租_来信定稿_v01.md"] = "a0c562f554f0bc65c5a49ee32247e7c4c4b05ab5948bb3e1d913db607798d585",
        ["docs/文案/普通订单/N10_汤可以喝_后续定稿_v01.md"] = "e446ae6dcf54aacba605dab33f4f4a06abbe1f6b63c306340f2c9be0342df16f",
        ["docs/文案/普通订单/N10_汤可以喝_来信定稿_v01.md"] = "42373e5d77acab36bb055542a2bf261c4c8d943b8a41f95413d39e42a1f68873",
        ["docs/文案/普通订单/首单_埃利亚斯_后续定稿_v01.md"] = "28d8f37ff36a04418445cad0d53d4c1e93836e514fe244b0e61ab7985ac75802",
        ["docs/文案/词条数值表_v02.md"] = "a7790f178dfc24aa806fd59336a27eb18074120b3ca9394843069c363146d2ad",
    },
    ["words"] = {
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "帮忙",
            ["effects"] = {
                ["safety"] = 0.05,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_elias_trust",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "没好意思",
            ["effects"] = {
                ["fear"] = 1.0,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_elias_fear",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "记忆类",
            ["displayText"] = "忘记",
            ["effects"] = {
                ["forget"] = 1.0,
                ["relax"] = 0.05,
                ["sadness"] = 0.1,
            },
            ["id"] = "word_candidate_elias_forget",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "sleep_basic",
            ["category"] = "睡眠类",
            ["displayText"] = "合上眼",
            ["effects"] = {
                ["calm"] = 0.05,
                ["dream"] = 0.1,
                ["sleep"] = 1.0,
            },
            ["id"] = "word_candidate_elias_sleep",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "tired_basic",
            ["category"] = "睡眠类",
            ["displayText"] = "困",
            ["effects"] = {
                ["calm"] = 0.1,
                ["relax"] = 0.05,
                ["sleep"] = 1.0,
            },
            ["id"] = "word_candidate_elias_sleep_alt",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "sleep_basic",
            ["category"] = "睡眠类",
            ["displayText"] = "梦见",
            ["effects"] = {
                ["dream"] = 1.0,
                ["sleep"] = 0.1,
            },
            ["id"] = "word_candidate_elias_dream",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "乐了",
            ["effects"] = {
                ["happy"] = 1.0,
                ["relax"] = 0.05,
                ["warmth"] = 0.1,
            },
            ["id"] = "word_candidate_elias_happy",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "算",
            ["effects"] = {
                ["reason"] = 1.0,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_elias_reason",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "神志不清",
            ["effects"] = {
                ["confusion"] = 1.0,
                ["fear"] = 0.05,
                ["sleep"] = 0.1,
            },
            ["id"] = "word_candidate_e01_c1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "记忆类",
            ["displayText"] = "记在心里",
            ["effects"] = {
                ["reason"] = 0.05,
                ["recall"] = 1.0,
                ["trust"] = 0.1,
            },
            ["id"] = "word_candidate_n01_recall",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "火气",
            ["effects"] = {
                ["anger"] = 1.0,
                ["brave"] = 0.05,
            },
            ["id"] = "word_candidate_n01_anger",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "掏心掏肺",
            ["effects"] = {
                ["recall"] = 0.05,
                ["safety"] = 0.05,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_n01_trust",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "客套话",
            ["effects"] = {
                ["fear"] = 0.05,
                ["reason"] = 0.05,
                ["suspicion"] = 1.0,
            },
            ["id"] = "word_candidate_n01_suspicion",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "壮起胆子",
            ["effects"] = {
                ["brave"] = 1.0,
                ["fear"] = 0.05,
                ["reason"] = 0.05,
            },
            ["id"] = "word_candidate_n01_brave",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "怕",
            ["effects"] = {
                ["fear"] = 1.0,
                ["reason"] = 0.1,
            },
            ["id"] = "word_candidate_n01_fear",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "多问几句",
            ["effects"] = {
                ["curiosity"] = 1.0,
                ["reason"] = 0.05,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_n01_curiosity",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "骂骂咧咧",
            ["effects"] = {
                ["anger"] = 1.0,
                ["brave"] = 0.05,
            },
            ["id"] = "word_candidate_n01_a2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "漂亮话",
            ["effects"] = {
                ["fear"] = 0.05,
                ["reason"] = 0.05,
                ["suspicion"] = 1.0,
            },
            ["id"] = "word_candidate_n01_s2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "高兴",
            ["effects"] = {
                ["happy"] = 1.0,
                ["relax"] = 0.05,
            },
            ["id"] = "word_candidate_n02_happy",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "怕",
            ["effects"] = {
                ["fear"] = 1.0,
                ["reason"] = 0.05,
                ["sadness"] = 0.1,
            },
            ["id"] = "word_candidate_n02_fear",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "哭",
            ["effects"] = {
                ["recall"] = 0.1,
                ["sadness"] = 1.0,
            },
            ["id"] = "word_candidate_n02_sadness",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "盘问",
            ["effects"] = {
                ["fear"] = 0.05,
                ["reason"] = 0.1,
                ["suspicion"] = 1.0,
            },
            ["id"] = "word_candidate_n02_suspicion",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "笑着",
            ["effects"] = {
                ["happy"] = 1.0,
                ["trust"] = 0.05,
            },
            ["id"] = "word_candidate_n02_h2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "怕得要命",
            ["effects"] = {
                ["fear"] = 1.0,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n03_fear",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "没关系",
            ["effects"] = {
                ["reason"] = 0.05,
                ["safety"] = 1.0,
                ["trust"] = 0.05,
            },
            ["id"] = "word_candidate_n03_k1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "头一回",
            ["effects"] = {
                ["brave"] = 0.05,
                ["curiosity"] = 1.0,
                ["happy"] = 0.05,
            },
            ["id"] = "word_candidate_n03_c1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "比我还要快",
            ["effects"] = {
                ["envy"] = 1.0,
                ["reason"] = 0.05,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n03_e1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "甜极了",
            ["effects"] = {
                ["happy"] = 1.0,
                ["relax"] = 0.1,
            },
            ["id"] = "word_candidate_n04_h1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "偷偷比了比",
            ["effects"] = {
                ["envy"] = 1.0,
                ["reason"] = 0.05,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n04_e1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "老厨娘",
            ["effects"] = {
                ["recall"] = 1.0,
                ["sadness"] = 0.1,
            },
            ["id"] = "word_candidate_n04_r1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "没见她回来",
            ["effects"] = {
                ["recall"] = 0.05,
                ["sadness"] = 1.0,
            },
            ["id"] = "word_candidate_n04_s1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "唱歌",
            ["effects"] = {
                ["brave"] = 0.05,
                ["happy"] = 1.0,
            },
            ["id"] = "word_candidate_n04_h2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "物件类",
            ["displayText"] = "肥烤鹅",
            ["effects"] = {
                ["appetite"] = 1.0,
                ["happy"] = 0.05,
                ["warmth"] = 0.05,
            },
            ["id"] = "word_candidate_n05_a1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "物件类",
            ["displayText"] = "算盘",
            ["effects"] = {
                ["reason"] = 1.0,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_n05_q1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "落魄",
            ["effects"] = {
                ["fear"] = 0.05,
                ["recall"] = 0.05,
                ["sadness"] = 1.0,
            },
            ["id"] = "word_candidate_n05_s1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "姑母",
            ["effects"] = {
                ["safety"] = 0.05,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_n05_t1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "身体类",
            ["displayText"] = "手底下先实了",
            ["effects"] = {
                ["safety"] = 0.05,
                ["steady"] = 1.0,
            },
            ["id"] = "word_candidate_n06_m1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "pain_basic",
            ["category"] = "身体类",
            ["displayText"] = "酸疼",
            ["effects"] = {
                ["fear"] = 0.05,
                ["pain"] = 1.0,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_n06_p1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "粗糙",
            ["effects"] = {
                ["anger"] = 1.0,
                ["reason"] = 0.05,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_n06_a1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "warmth_basic",
            ["category"] = "身体类",
            ["displayText"] = "搓热乎",
            ["effects"] = {
                ["relax"] = 0.05,
                ["steady"] = 0.1,
                ["warmth"] = 1.0,
            },
            ["id"] = "word_candidate_n06_w1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "身体类",
            ["displayText"] = "骨节发白",
            ["effects"] = {
                ["anger"] = 1.0,
                ["brave"] = 0.05,
            },
            ["id"] = "word_candidate_n07_a1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "堵我的嘴",
            ["effects"] = {
                ["anger"] = 1.0,
                ["fear"] = 0.05,
                ["reason"] = 0.05,
            },
            ["id"] = "word_candidate_n07_a2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "干笑",
            ["effects"] = {
                ["fear"] = 0.05,
                ["sadness"] = 1.0,
            },
            ["id"] = "word_candidate_n07_s1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "更没指望",
            ["effects"] = {
                ["fear"] = 1.0,
                ["reason"] = 0.05,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n07_f1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "轮休",
            ["effects"] = {
                ["calm"] = 0.05,
                ["relax"] = 1.0,
                ["safety"] = 0.1,
            },
            ["id"] = "word_candidate_n08_r1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "定定心心",
            ["effects"] = {
                ["calm"] = 1.0,
                ["reason"] = 0.05,
                ["relax"] = 0.05,
            },
            ["id"] = "word_candidate_n08_c1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "安安稳稳",
            ["effects"] = {
                ["calm"] = 1.0,
                ["reason"] = 0.05,
                ["safety"] = 0.05,
            },
            ["id"] = "word_candidate_n08_c2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "笑",
            ["effects"] = {
                ["happy"] = 1.0,
                ["trust"] = 0.05,
            },
            ["id"] = "word_candidate_n08_h1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "数落",
            ["effects"] = {
                ["anger"] = 1.0,
                ["fear"] = 0.05,
            },
            ["id"] = "word_candidate_n08_a1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "对不上",
            ["effects"] = {
                ["fear"] = 0.05,
                ["reason"] = 0.05,
                ["suspicion"] = 1.0,
            },
            ["id"] = "word_candidate_n09_suspicion",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "核一遍",
            ["effects"] = {
                ["reason"] = 1.0,
                ["recall"] = 0.1,
            },
            ["id"] = "word_candidate_n09_q1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "暗火",
            ["effects"] = {
                ["anger"] = 1.0,
                ["recall"] = 0.05,
            },
            ["id"] = "word_candidate_n09_a1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "情绪类",
            ["displayText"] = "寝食难安",
            ["effects"] = {
                ["fear"] = 1.0,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n09_f1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "死规矩",
            ["effects"] = {
                ["reason"] = 0.1,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_n09_t1",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "物件类",
            ["displayText"] = "底册",
            ["effects"] = {
                ["reason"] = 0.05,
                ["safety"] = 0.05,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_n09_t2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "旁证",
            ["effects"] = {
                ["fear"] = 0.05,
                ["reason"] = 0.1,
                ["suspicion"] = 1.0,
            },
            ["id"] = "word_candidate_n09_p2",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "记忆类",
            ["displayText"] = "想起",
            ["effects"] = {
                ["reason"] = 0.05,
                ["recall"] = 1.0,
                ["trust"] = 0.1,
            },
            ["id"] = "word_candidate_n10_recall",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "痛骂",
            ["effects"] = {
                ["anger"] = 1.0,
                ["brave"] = 0.05,
            },
            ["id"] = "word_candidate_n10_anger",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "行为类",
            ["displayText"] = "不敢",
            ["effects"] = {
                ["fear"] = 1.0,
                ["sadness"] = 0.05,
            },
            ["id"] = "word_candidate_n10_fear",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "关系类",
            ["displayText"] = "准话",
            ["effects"] = {
                ["recall"] = 0.05,
                ["safety"] = 0.05,
                ["trust"] = 1.0,
            },
            ["id"] = "word_candidate_n10_trust",
            ["reusable"] = false,
        },
        {
            ["attributeProfileId"] = "daytime_basic",
            ["category"] = "物件类",
            ["displayText"] = "汤",
            ["effects"] = {
                ["appetite"] = 1.0,
                ["relax"] = 0.05,
                ["warmth"] = 0.1,
            },
            ["id"] = "word_candidate_n10_soup",
            ["reusable"] = false,
        },
    },
}
